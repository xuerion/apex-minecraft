set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- ORACLE Application Express (APEX) export file
--
-- You should run the script connected to SQL*Plus as the Oracle user
-- APEX_050000 or as the owner (parsing schema) of the application.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_api.import_begin (
 p_version_yyyy_mm_dd=>'2013.01.01'
,p_default_workspace_id=>574177041251819873
,p_default_application_id=>17555
,p_default_owner=>'CS347_DARIUS_XU_SCHEMA'
);
end;
/
prompt --application/set_environment
 
prompt APPLICATION 17555 - Minecraft Application
--
-- Application Export:
--   Application:     17555
--   Name:            Minecraft Application
--   Date and Time:   06:12 Wednesday December 3, 2014
--   Exported By:     DARIUSGXU@GMAIL.COM
--   Flashback:       0
--   Export Type:     Application Export
--   Version:         5.0.0.00.07
--   Instance ID:     63855061200466
--

-- Application Statistics:
--   Pages:                     32
--     Items:                   70
--     Processes:               43
--     Regions:                 49
--     Buttons:                 65
--     Dynamic Actions:         27
--   Shared Components:
--     Logic:
--     Navigation:
--       Lists:                  1
--       Breadcrumbs:            1
--       NavBar Entries:         1
--     Security:
--       Authentication:         1
--     User Interface:
--       Themes:                 1
--       Templates:
--         Page:                 9
--         Region:               6
--         Label:                3
--         List:                 7
--         Popup LOV:            1
--         Calendar:             1
--         Breadcrumb:           1
--         Button:               4
--         Report:               6
--       LOVs:                   8
--       Shortcuts:              1
--     Globalization:
--     Reports:
--   Supporting Objects:  Included

prompt --application/delete_application
begin
wwv_flow_api.remove_flow(wwv_flow.g_flow_id);
end;
/
prompt --application/ui_types
begin
null;
end;
/
prompt --application/create_application
begin
wwv_flow_api.create_flow(
 p_id=>wwv_flow.g_flow_id
,p_display_id=>nvl(wwv_flow_application_install.get_application_id,17555)
,p_owner=>nvl(wwv_flow_application_install.get_schema,'CS347_DARIUS_XU_SCHEMA')
,p_name=>nvl(wwv_flow_application_install.get_application_name,'Minecraft Application')
,p_alias=>nvl(wwv_flow_application_install.get_application_alias,'F_17555')
,p_page_view_logging=>'YES'
,p_page_protection_enabled_y_n=>'Y'
,p_checksum_salt=>'73E12AC666617345B1C517AFA7A86F7152DC022983EC6D3C1A29A2446166BC16'
,p_bookmark_checksum_function=>'SH1'
,p_on_max_session_timeout_url=>'#LOGOUT_URL#'
,p_on_max_idle_timeout_url=>'#LOGOUT_URL#'
,p_compatibility_mode=>'4.2'
,p_flow_language=>'en'
,p_flow_language_derived_from=>'FLOW_PRIMARY_LANGUAGE'
,p_flow_image_prefix => nvl(wwv_flow_application_install.get_image_prefix,'')
,p_authentication=>'PLUGIN'
,p_authentication_id=>788853266544209427+wwv_flow_api.g_id_offset
,p_application_tab_set=>0
,p_logo_image=>'TEXT:Minecraft Application'
,p_public_user=>'APEX_PUBLIC_USER'
,p_proxy_server=> nvl(wwv_flow_application_install.get_proxy,'')
,p_flow_version=>'release 1.0'
,p_flow_status=>'AVAILABLE_W_EDIT_LINK'
,p_flow_unavailable_text=>'This application is currently unavailable at this time.'
,p_exact_substitutions_only=>'Y'
,p_browser_cache=>'N'
,p_browser_frame=>'D'
,p_rejoin_existing_sessions=>'N'
,p_csv_encoding=>'Y'
,p_auto_time_zone=>'N'
,p_last_updated_by=>'LULULIU820@UTEXAS.EDU'
,p_last_upd_yyyymmddhh24miss=>'20141124061754'
,p_ui_type_name => null
);
end;
/
prompt --application/shared_components/navigation/lists
begin
wwv_flow_api.create_list(
 p_id=>788825513509204011+wwv_flow_api.g_id_offset
,p_name=>'Navigation Bar'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.create_list_item(
 p_id=>788854428796209433+wwv_flow_api.g_id_offset
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>789438654042591039+wwv_flow_api.g_id_offset
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Players'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>886018666571763997+wwv_flow_api.g_id_offset
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Documents'
,p_list_item_link_target=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>789438654042591039+wwv_flow_api.g_id_offset
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>789438939636594285+wwv_flow_api.g_id_offset
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Avatars'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>789439136040596553+wwv_flow_api.g_id_offset
,p_list_item_display_sequence=>35
,p_list_item_link_text=>'Ownership'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>789438939636594285+wwv_flow_api.g_id_offset
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>789439406283597887+wwv_flow_api.g_id_offset
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Items'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>789438939636594285+wwv_flow_api.g_id_offset
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>793200069722260627+wwv_flow_api.g_id_offset
,p_list_item_display_sequence=>41
,p_list_item_link_text=>'Weapons'
,p_list_item_link_target=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>789439406283597887+wwv_flow_api.g_id_offset
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>793200715914267570+wwv_flow_api.g_id_offset
,p_list_item_display_sequence=>42
,p_list_item_link_text=>'Armors'
,p_list_item_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>789439406283597887+wwv_flow_api.g_id_offset
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>793201006686269070+wwv_flow_api.g_id_offset
,p_list_item_display_sequence=>43
,p_list_item_link_text=>'Tools'
,p_list_item_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>789439406283597887+wwv_flow_api.g_id_offset
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>793201275159269853+wwv_flow_api.g_id_offset
,p_list_item_display_sequence=>44
,p_list_item_link_text=>'Food'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>789439406283597887+wwv_flow_api.g_id_offset
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>886018401468762947+wwv_flow_api.g_id_offset
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Chunks'
,p_list_item_link_target=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>789440183488606431+wwv_flow_api.g_id_offset
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Materials'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
end;
/
prompt --application/user_interfaces
begin
wwv_flow_api.create_user_interface(
 p_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_ui_type_name=>'DESKTOP'
,p_display_name=>'Desktop'
,p_display_seq=>10
,p_use_auto_detect=>false
,p_is_default=>true
,p_theme_id=>42
,p_home_url=>'f?p=&APP_ID.:1:&SESSION.'
,p_login_url=>'f?p=&APP_ID.:LOGIN_DESKTOP:&SESSION.'
,p_navigation_list_id=>788825513509204011+wwv_flow_api.g_id_offset
);
end;
/
prompt --application/user_interfaces/combined_files
begin
null;
end;
/
prompt --application/shared_components/files
begin
null;
end;
/
prompt --application/plugin_settings
begin
wwv_flow_api.create_plugin_setting(
 p_id=>788825441705204011+wwv_flow_api.g_id_offset
,p_plugin_type=>'ITEM TYPE'
,p_plugin=>'NATIVE_YES_NO'
,p_attribute_01=>'Y'
,p_attribute_03=>'N'
);
end;
/
prompt --application/shared_components/security/authorizations
begin
null;
end;
/
prompt --application/shared_components/navigation/navigation_bar
begin
wwv_flow_api.create_icon_bar_item(
 p_id=>788853106698209426+wwv_flow_api.g_id_offset
,p_icon_sequence=>200
,p_icon_subtext=>'Logout'
,p_icon_target=>'&LOGOUT_URL.'
,p_icon_image_alt=>'Logout'
,p_icon_height=>32
,p_icon_width=>32
,p_icon_height2=>24
,p_icon_width2=>24
,p_nav_entry_is_feedback_yn=>'N'
,p_cell_colspan=>1
);
end;
/
prompt --application/shared_components/logic/application_processes
begin
null;
end;
/
prompt --application/shared_components/logic/application_items
begin
null;
end;
/
prompt --application/shared_components/logic/application_computations
begin
null;
end;
/
prompt --application/shared_components/navigation/tabs/standard
begin
null;
end;
/
prompt --application/shared_components/navigation/tabs/parent
begin
null;
end;
/
prompt --application/shared_components/user_interface/lovs
begin
wwv_flow_api.create_list_of_values(
 p_id=>891985611272348090+wwv_flow_api.g_id_offset
,p_lov_name=>'MC ARMOR'
,p_lov_query=>'.'||to_char(891985611272348090 + wwv_flow_api.g_id_offset)||'.'
);
wwv_flow_api.create_static_lov_data(
 p_id=>891985989451348090+wwv_flow_api.g_id_offset
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Helmet'
,p_lov_return_value=>'Helmet'
);
wwv_flow_api.create_static_lov_data(
 p_id=>891986249246348091+wwv_flow_api.g_id_offset
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Chestplate'
,p_lov_return_value=>'Chestplate'
);
wwv_flow_api.create_static_lov_data(
 p_id=>891987497391351715+wwv_flow_api.g_id_offset
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Legging'
,p_lov_return_value=>'Legging'
);
wwv_flow_api.create_static_lov_data(
 p_id=>891987755060351716+wwv_flow_api.g_id_offset
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Boot'
,p_lov_return_value=>'Boot'
);
wwv_flow_api.create_list_of_values(
 p_id=>891995791622360621+wwv_flow_api.g_id_offset
,p_lov_name=>'MC FOOD'
,p_lov_query=>'.'||to_char(891995791622360621 + wwv_flow_api.g_id_offset)||'.'
);
wwv_flow_api.create_static_lov_data(
 p_id=>891996092275360622+wwv_flow_api.g_id_offset
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Food'
,p_lov_return_value=>'Food'
);
wwv_flow_api.create_list_of_values(
 p_id=>891988257313356444+wwv_flow_api.g_id_offset
,p_lov_name=>'MC TOOL'
,p_lov_query=>'.'||to_char(891988257313356444 + wwv_flow_api.g_id_offset)||'.'
);
wwv_flow_api.create_static_lov_data(
 p_id=>891988554184356445+wwv_flow_api.g_id_offset
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Pickaxe'
,p_lov_return_value=>'Pickaxe'
);
wwv_flow_api.create_static_lov_data(
 p_id=>891988867690356447+wwv_flow_api.g_id_offset
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Axe'
,p_lov_return_value=>'Axe'
);
wwv_flow_api.create_static_lov_data(
 p_id=>891989110709356447+wwv_flow_api.g_id_offset
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Shovel'
,p_lov_return_value=>'Shovel'
);
wwv_flow_api.create_static_lov_data(
 p_id=>891989499919356447+wwv_flow_api.g_id_offset
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'Hoe'
,p_lov_return_value=>'Hoe'
);
wwv_flow_api.create_list_of_values(
 p_id=>891984897976346886+wwv_flow_api.g_id_offset
,p_lov_name=>'MC WEAPON'
,p_lov_query=>'.'||to_char(891984897976346886 + wwv_flow_api.g_id_offset)||'.'
);
wwv_flow_api.create_static_lov_data(
 p_id=>891985150595346887+wwv_flow_api.g_id_offset
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Sword'
,p_lov_return_value=>'Sword'
);
wwv_flow_api.create_static_lov_data(
 p_id=>891985400129346888+wwv_flow_api.g_id_offset
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Bow'
,p_lov_return_value=>'Bow'
);
wwv_flow_api.create_list_of_values(
 p_id=>886236742447910585+wwv_flow_api.g_id_offset
,p_lov_name=>'MC_AVATAR'
,p_lov_query=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select name as d,',
'       id as r',
'  from mc_avatar',
' order by 1'))
);
wwv_flow_api.create_list_of_values(
 p_id=>886236979685914055+wwv_flow_api.g_id_offset
,p_lov_name=>'MC_CHUNK'
,p_lov_query=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select name as d,',
'       id as r',
'  from mc_chunk',
' order by 1'))
);
wwv_flow_api.create_list_of_values(
 p_id=>886237190105916053+wwv_flow_api.g_id_offset
,p_lov_name=>'MC_MATERIAL'
,p_lov_query=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select name as d,',
'       id as r',
'  from mc_material',
' order by 1'))
);
wwv_flow_api.create_list_of_values(
 p_id=>886236450444902265+wwv_flow_api.g_id_offset
,p_lov_name=>'MC_PLAYER'
,p_lov_query=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select first_name || '' '' || last_name as d,',
'       id as r',
'  from mc_player',
' order by 1'))
);
end;
/
prompt --application/shared_components/navigation/trees
begin
null;
end;
/
prompt --application/pages/page_groups
begin
null;
end;
/
prompt --application/comments
begin
null;
end;
/
prompt --application/pages/page_00001
begin
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Home'
,p_page_mode=>'NORMAL'
,p_step_title=>'Home'
,p_step_sub_title=>'Home'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_cache_timeout_seconds=>21600
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'LULULIU820@UTEXAS.EDU'
,p_last_upd_yyyymmddhh24miss=>'20141124054158'
);
wwv_flow_api.create_page_plug(
 p_id=>789475571354778286+wwv_flow_api.g_id_offset
,p_plug_name=>'Group Members'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'Darius Xu',
'Lulu Liu'))
,p_plug_query_row_template=>1
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
end;
/
prompt --application/pages/page_00002
begin
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Players'
,p_page_mode=>'NORMAL'
,p_step_title=>'Players'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123071016'
);
wwv_flow_api.create_page_plug(
 p_id=>886151111620971222+wwv_flow_api.g_id_offset
,p_plug_name=>'Players_Report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>788835768975205834+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"FIRST_NAME",',
'"LAST_NAME",',
'"IP_ADDRESS",',
'"DEFAULT_LANG",',
'"MC_AVATAR_ID"',
'from "#OWNER#"."MC_PLAYER"',
'order by ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_row_template=>1
,p_prn_output_show_link=>'Y'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_document_header=>'APEX'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#ffffff'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_api.create_worksheet(
 p_id=>886151313014971222+wwv_flow_api.g_id_offset
,p_name=>'Players_Report'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_sql_query=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"FIRST_NAME",',
'"LAST_NAME",',
'"IP_ADDRESS",',
'"DEFAULT_LANG",',
'"MC_AVATAR_ID"',
'from "#OWNER#"."MC_PLAYER"',
'order by ID'))
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.::P32_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#e2.gif"  border="0">'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'DARIUSGXU@GMAIL.COM'
,p_internal_uid=>886151313014971222
);
wwv_flow_api.create_worksheet_column(
 p_id=>886151469699971223+wwv_flow_api.g_id_offset
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_link=>'f?p=&APP_ID.:62:&SESSION.::&DEBUG.::P62_ID:#ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#magnifying_glass_white_bg.gif" alt="">'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>892497338480496094+wwv_flow_api.g_id_offset
,p_db_column_name=>'FIRST_NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'First Name'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>892497468954496094+wwv_flow_api.g_id_offset
,p_db_column_name=>'LAST_NAME'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Last Name'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>892497550958496094+wwv_flow_api.g_id_offset
,p_db_column_name=>'IP_ADDRESS'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'IP Address'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>892497652791496094+wwv_flow_api.g_id_offset
,p_db_column_name=>'DEFAULT_LANG'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Default Language'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>892497794638496094+wwv_flow_api.g_id_offset
,p_db_column_name=>'MC_AVATAR_ID'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Avatar ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>886173221151973026+wwv_flow_api.g_id_offset
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8861733'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'ID:FIRST_NAME:LAST_NAME:IP_ADDRESS:DEFAULT_LANG:MC_AVATAR_ID'
,p_flashback_enabled=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>886172495039971226+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>886151111620971222+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create New Player'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:32::'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>886172091631971225+wwv_flow_api.g_id_offset
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>886151111620971222+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>886172304410971226+wwv_flow_api.g_id_offset
,p_event_id=>886172091631971225+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>886151111620971222+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>886172698849971226+wwv_flow_api.g_id_offset
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>886172495039971226+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>886172928014971226+wwv_flow_api.g_id_offset
,p_event_id=>886172698849971226+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>886151111620971222+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
end;
/
prompt --application/pages/page_00003
begin
wwv_flow_api.create_page(
 p_id=>3
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Avatars'
,p_page_mode=>'NORMAL'
,p_step_title=>'Avatars'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123055530'
);
wwv_flow_api.create_page_plug(
 p_id=>886213754486786261+wwv_flow_api.g_id_offset
,p_plug_name=>'Avatars_Report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>788835768975205834+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"NAME",',
'"HEALTH",',
'"CURRENT_SPAWN",',
'"HUNGER",',
'"EXPERIENCE",',
'"MC_PLAYER_ID"',
'from "#OWNER#"."MC_AVATAR"',
'order by ID ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_row_template=>1
);
wwv_flow_api.create_worksheet(
 p_id=>886213932921786261+wwv_flow_api.g_id_offset
,p_name=>'Avatars_Report'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_sql_query=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"NAME",',
'"HEALTH",',
'"CURRENT_SPAWN",',
'"HUNGER",',
'"EXPERIENCE",',
'"MC_PLAYER_ID"',
'from "#OWNER#"."MC_AVATAR"',
'order by ID ',
'  ',
''))
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.::P33_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#e2.gif"  border="0">'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'DARIUSGXU@GMAIL.COM'
,p_internal_uid=>886213932921786261
);
wwv_flow_api.create_worksheet_column(
 p_id=>886214065571786262+wwv_flow_api.g_id_offset
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_link=>'f?p=&APP_ID.:63:&SESSION.::&DEBUG.::P63_ID:#ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#magnifying_glass_white_bg.gif" alt="">'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>886214186263786263+wwv_flow_api.g_id_offset
,p_db_column_name=>'NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>886214206501786263+wwv_flow_api.g_id_offset
,p_db_column_name=>'HEALTH'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Health'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>886214315740786263+wwv_flow_api.g_id_offset
,p_db_column_name=>'CURRENT_SPAWN'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Current Spawn'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>886214483781786263+wwv_flow_api.g_id_offset
,p_db_column_name=>'HUNGER'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Hunger'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>886214526905786264+wwv_flow_api.g_id_offset
,p_db_column_name=>'EXPERIENCE'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Experience'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>886214605592786264+wwv_flow_api.g_id_offset
,p_db_column_name=>'MC_PLAYER_ID'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Player ID'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>886216057202789528+wwv_flow_api.g_id_offset
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8862161'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'ID:NAME:HEALTH:CURRENT_SPAWN:HUNGER:EXPERIENCE:MC_PLAYER_ID'
,p_flashback_enabled=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>886215166738786264+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>886213754486786261+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create New Avatar'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:33::'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>886214772962786264+wwv_flow_api.g_id_offset
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>886213754486786261+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>886215029354786264+wwv_flow_api.g_id_offset
,p_event_id=>886214772962786264+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>886213754486786261+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>886215328523786264+wwv_flow_api.g_id_offset
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>886215166738786264+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>886215655910786265+wwv_flow_api.g_id_offset
,p_event_id=>886215328523786264+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>886213754486786261+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
end;
/
prompt --application/pages/page_00004
begin
wwv_flow_api.create_page(
 p_id=>4
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Materials'
,p_page_mode=>'NORMAL'
,p_step_title=>'Materials'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'LULULIU820@UTEXAS.EDU'
,p_last_upd_yyyymmddhh24miss=>'20141124061754'
);
wwv_flow_api.create_page_plug(
 p_id=>891092740180278048+wwv_flow_api.g_id_offset
,p_plug_name=>'Materials_Report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>788835768975205834+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"NAME"',
'from "#OWNER#"."MC_MATERIAL"',
'order by ID ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_row_template=>1
);
wwv_flow_api.create_worksheet(
 p_id=>891092992188278048+wwv_flow_api.g_id_offset
,p_name=>'Materials_Report'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_sql_query=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"NAME"',
'from "#OWNER#"."MC_MATERIAL"',
'order by ID ',
'  ',
''))
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.::P34_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#e2.gif"  border="0">'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'DARIUSGXU@GMAIL.COM'
,p_internal_uid=>891092992188278048
);
wwv_flow_api.create_worksheet_column(
 p_id=>891093085182278049+wwv_flow_api.g_id_offset
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_link=>'f?p=&APP_ID.:64:&SESSION.::&DEBUG.::P64_ID:#ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#magnifying_glass_white_bg.gif" alt="">'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891093117867278050+wwv_flow_api.g_id_offset
,p_db_column_name=>'NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>891095327864300918+wwv_flow_api.g_id_offset
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8910954'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'ID:NAME'
,p_flashback_enabled=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>891093650962278051+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>891092740180278048+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create New Material'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:34:&SESSION.::&DEBUG.:34::'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>891093299851278050+wwv_flow_api.g_id_offset
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>891092740180278048+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>891093593111278050+wwv_flow_api.g_id_offset
,p_event_id=>891093299851278050+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>891092740180278048+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>891093818810278051+wwv_flow_api.g_id_offset
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>891093650962278051+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>891094159267278051+wwv_flow_api.g_id_offset
,p_event_id=>891093818810278051+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>891092740180278048+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
end;
/
prompt --application/pages/page_00005
begin
wwv_flow_api.create_page(
 p_id=>5
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Chunks'
,p_page_mode=>'NORMAL'
,p_step_title=>'Chunks'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123055622'
);
wwv_flow_api.create_page_plug(
 p_id=>891100374164328379+wwv_flow_api.g_id_offset
,p_plug_name=>'Chunks_Report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>788835768975205834+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"NAME"',
'from "#OWNER#"."MC_CHUNK"',
'order by ID ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_row_template=>1
);
wwv_flow_api.create_worksheet(
 p_id=>891100523539328379+wwv_flow_api.g_id_offset
,p_name=>'Chunks_Report'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_sql_query=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"NAME"',
'from "#OWNER#"."MC_CHUNK"',
'order by ID ',
'  ',
''))
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.::P35_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#e2.gif"  border="0">'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'DARIUSGXU@GMAIL.COM'
,p_internal_uid=>891100523539328379
);
wwv_flow_api.create_worksheet_column(
 p_id=>891100694048328380+wwv_flow_api.g_id_offset
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_link=>'f?p=&APP_ID.:65:&SESSION.::&DEBUG.::P65_ID:#ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#magnifying_glass_white_bg.gif" alt="">'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891100743424328381+wwv_flow_api.g_id_offset
,p_db_column_name=>'NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>891102320330336762+wwv_flow_api.g_id_offset
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8911024'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'ID:NAME'
,p_flashback_enabled=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>891101245198328381+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>891100374164328379+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create New Chunk'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:35::'
);
wwv_flow_api.create_page_da_event(
 p_id=>891100884922328381+wwv_flow_api.g_id_offset
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>891100374164328379+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>891101139428328381+wwv_flow_api.g_id_offset
,p_event_id=>891100884922328381+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>891100374164328379+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>891101437910328382+wwv_flow_api.g_id_offset
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>891101245198328381+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>891101743191328382+wwv_flow_api.g_id_offset
,p_event_id=>891101437910328382+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>891100374164328379+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
end;
/
prompt --application/pages/page_00006
begin
wwv_flow_api.create_page(
 p_id=>6
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Documents'
,p_page_mode=>'NORMAL'
,p_step_title=>'Documents'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141124030528'
);
wwv_flow_api.create_report_region(
 p_id=>898382780945997146+wwv_flow_api.g_id_offset
,p_name=>'Player Documents'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select d."ID",',
'd."FILE_NAME",',
'dbms_lob.getlength("FILE_DATA") "FILE_DATA",',
'dbms_lob.getlength("FILE_DATA") "Download",',
'd."FILE_COMMENTS",',
'd."TAGS",',
'p."FIRST_NAME" || '' '' || p."LAST_NAME" as "Player Name"',
'from "#OWNER#"."MC_DOCUMENT" d',
'join MC_PLAYER p',
'on  d.mc_player_id=p.id',
'  ',
''))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>788840920131206733+wwv_flow_api.g_id_offset
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>898383029833997147+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>' '
,p_column_link=>'f?p=#APP_ID#:36:#APP_SESSION#::::P36_ID:#ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#e2.gif"  border="0">'
,p_disable_sort_column=>'N'
,p_ref_schema=>'CS347_DARIUS_XU_SCHEMA'
,p_ref_table_name=>'MC_DOCUMENT'
,p_ref_column_name=>'ID'
);
wwv_flow_api.create_report_columns(
 p_id=>898383102815997148+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'FILE_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'File Name'
,p_use_as_row_header=>'N'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
,p_ref_schema=>'CS347_DARIUS_XU_SCHEMA'
,p_ref_table_name=>'MC_DOCUMENT'
,p_ref_column_name=>'FILE_NAME'
);
wwv_flow_api.create_report_columns(
 p_id=>898383468259997148+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'FILE_DATA'
,p_column_display_sequence=>3
,p_column_heading=>'File Data'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:66:&SESSION.::&DEBUG.::P66_ID:#ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#magnifying_glass_white_bg.gif" alt="">'
,p_disable_sort_column=>'N'
,p_lov_show_nulls=>'NO'
,p_derived_column=>'N'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
,p_ref_schema=>'CS347_DARIUS_XU_SCHEMA'
,p_ref_table_name=>'MC_DOCUMENT'
,p_ref_column_name=>'FILE_DATA'
);
wwv_flow_api.create_report_columns(
 p_id=>899449397845840211+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'Download'
,p_column_display_sequence=>7
,p_column_heading=>'Download'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:MC_DOCUMENT:FILE_DATA:ID::FILE_MIMETYPE:FILE_NAME::FILE_CHARSET:Attachment:Download:'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>898383567450997148+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'FILE_COMMENTS'
,p_column_display_sequence=>4
,p_column_heading=>'File Comments'
,p_disable_sort_column=>'N'
,p_ref_schema=>'CS347_DARIUS_XU_SCHEMA'
,p_ref_table_name=>'MC_DOCUMENT'
,p_ref_column_name=>'FILE_COMMENTS'
);
wwv_flow_api.create_report_columns(
 p_id=>898383609070997148+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'TAGS'
,p_column_display_sequence=>5
,p_column_heading=>'Tags'
,p_disable_sort_column=>'N'
,p_ref_schema=>'CS347_DARIUS_XU_SCHEMA'
,p_ref_table_name=>'MC_DOCUMENT'
,p_ref_column_name=>'TAGS'
);
wwv_flow_api.create_report_columns(
 p_id=>898403499879009630+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'Player Name'
,p_column_display_sequence=>6
,p_column_heading=>'Player Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>898384278112997149+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>898382780945997146+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add New Document'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_redirect_url=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:36::'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>898383848255997148+wwv_flow_api.g_id_offset
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>898382780945997146+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>898384197065997149+wwv_flow_api.g_id_offset
,p_event_id=>898383848255997148+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>898382780945997146+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>898384431392997149+wwv_flow_api.g_id_offset
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>898384278112997149+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>898384712333997149+wwv_flow_api.g_id_offset
,p_event_id=>898384431392997149+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>898382780945997146+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
end;
/
prompt --application/pages/page_00007
begin
wwv_flow_api.create_page(
 p_id=>7
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Weapons'
,p_page_mode=>'NORMAL'
,p_step_title=>'Weapons'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123055732'
);
wwv_flow_api.create_page_plug(
 p_id=>891922359522938486+wwv_flow_api.g_id_offset
,p_plug_name=>'Weapons_Report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>788835768975205834+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"NAME",',
'"TYPE",',
'"AMOUNT",',
'"MC_AVATAR_ID",',
'"DURABILITY",',
'"DAMAGE",',
'"MC_MATERIAL_ID"',
'from "#OWNER#"."MC_WEAPON"',
'where type=''Sword'' or type=''Bow''',
'order by ID ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_row_template=>1
);
wwv_flow_api.create_worksheet(
 p_id=>891922513392938486+wwv_flow_api.g_id_offset
,p_name=>'Weapons_Report'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_sql_query=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"NAME",',
'"TYPE",',
'"AMOUNT",',
'"MC_AVATAR_ID",',
'"DURABILITY",',
'"DAMAGE",',
'"MC_MATERIAL_ID"',
'from "#OWNER#"."MC_WEAPON"',
'where type=''Sword'' or type=''Bow''',
'order by ID ',
'  ',
''))
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.::P37_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#e2.gif"  border="0">'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'DARIUSGXU@GMAIL.COM'
,p_internal_uid=>891922513392938486
);
wwv_flow_api.create_worksheet_column(
 p_id=>891922619874938488+wwv_flow_api.g_id_offset
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_link=>'f?p=&APP_ID.:67:&SESSION.::&DEBUG.::P67_ID:#ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#magnifying_glass_white_bg.gif" alt="">'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891922771068938489+wwv_flow_api.g_id_offset
,p_db_column_name=>'NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891922867006938489+wwv_flow_api.g_id_offset
,p_db_column_name=>'TYPE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Type'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891922956518938490+wwv_flow_api.g_id_offset
,p_db_column_name=>'AMOUNT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Amount'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891923072113938490+wwv_flow_api.g_id_offset
,p_db_column_name=>'MC_AVATAR_ID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Owner ID'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891923170392938490+wwv_flow_api.g_id_offset
,p_db_column_name=>'DURABILITY'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Durability'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891923249695938490+wwv_flow_api.g_id_offset
,p_db_column_name=>'DAMAGE'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Damage'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891923306879938490+wwv_flow_api.g_id_offset
,p_db_column_name=>'MC_MATERIAL_ID'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Material ID'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>891926495895942712+wwv_flow_api.g_id_offset
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8919265'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'ID:NAME:TYPE:AMOUNT:MC_AVATAR_ID:DURABILITY:DAMAGE:MC_MATERIAL_ID'
,p_flashback_enabled=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>891923890075938491+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>891922359522938486+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create New Weapon'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:37::'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>891923486245938490+wwv_flow_api.g_id_offset
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>891922359522938486+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>891923724095938491+wwv_flow_api.g_id_offset
,p_event_id=>891923486245938490+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>891922359522938486+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>891924046019938491+wwv_flow_api.g_id_offset
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>891923890075938491+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>891924342627938491+wwv_flow_api.g_id_offset
,p_event_id=>891924046019938491+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>891922359522938486+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
end;
/
prompt --application/pages/page_00008
begin
wwv_flow_api.create_page(
 p_id=>8
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Armors'
,p_page_mode=>'NORMAL'
,p_step_title=>'Armors'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123055838'
);
wwv_flow_api.create_page_plug(
 p_id=>891943680517950656+wwv_flow_api.g_id_offset
,p_plug_name=>'Armors_Report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>788835768975205834+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"NAME",',
'"TYPE",',
'"AMOUNT",',
'"MC_AVATAR_ID",',
'"DURABILITY",',
'"ARMOR",',
'"MC_MATERIAL_ID"',
'from "#OWNER#"."MC_ARMOR"',
'where type=''Helmet'' or type=''Chestplate'' or type=''Legging'' or type=''Boot''',
'order by ID ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_row_template=>1
);
wwv_flow_api.create_worksheet(
 p_id=>891943841863950656+wwv_flow_api.g_id_offset
,p_name=>'Armors_Report'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_sql_query=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"NAME",',
'"TYPE",',
'"AMOUNT",',
'"MC_AVATAR_ID",',
'"DURABILITY",',
'"ARMOR",',
'"MC_MATERIAL_ID"',
'from "#OWNER#"."MC_ARMOR"',
'where type=''Helmet'' or type=''Chestplate'' or type=''Legging'' or type=''Boot''',
'order by ID ',
'  ',
''))
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.::P38_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#e2.gif"  border="0">'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'DARIUSGXU@GMAIL.COM'
,p_internal_uid=>891943841863950656
);
wwv_flow_api.create_worksheet_column(
 p_id=>891943993754950657+wwv_flow_api.g_id_offset
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_link=>'f?p=&APP_ID.:68:&SESSION.::&DEBUG.::P68_ID:#ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#magnifying_glass_white_bg.gif" alt="">'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891944046230950658+wwv_flow_api.g_id_offset
,p_db_column_name=>'NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891944160128950659+wwv_flow_api.g_id_offset
,p_db_column_name=>'TYPE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Type'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891944280404950659+wwv_flow_api.g_id_offset
,p_db_column_name=>'AMOUNT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Amount'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891944312648950659+wwv_flow_api.g_id_offset
,p_db_column_name=>'MC_AVATAR_ID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Owner ID'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891944437196950659+wwv_flow_api.g_id_offset
,p_db_column_name=>'DURABILITY'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Durability'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891944512608950659+wwv_flow_api.g_id_offset
,p_db_column_name=>'ARMOR'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Armor'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891944653219950660+wwv_flow_api.g_id_offset
,p_db_column_name=>'MC_MATERIAL_ID'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Material ID'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>892013726050398147+wwv_flow_api.g_id_offset
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8920138'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'ID:NAME:TYPE:AMOUNT:MC_AVATAR_ID:DURABILITY:ARMOR:MC_MATERIAL_ID'
,p_flashback_enabled=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>891945146882950660+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>891943680517950656+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create New Armor'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:38'
);
wwv_flow_api.create_page_da_event(
 p_id=>891944765561950660+wwv_flow_api.g_id_offset
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>891943680517950656+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>891945095475950660+wwv_flow_api.g_id_offset
,p_event_id=>891944765561950660+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>891943680517950656+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>891945389796950661+wwv_flow_api.g_id_offset
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>891945146882950660+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>891945672856950661+wwv_flow_api.g_id_offset
,p_event_id=>891945389796950661+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>891943680517950656+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
end;
/
prompt --application/pages/page_00009
begin
wwv_flow_api.create_page(
 p_id=>9
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Tools'
,p_page_mode=>'NORMAL'
,p_step_title=>'Tools'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123105628'
);
wwv_flow_api.create_page_plug(
 p_id=>892844759762920961+wwv_flow_api.g_id_offset
,p_plug_name=>'Tools_Report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>788835768975205834+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"NAME",',
'"TYPE",',
'"AMOUNT",',
'"MC_AVATAR_ID",',
'"DURABILITY",',
'"MC_MATERIAL_ID"',
'from "#OWNER#"."MC_TOOL"',
'where type=''Pickaxe'' or type=''Axe'' or type=''Shovel'' or type=''Hoe''',
'order by ID ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_row_template=>1
);
wwv_flow_api.create_worksheet(
 p_id=>892844971267920961+wwv_flow_api.g_id_offset
,p_name=>'Tools_Report'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_sql_query=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"NAME",',
'"TYPE",',
'"AMOUNT",',
'"MC_AVATAR_ID",',
'"DURABILITY",',
'"MC_MATERIAL_ID"',
'from "#OWNER#"."MC_TOOL"',
'where type=''Pickaxe'' or type=''Axe'' or type=''Shovel'' or type=''Hoe''',
'order by ID ',
'  ',
''))
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.::P39_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#e2.gif"  border="0">'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'DARIUSGXU@GMAIL.COM'
,p_internal_uid=>892844971267920961
);
wwv_flow_api.create_worksheet_column(
 p_id=>892845041565920963+wwv_flow_api.g_id_offset
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_link=>'f?p=&APP_ID.:69:&SESSION.::&DEBUG.::P69_ID:#ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#magnifying_glass_white_bg.gif" alt="">'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>892845115052920965+wwv_flow_api.g_id_offset
,p_db_column_name=>'NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>892845261850920965+wwv_flow_api.g_id_offset
,p_db_column_name=>'TYPE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Type'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>892845324447920966+wwv_flow_api.g_id_offset
,p_db_column_name=>'AMOUNT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Amount'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>892845458642920966+wwv_flow_api.g_id_offset
,p_db_column_name=>'MC_AVATAR_ID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Owner ID'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>892845590324920966+wwv_flow_api.g_id_offset
,p_db_column_name=>'DURABILITY'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Durability'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>892845688801920966+wwv_flow_api.g_id_offset
,p_db_column_name=>'MC_MATERIAL_ID'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Material ID'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>892860804794931987+wwv_flow_api.g_id_offset
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8928609'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'ID:NAME:TYPE:AMOUNT:MC_AVATAR_ID:DURABILITY:MC_MATERIAL_ID'
,p_flashback_enabled=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>892846152824920967+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>892844759762920961+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create New Tool'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:39::'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>892845731364920966+wwv_flow_api.g_id_offset
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>892844759762920961+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>892846001758920967+wwv_flow_api.g_id_offset
,p_event_id=>892845731364920966+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>892844759762920961+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>892846363242920968+wwv_flow_api.g_id_offset
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>892846152824920967+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>892846647574920968+wwv_flow_api.g_id_offset
,p_event_id=>892846363242920968+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>892844759762920961+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
end;
/
prompt --application/pages/page_00010
begin
wwv_flow_api.create_page(
 p_id=>10
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Food'
,p_page_mode=>'NORMAL'
,p_step_title=>'Food'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123055954'
);
wwv_flow_api.create_page_plug(
 p_id=>891957001541968915+wwv_flow_api.g_id_offset
,p_plug_name=>'Food_Report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>788835768975205834+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"NAME",',
'"TYPE",',
'"AMOUNT",',
'"MC_AVATAR_ID",',
'"FOOD",',
'"SATURATION"',
'from "#OWNER#"."MC_FOOD"',
'where type=''Food''',
'order by ID ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_row_template=>1
);
wwv_flow_api.create_worksheet(
 p_id=>891957224820968915+wwv_flow_api.g_id_offset
,p_name=>'Food_Report'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_sql_query=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select "ID", ',
'"NAME",',
'"TYPE",',
'"AMOUNT",',
'"MC_AVATAR_ID",',
'"FOOD",',
'"SATURATION"',
'from "#OWNER#"."MC_FOOD"',
'where type=''Food''',
'order by ID ',
'  ',
''))
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.::P40_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#e2.gif"  border="0">'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'DARIUSGXU@GMAIL.COM'
,p_internal_uid=>891957224820968915
);
wwv_flow_api.create_worksheet_column(
 p_id=>891957387500968917+wwv_flow_api.g_id_offset
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_link=>'f?p=&APP_ID.:70:&SESSION.::&DEBUG.::P70_ID:#ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#magnifying_glass_white_bg.gif" alt="">'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891957496789968918+wwv_flow_api.g_id_offset
,p_db_column_name=>'NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Name'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891957541252968919+wwv_flow_api.g_id_offset
,p_db_column_name=>'TYPE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Type'
,p_column_type=>'STRING'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891957671768968919+wwv_flow_api.g_id_offset
,p_db_column_name=>'AMOUNT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Amount'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891957726956968919+wwv_flow_api.g_id_offset
,p_db_column_name=>'MC_AVATAR_ID'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Owner ID'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891957853746968919+wwv_flow_api.g_id_offset
,p_db_column_name=>'FOOD'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Food'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>891957982847968919+wwv_flow_api.g_id_offset
,p_db_column_name=>'SATURATION'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Saturation'
,p_column_type=>'NUMBER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>892090660964373497+wwv_flow_api.g_id_offset
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8920907'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'ID:NAME:TYPE:AMOUNT:MC_AVATAR_ID:FOOD:SATURATION'
,p_flashback_enabled=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>891958417082968920+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>891957001541968915+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create New Food'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:40'
);
wwv_flow_api.create_page_da_event(
 p_id=>891958002170968920+wwv_flow_api.g_id_offset
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>891957001541968915+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>891958348909968920+wwv_flow_api.g_id_offset
,p_event_id=>891958002170968920+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>891957001541968915+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_da_event(
 p_id=>891958661661968921+wwv_flow_api.g_id_offset
,p_name=>'Create Button - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>891958417082968920+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>891958934674968921+wwv_flow_api.g_id_offset
,p_event_id=>891958661661968921+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>891957001541968915+wwv_flow_api.g_id_offset
,p_stop_execution_on_error=>'Y'
);
end;
/
prompt --application/pages/page_00011
begin
wwv_flow_api.create_page(
 p_id=>11
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Ownership'
,p_page_mode=>'NORMAL'
,p_step_title=>'Ownership'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123225915'
);
wwv_flow_api.create_page_plug(
 p_id=>891247625736591631+wwv_flow_api.g_id_offset
,p_plug_name=>'Ownership_Report'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>788835768975205834+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select o."ID", ',
'a."NAME" as "Avatar",',
'c."NAME" as "Chunk"',
'from "#OWNER#"."MC_OWNERSHIP" o',
'join MC_AVATAR a on o.mc_avatar_id=a.id',
'join MC_CHUNK c on o.mc_chunk_id=c.id',
'order by ID ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_row_template=>1
);
wwv_flow_api.create_worksheet(
 p_id=>891247860052591631+wwv_flow_api.g_id_offset
,p_name=>'Ownership_Report'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_sql_query=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select o."ID", ',
'a."NAME" as "Avatar",',
'c."NAME" as "Chunk"',
'from "#OWNER#"."MC_OWNERSHIP" o',
'join MC_AVATAR a on o.mc_avatar_id=a.id',
'join MC_CHUNK c on o.mc_chunk_id=c.id',
'order by ID ',
'  ',
''))
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_show_detail_link=>'C'
,p_show_calendar=>'N'
,p_download_formats=>'CSV:HTML:EMAIL:XLS:PDF:RTF'
,p_detail_link=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.::P41_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#e2.gif"  border="0">'
,p_allow_exclude_null_values=>'N'
,p_allow_hide_extra_columns=>'N'
,p_icon_view_columns_per_row=>1
,p_owner=>'DARIUSGXU@GMAIL.COM'
,p_internal_uid=>891247860052591631
);
wwv_flow_api.create_worksheet_column(
 p_id=>891247972495591632+wwv_flow_api.g_id_offset
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_link=>'f?p=&APP_ID.:71:&SESSION.::&DEBUG.::P71_ID:#ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#magnifying_glass_white_bg.gif" alt="">'
,p_column_type=>'NUMBER'
);
wwv_flow_api.create_worksheet_column(
 p_id=>896774139312462121+wwv_flow_api.g_id_offset
,p_db_column_name=>'Avatar'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Owner'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_column(
 p_id=>896774260743462122+wwv_flow_api.g_id_offset
,p_db_column_name=>'Chunk'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Chunk'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
);
wwv_flow_api.create_worksheet_rpt(
 p_id=>891221655308899003+wwv_flow_api.g_id_offset
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'8912217'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'ID:Avatar:Chunk'
,p_flashback_enabled=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>891248298190591633+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>891247625736591631+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Associate New Ownership'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:41::'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
end;
/
prompt --application/pages/page_00032
begin
wwv_flow_api.create_page(
 p_id=>32
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Form on MC_PLAYER'
,p_page_mode=>'MODAL'
,p_step_title=>'Form'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_cache_timeout_seconds=>21600
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141124005422'
);
wwv_flow_api.create_page_plug(
 p_id=>886146865483971198+wwv_flow_api.g_id_offset
,p_plug_name=>'Create New Player'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_query_row_template=>1
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>898291493468127347+wwv_flow_api.g_id_offset
,p_button_sequence=>70
,p_button_plug_id=>886146865483971198+wwv_flow_api.g_id_offset
,p_button_name=>'P32_CREATE_NEW_AVATAR'
,p_button_static_id=>'P32_CREATE_NEW_AVATAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--small'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Create New Avatar'
,p_button_position=>'BODY'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:33::'
,p_grid_new_grid=>false
,p_grid_new_row=>'Y'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>886147166495971199+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>886146865483971198+wwv_flow_api.g_id_offset
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P32_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>886147308848971199+wwv_flow_api.g_id_offset
,p_button_sequence=>10
,p_button_plug_id=>886146865483971198+wwv_flow_api.g_id_offset
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_grid_new_grid=>false
);
wwv_flow_api.create_page_button(
 p_id=>886147084207971199+wwv_flow_api.g_id_offset
,p_button_sequence=>40
,p_button_plug_id=>886146865483971198+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P32_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_grid=>false
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>886147268225971199+wwv_flow_api.g_id_offset
,p_button_sequence=>20
,p_button_plug_id=>886146865483971198+wwv_flow_api.g_id_offset
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Delete'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P32_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>886148405227971202+wwv_flow_api.g_id_offset
,p_branch_action=>'f?p=&APP_ID.:2:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>886148629802971216+wwv_flow_api.g_id_offset
,p_name=>'P32_ID'
,p_item_sequence=>10
,p_item_plug_id=>886146865483971198+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>886148810293971217+wwv_flow_api.g_id_offset
,p_name=>'P32_FIRST_NAME'
,p_item_sequence=>20
,p_item_plug_id=>886146865483971198+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'First Name'
,p_source=>'FIRST_NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>256
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>886149098683971217+wwv_flow_api.g_id_offset
,p_name=>'P32_LAST_NAME'
,p_item_sequence=>30
,p_item_plug_id=>886146865483971198+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Last Name'
,p_source=>'LAST_NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>256
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>886149283844971218+wwv_flow_api.g_id_offset
,p_name=>'P32_IP_ADDRESS'
,p_item_sequence=>40
,p_item_plug_id=>886146865483971198+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'IP Address'
,p_source=>'IP_ADDRESS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>64
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>886149423784971218+wwv_flow_api.g_id_offset
,p_name=>'P32_DEFAULT_LANG'
,p_item_sequence=>50
,p_item_plug_id=>886146865483971198+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Default Language'
,p_source=>'DEFAULT_LANG'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>256
,p_cHeight=>4
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>886149687721971218+wwv_flow_api.g_id_offset
,p_name=>'P32_MC_AVATAR_ID'
,p_item_sequence=>60
,p_item_plug_id=>886146865483971198+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Avatar'
,p_source=>'MC_AVATAR_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'MC_AVATAR'
,p_lov=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select name as d,',
'       id as r',
'  from mc_avatar',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>886147482089971199+wwv_flow_api.g_id_offset
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>886147308848971199+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>886147840578971201+wwv_flow_api.g_id_offset
,p_event_id=>886147482089971199+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>886150012240971219+wwv_flow_api.g_id_offset
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from MC_PLAYER'
,p_attribute_02=>'MC_PLAYER'
,p_attribute_03=>'P32_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>886150213940971220+wwv_flow_api.g_id_offset
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of MC_PLAYER'
,p_attribute_02=>'MC_PLAYER'
,p_attribute_03=>'P32_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
);
wwv_flow_api.create_page_process(
 p_id=>886150464903971220+wwv_flow_api.g_id_offset
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>886147268225971199+wwv_flow_api.g_id_offset
);
wwv_flow_api.create_page_process(
 p_id=>886150676744971220+wwv_flow_api.g_id_offset
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
end;
/
prompt --application/pages/page_00033
begin
wwv_flow_api.create_page(
 p_id=>33
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Form on MC_AVATAR'
,p_page_mode=>'MODAL'
,p_step_title=>'Form'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_cache_timeout_seconds=>21600
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141124005530'
);
wwv_flow_api.create_page_plug(
 p_id=>886209239421786235+wwv_flow_api.g_id_offset
,p_plug_name=>'Create New Avatar'
,p_region_template_options=>'#DEFAULT#:t-Region--defaultHeight:t-Region-scrollAuto'
,p_plug_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_query_row_template=>1
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>898310171601887796+wwv_flow_api.g_id_offset
,p_button_sequence=>80
,p_button_plug_id=>886209239421786235+wwv_flow_api.g_id_offset
,p_button_name=>'P33_CREATE_NEW_PLAYER'
,p_button_static_id=>'P33_CREATE_NEW_PLAYER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--small'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Create New Player'
,p_button_position=>'BODY'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:32::'
,p_grid_new_grid=>false
,p_grid_new_row=>'Y'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>886209597668786236+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>886209239421786235+wwv_flow_api.g_id_offset
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P33_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>886209782588786236+wwv_flow_api.g_id_offset
,p_button_sequence=>10
,p_button_plug_id=>886209239421786235+wwv_flow_api.g_id_offset
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_grid_new_grid=>false
);
wwv_flow_api.create_page_button(
 p_id=>886209434887786236+wwv_flow_api.g_id_offset
,p_button_sequence=>40
,p_button_plug_id=>886209239421786235+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P33_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_grid=>false
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>886209698726786236+wwv_flow_api.g_id_offset
,p_button_sequence=>20
,p_button_plug_id=>886209239421786235+wwv_flow_api.g_id_offset
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Delete'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P33_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>886210836424786238+wwv_flow_api.g_id_offset
,p_branch_action=>'f?p=&APP_ID.:3:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>886211038504786251+wwv_flow_api.g_id_offset
,p_name=>'P33_ID'
,p_item_sequence=>10
,p_item_plug_id=>886209239421786235+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>886211242493786257+wwv_flow_api.g_id_offset
,p_name=>'P33_NAME'
,p_item_sequence=>20
,p_item_plug_id=>886209239421786235+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Name'
,p_source=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>256
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>886211417810786257+wwv_flow_api.g_id_offset
,p_name=>'P33_HEALTH'
,p_item_sequence=>30
,p_item_plug_id=>886209239421786235+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Health'
,p_source=>'HEALTH'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>886211614898786258+wwv_flow_api.g_id_offset
,p_name=>'P33_CURRENT_SPAWN'
,p_item_sequence=>40
,p_item_plug_id=>886209239421786235+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Current Spawn'
,p_source=>'CURRENT_SPAWN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>64
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>886211817974786258+wwv_flow_api.g_id_offset
,p_name=>'P33_HUNGER'
,p_item_sequence=>50
,p_item_plug_id=>886209239421786235+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Hunger'
,p_source=>'HUNGER'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>886212045884786258+wwv_flow_api.g_id_offset
,p_name=>'P33_EXPERIENCE'
,p_item_sequence=>60
,p_item_plug_id=>886209239421786235+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Experience'
,p_source=>'EXPERIENCE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>886212245016786259+wwv_flow_api.g_id_offset
,p_name=>'P33_MC_PLAYER_ID'
,p_item_sequence=>70
,p_item_plug_id=>886209239421786235+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Player'
,p_source=>'MC_PLAYER_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'MC_PLAYER'
,p_lov=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select first_name || '' '' || last_name as d,',
'       id as r',
'  from mc_player',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>886209832862786236+wwv_flow_api.g_id_offset
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>886209782588786236+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>886210216334786237+wwv_flow_api.g_id_offset
,p_event_id=>886209832862786236+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>886212652960786259+wwv_flow_api.g_id_offset
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from MC_AVATAR'
,p_attribute_02=>'MC_AVATAR'
,p_attribute_03=>'P33_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>886212847680786260+wwv_flow_api.g_id_offset
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of MC_AVATAR'
,p_attribute_02=>'MC_AVATAR'
,p_attribute_03=>'P33_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
);
wwv_flow_api.create_page_process(
 p_id=>886213065248786260+wwv_flow_api.g_id_offset
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>886209698726786236+wwv_flow_api.g_id_offset
);
wwv_flow_api.create_page_process(
 p_id=>886213250047786260+wwv_flow_api.g_id_offset
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
end;
/
prompt --application/pages/page_00034
begin
wwv_flow_api.create_page(
 p_id=>34
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Form on MC_MATERIAL'
,p_page_mode=>'MODAL'
,p_step_title=>'Form'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_cache_timeout_seconds=>21600
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141122221501'
);
wwv_flow_api.create_page_plug(
 p_id=>891089248509278039+wwv_flow_api.g_id_offset
,p_plug_name=>'Create New Material'
,p_region_template_options=>'#DEFAULT#:t-Region--defaultHeight:t-Region-scrollAuto'
,p_plug_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_query_row_template=>1
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>891089562521278040+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>891089248509278039+wwv_flow_api.g_id_offset
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P34_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>891089783375278040+wwv_flow_api.g_id_offset
,p_button_sequence=>10
,p_button_plug_id=>891089248509278039+wwv_flow_api.g_id_offset
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_grid_new_grid=>false
);
wwv_flow_api.create_page_button(
 p_id=>891089409973278040+wwv_flow_api.g_id_offset
,p_button_sequence=>40
,p_button_plug_id=>891089248509278039+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P34_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_grid=>false
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>891089653217278040+wwv_flow_api.g_id_offset
,p_button_sequence=>20
,p_button_plug_id=>891089248509278039+wwv_flow_api.g_id_offset
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Delete'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P34_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>891090815685278043+wwv_flow_api.g_id_offset
,p_branch_action=>'f?p=&APP_ID.:4:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>891091055694278045+wwv_flow_api.g_id_offset
,p_name=>'P34_ID'
,p_item_sequence=>10
,p_item_plug_id=>891089248509278039+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>891091293477278046+wwv_flow_api.g_id_offset
,p_name=>'P34_NAME'
,p_item_sequence=>20
,p_item_plug_id=>891089248509278039+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Name'
,p_source=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>256
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>891089892690278040+wwv_flow_api.g_id_offset
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>891089783375278040+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>891090258241278042+wwv_flow_api.g_id_offset
,p_event_id=>891089892690278040+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>891091605224278046+wwv_flow_api.g_id_offset
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from MC_MATERIAL'
,p_attribute_02=>'MC_MATERIAL'
,p_attribute_03=>'P34_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>891091892960278047+wwv_flow_api.g_id_offset
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of MC_MATERIAL'
,p_attribute_02=>'MC_MATERIAL'
,p_attribute_03=>'P34_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
);
wwv_flow_api.create_page_process(
 p_id=>891092024469278047+wwv_flow_api.g_id_offset
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>891089653217278040+wwv_flow_api.g_id_offset
);
wwv_flow_api.create_page_process(
 p_id=>891092230089278047+wwv_flow_api.g_id_offset
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
end;
/
prompt --application/pages/page_00035
begin
wwv_flow_api.create_page(
 p_id=>35
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Form on MC_CHUNK'
,p_page_mode=>'MODAL'
,p_step_title=>'Form'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_cache_timeout_seconds=>21600
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141122222220'
);
wwv_flow_api.create_page_plug(
 p_id=>891096820124328369+wwv_flow_api.g_id_offset
,p_plug_name=>'Create New Chunk'
,p_region_template_options=>'#DEFAULT#:t-Region--defaultHeight:t-Region-scrollAuto'
,p_plug_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_query_row_template=>1
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>891097181344328370+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>891096820124328369+wwv_flow_api.g_id_offset
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P35_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>891097388627328370+wwv_flow_api.g_id_offset
,p_button_sequence=>10
,p_button_plug_id=>891096820124328369+wwv_flow_api.g_id_offset
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_grid_new_grid=>false
);
wwv_flow_api.create_page_button(
 p_id=>891097032068328370+wwv_flow_api.g_id_offset
,p_button_sequence=>40
,p_button_plug_id=>891096820124328369+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P35_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_grid=>false
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>891097210429328370+wwv_flow_api.g_id_offset
,p_button_sequence=>20
,p_button_plug_id=>891096820124328369+wwv_flow_api.g_id_offset
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Delete'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P35_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>891098412347328374+wwv_flow_api.g_id_offset
,p_branch_action=>'f?p=&APP_ID.:5:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>891098685152328375+wwv_flow_api.g_id_offset
,p_name=>'P35_ID'
,p_item_sequence=>10
,p_item_plug_id=>891096820124328369+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>891098844906328377+wwv_flow_api.g_id_offset
,p_name=>'P35_NAME'
,p_item_sequence=>20
,p_item_plug_id=>891096820124328369+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Name'
,p_source=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>256
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_da_event(
 p_id=>891097469523328370+wwv_flow_api.g_id_offset
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>891097388627328370+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>891097866914328372+wwv_flow_api.g_id_offset
,p_event_id=>891097469523328370+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>891099229982328377+wwv_flow_api.g_id_offset
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from MC_CHUNK'
,p_attribute_02=>'MC_CHUNK'
,p_attribute_03=>'P35_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>891099401430328378+wwv_flow_api.g_id_offset
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of MC_CHUNK'
,p_attribute_02=>'MC_CHUNK'
,p_attribute_03=>'P35_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
);
wwv_flow_api.create_page_process(
 p_id=>891099663870328378+wwv_flow_api.g_id_offset
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>891097210429328370+wwv_flow_api.g_id_offset
);
wwv_flow_api.create_page_process(
 p_id=>891099844109328378+wwv_flow_api.g_id_offset
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
end;
/
prompt --application/pages/page_00036
begin
wwv_flow_api.create_page(
 p_id=>36
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Form on MC_DOCUMENT'
,p_page_mode=>'MODAL'
,p_step_title=>'Form'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_cache_timeout_seconds=>21600
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141124014754'
);
wwv_flow_api.create_page_plug(
 p_id=>898378032277997133+wwv_flow_api.g_id_offset
,p_plug_name=>'Add New Document'
,p_region_template_options=>'#DEFAULT#:t-Region--defaultHeight:t-Region-scrollAuto'
,p_plug_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_query_row_template=>1
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>898378396668997134+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>898378032277997133+wwv_flow_api.g_id_offset
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P36_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>898378518729997134+wwv_flow_api.g_id_offset
,p_button_sequence=>10
,p_button_plug_id=>898378032277997133+wwv_flow_api.g_id_offset
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_grid_new_grid=>false
);
wwv_flow_api.create_page_button(
 p_id=>898378226411997134+wwv_flow_api.g_id_offset
,p_button_sequence=>40
,p_button_plug_id=>898378032277997133+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P36_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_grid=>false
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>898378485777997134+wwv_flow_api.g_id_offset
,p_button_sequence=>20
,p_button_plug_id=>898378032277997133+wwv_flow_api.g_id_offset
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Delete'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P36_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>898379699249997137+wwv_flow_api.g_id_offset
,p_branch_action=>'f?p=&APP_ID.:6:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>898379882973997139+wwv_flow_api.g_id_offset
,p_name=>'P36_ID'
,p_item_sequence=>10
,p_item_plug_id=>898378032277997133+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>898380053186997141+wwv_flow_api.g_id_offset
,p_name=>'P36_FILE_NAME'
,p_item_sequence=>20
,p_item_plug_id=>898378032277997133+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'File Name'
,p_source=>'FILE_NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>898380276861997141+wwv_flow_api.g_id_offset
,p_name=>'P36_FILE_MIMETYPE'
,p_item_sequence=>30
,p_item_plug_id=>898378032277997133+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'File Mimetype'
,p_source=>'FILE_MIMETYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_cSize=>60
,p_cMaxlength=>512
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>898380454446997141+wwv_flow_api.g_id_offset
,p_name=>'P36_FILE_CHARSET'
,p_item_sequence=>40
,p_item_plug_id=>898378032277997133+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'File Charset'
,p_source=>'FILE_CHARSET'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_cSize=>60
,p_cMaxlength=>512
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>898380669642997141+wwv_flow_api.g_id_offset
,p_name=>'P36_FILE_DATA'
,p_item_sequence=>50
,p_item_plug_id=>898378032277997133+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'File Data'
,p_source=>'FILE_DATA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>60
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'DB_COLUMN'
,p_attribute_02=>'FILE_MIMETYPE'
,p_attribute_03=>'FILE_NAME'
,p_attribute_04=>'FILE_CHARSET'
,p_attribute_06=>'Y'
,p_attribute_08=>'attachment'
);
wwv_flow_api.create_page_item(
 p_id=>898380810773997142+wwv_flow_api.g_id_offset
,p_name=>'P36_FILE_COMMENTS'
,p_item_sequence=>60
,p_item_plug_id=>898378032277997133+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'File Comments'
,p_source=>'FILE_COMMENTS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>898381042248997142+wwv_flow_api.g_id_offset
,p_name=>'P36_TAGS'
,p_item_sequence=>70
,p_item_plug_id=>898378032277997133+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Tags'
,p_source=>'TAGS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>4000
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>898381217017997142+wwv_flow_api.g_id_offset
,p_name=>'P36_MC_PLAYER_ID'
,p_item_sequence=>80
,p_item_plug_id=>898378032277997133+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Player'
,p_source=>'MC_PLAYER_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'MC_PLAYER'
,p_lov=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select first_name || '' '' || last_name as d,',
'       id as r',
'  from mc_player',
' order by 1'))
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>898378687582997134+wwv_flow_api.g_id_offset
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>898378518729997134+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>898379056204997136+wwv_flow_api.g_id_offset
,p_event_id=>898378687582997134+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>898381648280997143+wwv_flow_api.g_id_offset
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from MC_DOCUMENT'
,p_attribute_02=>'MC_DOCUMENT'
,p_attribute_03=>'P36_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>898381822297997144+wwv_flow_api.g_id_offset
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of MC_DOCUMENT'
,p_attribute_02=>'MC_DOCUMENT'
,p_attribute_03=>'P36_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
);
wwv_flow_api.create_page_process(
 p_id=>898382034908997145+wwv_flow_api.g_id_offset
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>898378485777997134+wwv_flow_api.g_id_offset
);
wwv_flow_api.create_page_process(
 p_id=>898382216233997145+wwv_flow_api.g_id_offset
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
end;
/
prompt --application/pages/page_00037
begin
wwv_flow_api.create_page(
 p_id=>37
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Form on MC_WEAPON'
,p_page_mode=>'MODAL'
,p_step_title=>'Form'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_cache_timeout_seconds=>21600
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123040528'
);
wwv_flow_api.create_page_plug(
 p_id=>891917603375938474+wwv_flow_api.g_id_offset
,p_plug_name=>'Create New Weapon'
,p_region_template_options=>'#DEFAULT#:t-Region--defaultHeight:t-Region-scrollAuto'
,p_plug_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_query_row_template=>1
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>891917907637938475+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>891917603375938474+wwv_flow_api.g_id_offset
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P37_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>891918117237938475+wwv_flow_api.g_id_offset
,p_button_sequence=>10
,p_button_plug_id=>891917603375938474+wwv_flow_api.g_id_offset
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_grid_new_grid=>false
);
wwv_flow_api.create_page_button(
 p_id=>891917841597938475+wwv_flow_api.g_id_offset
,p_button_sequence=>40
,p_button_plug_id=>891917603375938474+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P37_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_grid=>false
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>891918074039938475+wwv_flow_api.g_id_offset
,p_button_sequence=>20
,p_button_plug_id=>891917603375938474+wwv_flow_api.g_id_offset
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Delete'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P37_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>891919217032938478+wwv_flow_api.g_id_offset
,p_branch_action=>'f?p=&APP_ID.:7:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>891919464955938480+wwv_flow_api.g_id_offset
,p_name=>'P37_ID'
,p_item_sequence=>10
,p_item_plug_id=>891917603375938474+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>891919630311938481+wwv_flow_api.g_id_offset
,p_name=>'P37_NAME'
,p_item_sequence=>20
,p_item_plug_id=>891917603375938474+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Name'
,p_source=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>256
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>891919870864938482+wwv_flow_api.g_id_offset
,p_name=>'P37_TYPE'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>891917603375938474+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Type'
,p_source=>'TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'MC WEAPON'
,p_lov=>'.'||to_char(891984897976346886 + wwv_flow_api.g_id_offset)||'.'
,p_cSize=>60
,p_cMaxlength=>256
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847507227208503+wwv_flow_api.g_id_offset
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
,p_attribute_04=>'VERTICAL'
);
wwv_flow_api.create_page_item(
 p_id=>891920049625938482+wwv_flow_api.g_id_offset
,p_name=>'P37_AMOUNT'
,p_item_sequence=>40
,p_item_plug_id=>891917603375938474+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Amount'
,p_source=>'AMOUNT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>891920276948938483+wwv_flow_api.g_id_offset
,p_name=>'P37_MC_AVATAR_ID'
,p_item_sequence=>50
,p_item_plug_id=>891917603375938474+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Owner'
,p_source=>'MC_AVATAR_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'MC_AVATAR'
,p_lov=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select name as d,',
'       id as r',
'  from mc_avatar',
' order by 1'))
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>891920476995938483+wwv_flow_api.g_id_offset
,p_name=>'P37_DURABILITY'
,p_item_sequence=>60
,p_item_plug_id=>891917603375938474+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Durability'
,p_source=>'DURABILITY'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>891920649707938483+wwv_flow_api.g_id_offset
,p_name=>'P37_DAMAGE'
,p_item_sequence=>70
,p_item_plug_id=>891917603375938474+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Damage'
,p_source=>'DAMAGE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>891920866896938483+wwv_flow_api.g_id_offset
,p_name=>'P37_MC_MATERIAL_ID'
,p_item_sequence=>80
,p_item_plug_id=>891917603375938474+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Material'
,p_source=>'MC_MATERIAL_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'MC_MATERIAL'
,p_lov=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select name as d,',
'       id as r',
'  from mc_material',
' order by 1'))
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>891918291441938475+wwv_flow_api.g_id_offset
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>891918117237938475+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>891918608887938477+wwv_flow_api.g_id_offset
,p_event_id=>891918291441938475+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>891921217047938484+wwv_flow_api.g_id_offset
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from MC_WEAPON'
,p_attribute_02=>'MC_WEAPON'
,p_attribute_03=>'P37_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>891921443409938485+wwv_flow_api.g_id_offset
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of MC_WEAPON'
,p_attribute_02=>'MC_WEAPON'
,p_attribute_03=>'P37_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
);
wwv_flow_api.create_page_process(
 p_id=>891921696831938485+wwv_flow_api.g_id_offset
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>891918074039938475+wwv_flow_api.g_id_offset
);
wwv_flow_api.create_page_process(
 p_id=>891921859216938485+wwv_flow_api.g_id_offset
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
end;
/
prompt --application/pages/page_00038
begin
wwv_flow_api.create_page(
 p_id=>38
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Form on MC_ARMOR'
,p_page_mode=>'MODAL'
,p_step_title=>'Form'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_cache_timeout_seconds=>21600
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123040601'
);
wwv_flow_api.create_page_plug(
 p_id=>891928943437950619+wwv_flow_api.g_id_offset
,p_plug_name=>'Create New Armor'
,p_region_template_options=>'#DEFAULT#:t-Region--defaultHeight:t-Region-scrollAuto'
,p_plug_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_query_row_template=>1
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>891929239774950620+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>891928943437950619+wwv_flow_api.g_id_offset
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P38_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>891929437739950620+wwv_flow_api.g_id_offset
,p_button_sequence=>10
,p_button_plug_id=>891928943437950619+wwv_flow_api.g_id_offset
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_grid_new_grid=>false
);
wwv_flow_api.create_page_button(
 p_id=>891929137990950620+wwv_flow_api.g_id_offset
,p_button_sequence=>40
,p_button_plug_id=>891928943437950619+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P38_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_grid=>false
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>891929313559950620+wwv_flow_api.g_id_offset
,p_button_sequence=>20
,p_button_plug_id=>891928943437950619+wwv_flow_api.g_id_offset
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Delete'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P38_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>891930512571950623+wwv_flow_api.g_id_offset
,p_branch_action=>'f?p=&APP_ID.:8:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>891930776693950649+wwv_flow_api.g_id_offset
,p_name=>'P38_ID'
,p_item_sequence=>10
,p_item_plug_id=>891928943437950619+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>891930957022950651+wwv_flow_api.g_id_offset
,p_name=>'P38_NAME'
,p_item_sequence=>20
,p_item_plug_id=>891928943437950619+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Name'
,p_source=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>256
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>891931161846950651+wwv_flow_api.g_id_offset
,p_name=>'P38_TYPE'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>891928943437950619+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Type'
,p_source=>'TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'MC ARMOR'
,p_lov=>'.'||to_char(891985611272348090 + wwv_flow_api.g_id_offset)||'.'
,p_cSize=>60
,p_cMaxlength=>256
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847507227208503+wwv_flow_api.g_id_offset
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
,p_attribute_04=>'VERTICAL'
);
wwv_flow_api.create_page_item(
 p_id=>891931326572950652+wwv_flow_api.g_id_offset
,p_name=>'P38_AMOUNT'
,p_item_sequence=>40
,p_item_plug_id=>891928943437950619+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Amount'
,p_source=>'AMOUNT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>891931522560950652+wwv_flow_api.g_id_offset
,p_name=>'P38_MC_AVATAR_ID'
,p_item_sequence=>50
,p_item_plug_id=>891928943437950619+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Avatar'
,p_source=>'MC_AVATAR_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'MC_AVATAR'
,p_lov=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select name as d,',
'       id as r',
'  from mc_avatar',
' order by 1'))
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>891931770657950652+wwv_flow_api.g_id_offset
,p_name=>'P38_DURABILITY'
,p_item_sequence=>60
,p_item_plug_id=>891928943437950619+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Durability'
,p_source=>'DURABILITY'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>891941948076950652+wwv_flow_api.g_id_offset
,p_name=>'P38_ARMOR'
,p_item_sequence=>70
,p_item_plug_id=>891928943437950619+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Armor'
,p_source=>'ARMOR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>891942127055950653+wwv_flow_api.g_id_offset
,p_name=>'P38_MC_MATERIAL_ID'
,p_item_sequence=>80
,p_item_plug_id=>891928943437950619+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Material'
,p_source=>'MC_MATERIAL_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'MC_MATERIAL'
,p_lov=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select name as d,',
'       id as r',
'  from mc_material',
' order by 1'))
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>891929522078950620+wwv_flow_api.g_id_offset
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>891929437739950620+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>891929993242950622+wwv_flow_api.g_id_offset
,p_event_id=>891929522078950620+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>891942574777950653+wwv_flow_api.g_id_offset
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from MC_ARMOR'
,p_attribute_02=>'MC_ARMOR'
,p_attribute_03=>'P38_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>891942740845950654+wwv_flow_api.g_id_offset
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of MC_ARMOR'
,p_attribute_02=>'MC_ARMOR'
,p_attribute_03=>'P38_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
);
wwv_flow_api.create_page_process(
 p_id=>891942916417950654+wwv_flow_api.g_id_offset
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>891929313559950620+wwv_flow_api.g_id_offset
);
wwv_flow_api.create_page_process(
 p_id=>891943155164950654+wwv_flow_api.g_id_offset
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
end;
/
prompt --application/pages/page_00039
begin
wwv_flow_api.create_page(
 p_id=>39
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Form on MC_TOOL'
,p_page_mode=>'MODAL'
,p_step_title=>'Form'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_cache_timeout_seconds=>21600
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123102453'
);
wwv_flow_api.create_page_plug(
 p_id=>892840276557920941+wwv_flow_api.g_id_offset
,p_plug_name=>'Create New Tool'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_query_row_template=>1
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>892840510566920942+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>892840276557920941+wwv_flow_api.g_id_offset
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P39_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>892840704806920944+wwv_flow_api.g_id_offset
,p_button_sequence=>10
,p_button_plug_id=>892840276557920941+wwv_flow_api.g_id_offset
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_grid_new_grid=>false
);
wwv_flow_api.create_page_button(
 p_id=>892840473113920942+wwv_flow_api.g_id_offset
,p_button_sequence=>40
,p_button_plug_id=>892840276557920941+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P39_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_grid=>false
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>892840640304920942+wwv_flow_api.g_id_offset
,p_button_sequence=>20
,p_button_plug_id=>892840276557920941+wwv_flow_api.g_id_offset
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Delete'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P39_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>892841865465920949+wwv_flow_api.g_id_offset
,p_branch_action=>'f?p=&APP_ID.:9:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>892842082501920953+wwv_flow_api.g_id_offset
,p_name=>'P39_ID'
,p_item_sequence=>10
,p_item_plug_id=>892840276557920941+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>892842295992920954+wwv_flow_api.g_id_offset
,p_name=>'P39_NAME'
,p_item_sequence=>20
,p_item_plug_id=>892840276557920941+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Name'
,p_source=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>256
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>892842491572920956+wwv_flow_api.g_id_offset
,p_name=>'P39_TYPE'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>892840276557920941+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Type'
,p_source=>'TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'MC TOOL'
,p_lov=>'.'||to_char(891988257313356444 + wwv_flow_api.g_id_offset)||'.'
,p_cSize=>60
,p_cMaxlength=>256
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847507227208503+wwv_flow_api.g_id_offset
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
,p_attribute_04=>'VERTICAL'
);
wwv_flow_api.create_page_item(
 p_id=>892842636211920956+wwv_flow_api.g_id_offset
,p_name=>'P39_AMOUNT'
,p_item_sequence=>40
,p_item_plug_id=>892840276557920941+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Amount'
,p_source=>'AMOUNT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>892842800536920957+wwv_flow_api.g_id_offset
,p_name=>'P39_MC_AVATAR_ID'
,p_item_sequence=>50
,p_item_plug_id=>892840276557920941+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Avatar'
,p_source=>'MC_AVATAR_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'MC_AVATAR'
,p_lov=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select name as d,',
'       id as r',
'  from mc_avatar',
' order by 1'))
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>892843026653920957+wwv_flow_api.g_id_offset
,p_name=>'P39_DURABILITY'
,p_item_sequence=>60
,p_item_plug_id=>892840276557920941+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Durability'
,p_source=>'DURABILITY'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>892843262280920957+wwv_flow_api.g_id_offset
,p_name=>'P39_MC_MATERIAL_ID'
,p_item_sequence=>70
,p_item_plug_id=>892840276557920941+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Material'
,p_source=>'MC_MATERIAL_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'MC_MATERIAL'
,p_lov=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select name as d,',
'       id as r',
'  from mc_material',
' order by 1'))
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>892840853675920944+wwv_flow_api.g_id_offset
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>892840704806920944+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>892841255413920945+wwv_flow_api.g_id_offset
,p_event_id=>892840853675920944+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>892843659812920959+wwv_flow_api.g_id_offset
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from MC_TOOL'
,p_attribute_02=>'MC_TOOL'
,p_attribute_03=>'P39_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>892843872069920960+wwv_flow_api.g_id_offset
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of MC_TOOL'
,p_attribute_02=>'MC_TOOL'
,p_attribute_03=>'P39_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
);
wwv_flow_api.create_page_process(
 p_id=>892844048283920960+wwv_flow_api.g_id_offset
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>892840640304920942+wwv_flow_api.g_id_offset
);
wwv_flow_api.create_page_process(
 p_id=>892844252221920960+wwv_flow_api.g_id_offset
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
end;
/
prompt --application/pages/page_00040
begin
wwv_flow_api.create_page(
 p_id=>40
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Form on MC_FOOD'
,p_page_mode=>'MODAL'
,p_step_title=>'Form'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_cache_timeout_seconds=>21600
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123040758'
);
wwv_flow_api.create_page_plug(
 p_id=>891952530578968877+wwv_flow_api.g_id_offset
,p_plug_name=>'Create New Food'
,p_region_template_options=>'#DEFAULT#:t-Region--defaultHeight:t-Region-scrollAuto'
,p_plug_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_query_row_template=>1
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>891952867257968878+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>891952530578968877+wwv_flow_api.g_id_offset
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P40_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>891953039809968879+wwv_flow_api.g_id_offset
,p_button_sequence=>10
,p_button_plug_id=>891952530578968877+wwv_flow_api.g_id_offset
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_grid_new_grid=>false
);
wwv_flow_api.create_page_button(
 p_id=>891952725369968878+wwv_flow_api.g_id_offset
,p_button_sequence=>40
,p_button_plug_id=>891952530578968877+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P40_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_grid=>false
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>891952941302968878+wwv_flow_api.g_id_offset
,p_button_sequence=>20
,p_button_plug_id=>891952530578968877+wwv_flow_api.g_id_offset
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Delete'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P40_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>891954106499968883+wwv_flow_api.g_id_offset
,p_branch_action=>'f?p=&APP_ID.:10:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>891954301352968909+wwv_flow_api.g_id_offset
,p_name=>'P40_ID'
,p_item_sequence=>10
,p_item_plug_id=>891952530578968877+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>891954517868968911+wwv_flow_api.g_id_offset
,p_name=>'P40_NAME'
,p_item_sequence=>20
,p_item_plug_id=>891952530578968877+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Name'
,p_source=>'NAME'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>256
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_api.create_page_item(
 p_id=>891954742015968911+wwv_flow_api.g_id_offset
,p_name=>'P40_TYPE'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>891952530578968877+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Type'
,p_source=>'TYPE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'MC FOOD'
,p_lov=>'.'||to_char(891995791622360621 + wwv_flow_api.g_id_offset)||'.'
,p_cSize=>60
,p_cMaxlength=>256
,p_cHeight=>4
,p_label_alignment=>'RIGHT'
,p_field_template=>788847507227208503+wwv_flow_api.g_id_offset
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
,p_attribute_04=>'VERTICAL'
);
wwv_flow_api.create_page_item(
 p_id=>891954967261968911+wwv_flow_api.g_id_offset
,p_name=>'P40_AMOUNT'
,p_item_sequence=>40
,p_item_plug_id=>891952530578968877+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Amount'
,p_source=>'AMOUNT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>891955165465968912+wwv_flow_api.g_id_offset
,p_name=>'P40_MC_AVATAR_ID'
,p_item_sequence=>50
,p_item_plug_id=>891952530578968877+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Avatar'
,p_source=>'MC_AVATAR_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'MC_AVATAR'
,p_lov=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select name as d,',
'       id as r',
'  from mc_avatar',
' order by 1'))
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>891955363304968912+wwv_flow_api.g_id_offset
,p_name=>'P40_FOOD'
,p_item_sequence=>60
,p_item_plug_id=>891952530578968877+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Food'
,p_source=>'FOOD'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_item(
 p_id=>891955559828968912+wwv_flow_api.g_id_offset
,p_name=>'P40_SATURATION'
,p_item_sequence=>70
,p_item_plug_id=>891952530578968877+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Saturation'
,p_source=>'SATURATION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_03=>'right'
);
wwv_flow_api.create_page_da_event(
 p_id=>891953161433968879+wwv_flow_api.g_id_offset
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>891953039809968879+wwv_flow_api.g_id_offset
,p_bind_type=>'bind'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>891953561777968881+wwv_flow_api.g_id_offset
,p_event_id=>891953161433968879+wwv_flow_api.g_id_offset
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
,p_stop_execution_on_error=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>891955933336968913+wwv_flow_api.g_id_offset
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from MC_FOOD'
,p_attribute_02=>'MC_FOOD'
,p_attribute_03=>'P40_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>891956177013968914+wwv_flow_api.g_id_offset
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of MC_FOOD'
,p_attribute_02=>'MC_FOOD'
,p_attribute_03=>'P40_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
);
wwv_flow_api.create_page_process(
 p_id=>891956386649968914+wwv_flow_api.g_id_offset
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>891952941302968878+wwv_flow_api.g_id_offset
);
wwv_flow_api.create_page_process(
 p_id=>891956502275968914+wwv_flow_api.g_id_offset
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
end;
/
prompt --application/pages/page_00041
begin
wwv_flow_api.create_page(
 p_id=>41
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Form on MC_OWNERSHIP'
,p_page_mode=>'NORMAL'
,p_step_title=>'Form'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_cache_timeout_seconds=>21600
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123103323'
);
wwv_flow_api.create_page_plug(
 p_id=>891244480107591623+wwv_flow_api.g_id_offset
,p_plug_name=>'Associate New Ownership'
,p_region_template_options=>'#DEFAULT#:t-Region--defaultHeight:t-Region-scrollAuto'
,p_plug_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_query_row_template=>1
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>891282081100938154+wwv_flow_api.g_id_offset
,p_button_sequence=>25
,p_button_plug_id=>891244480107591623+wwv_flow_api.g_id_offset
,p_button_name=>'P41_CREATE_NEW_AVATAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#:t-Button--large'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Create New Avatar'
,p_button_position=>'BODY'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:33::'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>891287987387961502+wwv_flow_api.g_id_offset
,p_button_sequence=>35
,p_button_plug_id=>891244480107591623+wwv_flow_api.g_id_offset
,p_button_name=>'P41_CREATE_NEW_CHUNK'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#:t-Button--large'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Create New Chunk'
,p_button_position=>'BODY'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:35:&SESSION.::&DEBUG.:35::'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>891244786088591624+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>891244480107591623+wwv_flow_api.g_id_offset
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'REGION_TEMPLATE_CHANGE'
,p_button_condition=>'P41_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
,p_database_action=>'UPDATE'
);
wwv_flow_api.create_page_button(
 p_id=>891244964828591624+wwv_flow_api.g_id_offset
,p_button_sequence=>10
,p_button_plug_id=>891244480107591623+wwv_flow_api.g_id_offset
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Cancel'
,p_button_position=>'REGION_TEMPLATE_CLOSE'
,p_button_redirect_url=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.:::'
,p_grid_new_grid=>false
);
wwv_flow_api.create_page_button(
 p_id=>891244689623591624+wwv_flow_api.g_id_offset
,p_button_sequence=>40
,p_button_plug_id=>891244480107591623+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Associate'
,p_button_position=>'REGION_TEMPLATE_CREATE'
,p_button_condition=>'P41_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
,p_database_action=>'INSERT'
);
wwv_flow_api.create_page_button(
 p_id=>891244817002591624+wwv_flow_api.g_id_offset
,p_button_sequence=>20
,p_button_plug_id=>891244480107591623+wwv_flow_api.g_id_offset
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Delete'
,p_button_position=>'TOP'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P41_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_grid=>false
,p_database_action=>'DELETE'
);
wwv_flow_api.create_page_branch(
 p_id=>891245750580591626+wwv_flow_api.g_id_offset
,p_branch_action=>'f?p=&APP_ID.:11:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_api.create_page_item(
 p_id=>891245967071591627+wwv_flow_api.g_id_offset
,p_name=>'P41_ID'
,p_item_sequence=>10
,p_item_plug_id=>891244480107591623+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
);
wwv_flow_api.create_page_item(
 p_id=>891246121657591629+wwv_flow_api.g_id_offset
,p_name=>'P41_MC_AVATAR_ID'
,p_item_sequence=>20
,p_item_plug_id=>891244480107591623+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Avatar'
,p_source=>'MC_AVATAR_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'MC_AVATAR'
,p_lov=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select name as d,',
'       id as r',
'  from mc_avatar',
' order by 1'))
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_colspan=>2
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>891246396263591629+wwv_flow_api.g_id_offset
,p_name=>'P41_MC_CHUNK_ID'
,p_item_sequence=>30
,p_item_plug_id=>891244480107591623+wwv_flow_api.g_id_offset
,p_use_cache_before_default=>'NO'
,p_prompt=>'Chunk'
,p_source=>'MC_CHUNK_ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'MC_CHUNK'
,p_lov=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select name as d,',
'       id as r',
'  from mc_chunk',
' order by 1'))
,p_cSize=>32
,p_cMaxlength=>255
,p_cHeight=>1
,p_colspan=>2
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_process(
 p_id=>891246785630591629+wwv_flow_api.g_id_offset
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from MC_OWNERSHIP'
,p_attribute_02=>'MC_OWNERSHIP'
,p_attribute_03=>'P41_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
);
wwv_flow_api.create_page_process(
 p_id=>891246955326591630+wwv_flow_api.g_id_offset
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of MC_OWNERSHIP'
,p_attribute_02=>'MC_OWNERSHIP'
,p_attribute_03=>'P41_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
);
wwv_flow_api.create_page_process(
 p_id=>891247152609591630+wwv_flow_api.g_id_offset
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>891244817002591624+wwv_flow_api.g_id_offset
);
end;
/
prompt --application/pages/page_00062
begin
wwv_flow_api.create_page(
 p_id=>62
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Player Details'
,p_page_mode=>'NORMAL'
,p_step_title=>'Player Details'
,p_step_sub_title=>'Player Details'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141124031212'
);
wwv_flow_api.create_report_region(
 p_id=>892463279280588298+wwv_flow_api.g_id_offset
,p_name=>'Player''s Details'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select ',
' "ID",',
' "FIRST_NAME",',
' "LAST_NAME",',
' "IP_ADDRESS",',
' "DEFAULT_LANG",',
' "MC_AVATAR_ID",',
' "CREATED",',
' "CREATED_BY",',
' "ROW_VERSION_NUMBER",',
' "UPDATED",',
' "UPDATED_BY"',
'from #OWNER#.MC_PLAYER',
'where "ID"=:P62_ID'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>892463523261588299+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892463664791588300+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'FIRST_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'First Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892463701067588300+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'LAST_NAME'
,p_column_display_sequence=>3
,p_column_heading=>'Last Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892463805395588300+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'IP_ADDRESS'
,p_column_display_sequence=>4
,p_column_heading=>'IP Address'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892463991768588300+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'DEFAULT_LANG'
,p_column_display_sequence=>5
,p_column_heading=>'Default Language'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892464090888588300+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'MC_AVATAR_ID'
,p_column_display_sequence=>6
,p_column_heading=>'Avatar ID'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892464161024588300+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'CREATED'
,p_column_display_sequence=>7
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892464216399588300+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>8
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892464308053588300+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>9
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892464456903588300+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>10
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892464507863588301+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>11
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>893054810756078517+wwv_flow_api.g_id_offset
,p_name=>'Player''s Avatar'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select ',
' a."ID",',
' a."NAME",',
' a."HEALTH",',
' a."CURRENT_SPAWN",',
' a."HUNGER",',
' a."EXPERIENCE",',
' a."CREATED",',
' a."CREATED_BY",',
' a."ROW_VERSION_NUMBER",',
' a."UPDATED",',
' a."UPDATED_BY"',
'from #OWNER#.MC_PLAYER p',
'join #OWNER#.MC_AVATAR a',
'on p.mc_avatar_id=a.id',
'where p."ID"=:P62_ID'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>893055486397078521+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893062269984809122+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893062442136812890+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'HEALTH'
,p_column_display_sequence=>3
,p_column_heading=>'Health'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893062582594812891+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CURRENT_SPAWN'
,p_column_display_sequence=>4
,p_column_heading=>'Current Spawn'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893062688536812891+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'HUNGER'
,p_column_display_sequence=>5
,p_column_heading=>'Hunger'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893062759619812891+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'EXPERIENCE'
,p_column_display_sequence=>6
,p_column_heading=>'Experience'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893055611295078521+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'CREATED'
,p_column_display_sequence=>7
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893055790082078521+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>8
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893055856935078521+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>9
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893055910570078521+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>10
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893056050400078521+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>11
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>899487488667909027+wwv_flow_api.g_id_offset
,p_name=>'Player''s Documents'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select ID,',
'       FILE_NAME,',
'       FILE_MIMETYPE,',
'       dbms_lob.getlength("FILE_DATA") as "Size (Bytes)",',
'       dbms_lob.getlength("FILE_DATA") as "File Data",',
'       FILE_COMMENTS,',
'       TAGS,',
'       CREATED,',
'       CREATED_BY,',
'       UPDATED,',
'       UPDATED_BY',
'  from MC_DOCUMENT',
'  where MC_PLAYER_ID=:P62_ID',
'  '))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>788840920131206733+wwv_flow_api.g_id_offset
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>899487844026909030+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899487910123909031+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'FILE_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'File Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899488012065909031+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'FILE_MIMETYPE'
,p_column_display_sequence=>4
,p_column_heading=>'File Mimetype'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899507093802965944+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'Size (Bytes)'
,p_column_display_sequence=>3
,p_column_heading=>'Size (Bytes)'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899499902750928168+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'File Data'
,p_column_display_sequence=>5
,p_column_heading=>'File Data'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:MC_DOCUMENT:FILE_DATA:ID::FILE_MIMETYPE:FILE_NAME::FILE_CHARSET:Attachment:Download:'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>899488355904909032+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'FILE_COMMENTS'
,p_column_display_sequence=>7
,p_column_heading=>'File Comments'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899488464246909032+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'TAGS'
,p_column_display_sequence=>6
,p_column_heading=>'Tags'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899488672922909032+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'CREATED'
,p_column_display_sequence=>8
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899488724280909032+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>9
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899488964441909032+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>10
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899489096419909032+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>11
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>899508600034973982+wwv_flow_api.g_id_offset
,p_button_sequence=>10
,p_button_plug_id=>899487488667909027+wwv_flow_api.g_id_offset
,p_button_name=>'ADD_DOCUMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#:t-Button--small:t-Button--gapLeft'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Add New Document'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.:36:P36_MC_PLAYER_ID:&P62_ID.'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>892483016913657499+wwv_flow_api.g_id_offset
,p_name=>'P62_ID'
,p_item_sequence=>10
,p_item_plug_id=>892463279280588298+wwv_flow_api.g_id_offset
,p_display_as=>'NATIVE_HIDDEN'
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_attribute_01=>'Y'
);
end;
/
prompt --application/pages/page_00063
begin
wwv_flow_api.create_page(
 p_id=>63
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Avatar Details'
,p_page_mode=>'NORMAL'
,p_step_title=>'Avatar Details'
,p_step_sub_title=>'Avatar Details'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'LULULIU820@UTEXAS.EDU'
,p_last_upd_yyyymmddhh24miss=>'20141124060952'
);
wwv_flow_api.create_report_region(
 p_id=>892465055984595128+wwv_flow_api.g_id_offset
,p_name=>'Avatar''s Details'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select ',
' "ID",',
' "NAME",',
' "HEALTH",',
' "CURRENT_SPAWN",',
' "HUNGER",',
' "EXPERIENCE",',
' "MC_PLAYER_ID",',
' "CREATED",',
' "CREATED_BY",',
' "ROW_VERSION_NUMBER",',
' "UPDATED",',
' "UPDATED_BY"',
'from #OWNER#.MC_AVATAR',
'where "ID"=:P63_ID'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>892465390382595130+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892465456478595130+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892465565636595130+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'HEALTH'
,p_column_display_sequence=>3
,p_column_heading=>'Health'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892465623202595130+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CURRENT_SPAWN'
,p_column_display_sequence=>4
,p_column_heading=>'Current Spawn'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892465704989595130+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'HUNGER'
,p_column_display_sequence=>5
,p_column_heading=>'Hunger'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892465836270595130+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'EXPERIENCE'
,p_column_display_sequence=>6
,p_column_heading=>'Experience'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892465967256595131+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'MC_PLAYER_ID'
,p_column_display_sequence=>7
,p_column_heading=>'Player ID'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892466059615595131+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'CREATED'
,p_column_display_sequence=>8
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892466156918595131+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>9
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892466200080595131+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>10
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892466390089595131+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>11
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892466402155595131+wwv_flow_api.g_id_offset
,p_query_column_id=>12
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>12
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>893058558439296718+wwv_flow_api.g_id_offset
,p_name=>'Avatar''s Player'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select ',
' p."ID",',
' p."FIRST_NAME",',
' p."LAST_NAME",',
' p."IP_ADDRESS",',
' p."DEFAULT_LANG",',
' p."CREATED",',
' p."CREATED_BY",',
' p."ROW_VERSION_NUMBER",',
' p."UPDATED",',
' p."UPDATED_BY"',
'from #OWNER#.MC_AVATAR a',
'join #OWNER#.MC_PLAYER p',
'on a.mc_player_id=p.id',
'where a."ID"=:P63_ID'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>893058708051296721+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893064027618128818+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'FIRST_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'First Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893064197944128818+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'LAST_NAME'
,p_column_display_sequence=>3
,p_column_heading=>'Last Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893064237042128818+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'IP_ADDRESS'
,p_column_display_sequence=>4
,p_column_heading=>'IP Address'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893064343491128818+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'DEFAULT_LANG'
,p_column_display_sequence=>5
,p_column_heading=>'Default Language'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893059441776296722+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'CREATED'
,p_column_display_sequence=>6
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893059538110296722+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>7
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893059646815296722+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>8
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893059744945296722+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>9
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893059862676296722+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>10
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>895412861960627485+wwv_flow_api.g_id_offset
,p_name=>'Avatar''s Land'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select ID,',
'       NAME,',
'       CREATED,',
'       CREATED_BY,',
'       ROW_VERSION_NUMBER,',
'       UPDATED,',
'       UPDATED_BY',
'  from MC_CHUNK',
'  where ID in (select mc_chunk_id from MC_OWNERSHIP where mc_avatar_id=:P63_ID)'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>788840920131206733+wwv_flow_api.g_id_offset
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>895413166911627487+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895413273779627489+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895413366715627489+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'CREATED'
,p_column_display_sequence=>3
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895413440085627489+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>4
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895413559151627489+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>5
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895413628126627489+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>6
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895413724696627489+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>7
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>895881117166974159+wwv_flow_api.g_id_offset
,p_name=>'Avatar''s Inventory'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select i.ID,',
'       i.TYPE,',
'       i.NAME,',
'       i.AMOUNT,',
'       i.DURABILITY,',
'       i.DAMAGE,',
'       i.ARMOR,',
'       i.FOOD,',
'       i.SATURATION,',
'       m.NAME as "Material Name",',
'       i.CREATED,',
'       i.CREATED_BY,',
'       i.ROW_VERSION_NUMBER,',
'       i.UPDATED,',
'       i.UPDATED_BY',
'  from MC_ITEM i',
'  full outer join MC_MATERIAL m',
'  on i.mc_material_id=m.id',
'  where i.mc_avatar_id=:P63_ID'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>788840920131206733+wwv_flow_api.g_id_offset
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>895881440007974162+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895881505897974162+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'TYPE'
,p_column_display_sequence=>2
,p_column_heading=>'Type'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895881658361974163+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'NAME'
,p_column_display_sequence=>3
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895881734691974163+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'AMOUNT'
,p_column_display_sequence=>4
,p_column_heading=>'Amount'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895881865047974163+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'DURABILITY'
,p_column_display_sequence=>5
,p_column_heading=>'Durability'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895891932393974163+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'DAMAGE'
,p_column_display_sequence=>6
,p_column_heading=>'Damage'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895892028248974163+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'ARMOR'
,p_column_display_sequence=>7
,p_column_heading=>'Armor'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895892174955974163+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'FOOD'
,p_column_display_sequence=>8
,p_column_heading=>'Food'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895892276810974163+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'SATURATION'
,p_column_display_sequence=>9
,p_column_heading=>'Saturation'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895940137361400329+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'Material Name'
,p_column_display_sequence=>10
,p_column_heading=>'Material'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895892401910974163+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'CREATED'
,p_column_display_sequence=>11
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895892511952974163+wwv_flow_api.g_id_offset
,p_query_column_id=>12
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>12
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895892617177974163+wwv_flow_api.g_id_offset
,p_query_column_id=>13
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>13
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895892749122974163+wwv_flow_api.g_id_offset
,p_query_column_id=>14
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>14
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895892891263974163+wwv_flow_api.g_id_offset
,p_query_column_id=>15
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>15
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>899187264020644551+wwv_flow_api.g_id_offset
,p_button_sequence=>10
,p_button_plug_id=>895881117166974159+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE_WEAPON'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#:t-Button--small:t-Button--gapLeft'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Create New Weapon'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:37:P37_MC_AVATAR_ID:&P63_ID.'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>899300616214365626+wwv_flow_api.g_id_offset
,p_button_sequence=>20
,p_button_plug_id=>895881117166974159+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE_ARMOR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#:t-Button--small'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Create New Armor'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:38:P38_MC_AVATAR_ID:&P63_ID.'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>899300988879366870+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>895881117166974159+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE_TOOL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#:t-Button--small'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Create New Tool'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:39:P39_MC_AVATAR_ID:&P63_ID.'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>899190846949656737+wwv_flow_api.g_id_offset
,p_button_sequence=>40
,p_button_plug_id=>895881117166974159+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE_FOOD'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#:t-Button--small'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Create New Food'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.:40:P40_MC_AVATAR_ID:&P63_ID.'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>899317103610422034+wwv_flow_api.g_id_offset
,p_button_sequence=>50
,p_button_plug_id=>895412861960627485+wwv_flow_api.g_id_offset
,p_button_name=>'ADD_LAND'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#:t-Button--small:t-Button--gapLeft'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Add New Land'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:41:P41_MC_AVATAR_ID:&P63_ID.'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>893058048506140302+wwv_flow_api.g_id_offset
,p_name=>'P63_ID'
,p_item_sequence=>10
,p_item_plug_id=>892465055984595128+wwv_flow_api.g_id_offset
,p_display_as=>'NATIVE_HIDDEN'
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_attribute_01=>'Y'
);
end;
/
prompt --application/pages/page_00064
begin
wwv_flow_api.create_page(
 p_id=>64
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Material Details'
,p_page_mode=>'NORMAL'
,p_step_title=>'Material Details'
,p_step_sub_title=>'Material Details'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141124021207'
);
wwv_flow_api.create_report_region(
 p_id=>892466903832598886+wwv_flow_api.g_id_offset
,p_name=>'Material''s Details'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select ',
' "ID",',
' "NAME",',
' "CREATED",',
' "CREATED_BY",',
' "ROW_VERSION_NUMBER",',
' "UPDATED",',
' "UPDATED_BY"',
'from #OWNER#.MC_MATERIAL',
'where "ID"=:P64_ID'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>892467219356598887+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892467362962598888+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892467460236598888+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'CREATED'
,p_column_display_sequence=>3
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892467588789598888+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>4
,p_column_heading=>'Creared By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892467610687598888+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>5
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892467751386598888+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>6
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892467893881598888+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>7
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>893091116425601984+wwv_flow_api.g_id_offset
,p_name=>'List of Item(s) with Material'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select i.ID,',
'       i.TYPE,',
'       i.NAME,',
'       i.AMOUNT,',
'       i.DURABILITY,',
'       i.DAMAGE,',
'       i.ARMOR,',
'       a.NAME as "Owner Name",',
'       i.CREATED,',
'       i.CREATED_BY,',
'       i.ROW_VERSION_NUMBER,',
'       i.UPDATED,',
'       i.UPDATED_BY',
'  from MC_ITEM i',
'  join MC_AVATAR a',
'  on i.mc_avatar_id=a.id',
'  where i.MC_MATERIAL_ID=:P64_ID'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>788840920131206733+wwv_flow_api.g_id_offset
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>893091436521601987+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893091554277601989+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'TYPE'
,p_column_display_sequence=>3
,p_column_heading=>'Type'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893091601171601989+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893091764376601989+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'AMOUNT'
,p_column_display_sequence=>4
,p_column_heading=>'Amount'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893091814363601989+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'DURABILITY'
,p_column_display_sequence=>5
,p_column_heading=>'Durability'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893151996515601989+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'DAMAGE'
,p_column_display_sequence=>6
,p_column_heading=>'Damage'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893152054994601989+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'ARMOR'
,p_column_display_sequence=>7
,p_column_heading=>'Armor'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895915028760322238+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'Owner Name'
,p_column_display_sequence=>8
,p_column_heading=>'Owner'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893152549402601989+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'CREATED'
,p_column_display_sequence=>9
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893152699646601989+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>10
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893152745702601989+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>11
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893152887638601989+wwv_flow_api.g_id_offset
,p_query_column_id=>12
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>12
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893152918178601989+wwv_flow_api.g_id_offset
,p_query_column_id=>13
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>13
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>899243908888276862+wwv_flow_api.g_id_offset
,p_button_sequence=>10
,p_button_plug_id=>893091116425601984+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE_WEAPON'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#:t-Button--small:t-Button--gapLeft'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Create New Weapon'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:37:&SESSION.::&DEBUG.:37:P37_MC_MATERIAL_ID:&P64_ID.'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>899263369685303552+wwv_flow_api.g_id_offset
,p_button_sequence=>20
,p_button_plug_id=>893091116425601984+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE_ARMOR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#:t-Button--small'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Create New Armor'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:38:&SESSION.::&DEBUG.:38:P38_MC_MATERIAL_ID:&P64_ID.'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>899264975943312353+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>893091116425601984+wwv_flow_api.g_id_offset
,p_button_name=>'CREATE_TOOL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#:t-Button--small'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Create New Tool'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:39:&SESSION.::&DEBUG.:39:P39_MC_MATERIAL_ID:&P64_ID.'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>893090576767586465+wwv_flow_api.g_id_offset
,p_name=>'P64_ID'
,p_item_sequence=>10
,p_item_plug_id=>892466903832598886+wwv_flow_api.g_id_offset
,p_display_as=>'NATIVE_HIDDEN'
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_attribute_01=>'Y'
);
end;
/
prompt --application/pages/page_00065
begin
wwv_flow_api.create_page(
 p_id=>65
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Chunk Details'
,p_page_mode=>'NORMAL'
,p_step_title=>'Chunk Details'
,p_step_sub_title=>'Chunk Details'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141124022343'
);
wwv_flow_api.create_report_region(
 p_id=>892471921754608111+wwv_flow_api.g_id_offset
,p_name=>'Chunk''s Details'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select ',
' "ID",',
' "NAME",',
' "CREATED",',
' "CREATED_BY",',
' "ROW_VERSION_NUMBER",',
' "UPDATED",',
' "UPDATED_BY"',
'from #OWNER#.MC_CHUNK',
'where "ID"=:P65_ID'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>892472217794608113+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892472350517608113+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892472403453608114+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'CREATED'
,p_column_display_sequence=>3
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892472521067608114+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>4
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892472640765608114+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>5
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892472717086608114+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>6
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892472874654608114+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>7
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>893155940686680052+wwv_flow_api.g_id_offset
,p_name=>'Chunk''s Owner(s)'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select a.ID,',
'       a.NAME,',
'       a.HEALTH,',
'       a.CURRENT_SPAWN,',
'       a.HUNGER,',
'       a.EXPERIENCE,',
'       p.FIRST_NAME || '' '' || p.LAST_NAME as "Player",',
'       a.CREATED,',
'       a.CREATED_BY,',
'       a.ROW_VERSION_NUMBER,',
'       a.UPDATED,',
'       a.UPDATED_BY',
'  from MC_AVATAR a',
'  join MC_PLAYER p',
'  on a.mc_player_id=p.id',
'  where a.ID in (select mc_avatar_id from MC_OWNERSHIP where mc_chunk_id=:P65_ID)'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>788840920131206733+wwv_flow_api.g_id_offset
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>893156238199680057+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893158021151732342+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893158168376732343+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'HEALTH'
,p_column_display_sequence=>3
,p_column_heading=>'Health'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893158275987732343+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CURRENT_SPAWN'
,p_column_display_sequence=>4
,p_column_heading=>'Current Spawn'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893158367137732343+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'HUNGER'
,p_column_display_sequence=>5
,p_column_heading=>'Hunger'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893158497968732343+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'EXPERIENCE'
,p_column_display_sequence=>6
,p_column_heading=>'Experience'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896759370650445857+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'Player'
,p_column_display_sequence=>7
,p_column_heading=>'Player'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893156963304680058+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'CREATED'
,p_column_display_sequence=>8
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893157047245680058+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>9
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893157170485680058+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>10
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893157264608680058+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>11
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>893157369940680058+wwv_flow_api.g_id_offset
,p_query_column_id=>12
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>12
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_page_button(
 p_id=>899323525884679551+wwv_flow_api.g_id_offset
,p_button_sequence=>10
,p_button_plug_id=>893155940686680052+wwv_flow_api.g_id_offset
,p_button_name=>'ADD_OWNER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:#DEFAULT#:t-Button--small:t-Button--gapLeft'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_image_alt=>'Add New Owner'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:41:&SESSION.::&DEBUG.:41:P41_MC_CHUNK_ID:&P65_ID.'
,p_grid_new_grid=>false
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>893155341614666855+wwv_flow_api.g_id_offset
,p_name=>'P65_ID'
,p_item_sequence=>10
,p_item_plug_id=>892471921754608111+wwv_flow_api.g_id_offset
,p_display_as=>'NATIVE_HIDDEN'
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_attribute_01=>'Y'
);
end;
/
prompt --application/pages/page_00066
begin
wwv_flow_api.create_page(
 p_id=>66
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Document Details'
,p_page_mode=>'NORMAL'
,p_step_title=>'Document Details'
,p_step_sub_title=>'Document Details'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141124025617'
);
wwv_flow_api.create_report_region(
 p_id=>899383071577713271+wwv_flow_api.g_id_offset
,p_name=>'Document''s Details'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select ',
' d."ID",',
' d."FILE_NAME",',
' d."FILE_MIMETYPE",',
' dbms_lob.getlength("FILE_DATA") "FILE_DATA",',
' dbms_lob.getlength("FILE_DATA") "Download",',
' d."FILE_COMMENTS",',
' d."TAGS",',
' p."FIRST_NAME" || '' '' || p."LAST_NAME" as "Player Name",',
' d."CREATED",',
' d."CREATED_BY",',
' d."ROW_VERSION_NUMBER",',
' d."UPDATED",',
' d."UPDATED_BY"',
'from #OWNER#.MC_DOCUMENT d',
'join MC_PlAYER p',
'on d.mc_player_id=p.id',
'where d.ID=:P66_ID'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>899383350144713273+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899383412454713273+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'FILE_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'File Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899383540533713273+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'FILE_MIMETYPE'
,p_column_display_sequence=>3
,p_column_heading=>'File Mimetype'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899383769362713274+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'FILE_DATA'
,p_column_display_sequence=>4
,p_column_heading=>'File Size (Bytes)'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899469506439860731+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'Download'
,p_column_display_sequence=>13
,p_column_heading=>'Download'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:MC_DOCUMENT:FILE_DATA:ID::FILE_MIMETYPE:FILE_NAME::FILE_CHARSET:Attachment:Download:'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_lov_show_nulls=>'NO'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>899383862556713274+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'FILE_COMMENTS'
,p_column_display_sequence=>5
,p_column_heading=>'File Comments'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899383972075713274+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'TAGS'
,p_column_display_sequence=>6
,p_column_heading=>'Tags'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899424001221789976+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'Player Name'
,p_column_display_sequence=>7
,p_column_heading=>'Player Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899384137532713274+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'CREATED'
,p_column_display_sequence=>8
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899384267845713274+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>9
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899384301795713274+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>10
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899384413368713274+wwv_flow_api.g_id_offset
,p_query_column_id=>12
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>11
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899384588265713274+wwv_flow_api.g_id_offset
,p_query_column_id=>13
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>12
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>899471418372882766+wwv_flow_api.g_id_offset
,p_name=>'Player''s Details'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select p.ID,',
'       p.FIRST_NAME,',
'       p.LAST_NAME,',
'       p.IP_ADDRESS,',
'       p.DEFAULT_LANG,',
'       a.NAME,',
'       p.CREATED,',
'       p.CREATED_BY,',
'       p.ROW_VERSION_NUMBER,',
'       p.UPDATED,',
'       p.UPDATED_BY',
'  from MC_PLAYER p',
'  join MC_AVATAR a',
'  on p.mc_avatar_id=a.id',
'  where p.ID in (select mc_player_id from MC_DOCUMENT where ID=:P66_ID)'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>899471793388882772+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899471819882882773+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'FIRST_NAME'
,p_column_display_sequence=>2
,p_column_heading=>'First Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899471990393882773+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'LAST_NAME'
,p_column_display_sequence=>3
,p_column_heading=>'Last Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899472090320882773+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'IP_ADDRESS'
,p_column_display_sequence=>4
,p_column_heading=>'IP Address'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899472179049882773+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'DEFAULT_LANG'
,p_column_display_sequence=>5
,p_column_heading=>'Default Lang'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899474463008889304+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'NAME'
,p_column_display_sequence=>6
,p_column_heading=>'Avatar'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899472337614882773+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'CREATED'
,p_column_display_sequence=>7
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899472435154882773+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>8
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899472561811882773+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>9
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899472680810882773+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>10
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>899472717130882773+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>11
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>899384817362715510+wwv_flow_api.g_id_offset
,p_name=>'P66_ID'
,p_item_sequence=>10
,p_item_plug_id=>899383071577713271+wwv_flow_api.g_id_offset
,p_display_as=>'NATIVE_HIDDEN'
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_attribute_01=>'Y'
);
end;
/
prompt --application/pages/page_00067
begin
wwv_flow_api.create_page(
 p_id=>67
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Weapon Details'
,p_page_mode=>'NORMAL'
,p_step_title=>'Weapon Details'
,p_step_sub_title=>'Weapon Details'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123223820'
);
wwv_flow_api.create_report_region(
 p_id=>892475404975621179+wwv_flow_api.g_id_offset
,p_name=>'Weapon''s Details'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select *',
'from #OWNER#.MC_WEAPON',
'where "ID"=:P67_ID'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>892475780073621180+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892475811106621181+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892475960175621181+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'TYPE'
,p_column_display_sequence=>3
,p_column_heading=>'Type'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892476021470621181+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'AMOUNT'
,p_column_display_sequence=>4
,p_column_heading=>'Amount'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892476107948621181+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'MC_AVATAR_ID'
,p_column_display_sequence=>5
,p_column_heading=>'Owner ID'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892476261920621181+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'DURABILITY'
,p_column_display_sequence=>6
,p_column_heading=>'Durability'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892476308853621181+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'DAMAGE'
,p_column_display_sequence=>7
,p_column_heading=>'Damage'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892476406956621181+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'MC_MATERIAL_ID'
,p_column_display_sequence=>8
,p_column_heading=>'Material ID'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895441606169412549+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'CREATED'
,p_column_display_sequence=>9
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895441737766412550+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>10
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895441835527412550+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>11
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895451914602412550+wwv_flow_api.g_id_offset
,p_query_column_id=>12
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>12
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895452098396412550+wwv_flow_api.g_id_offset
,p_query_column_id=>13
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>13
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>895732740305134922+wwv_flow_api.g_id_offset
,p_name=>'Weapon''s Material'
,p_parent_plug_id=>892475404975621179+wwv_flow_api.g_id_offset
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select ID,',
'       NAME,',
'       CREATED,',
'       CREATED_BY,',
'       ROW_VERSION_NUMBER,',
'       UPDATED,',
'       UPDATED_BY',
'  from MC_MATERIAL',
'  where ID in (select mc_material_id from MC_WEAPON where ID=:P67_ID)'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>1
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>895733025817134925+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
);
wwv_flow_api.create_report_columns(
 p_id=>895733107867134925+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
);
wwv_flow_api.create_report_columns(
 p_id=>895733228939134926+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'CREATED'
,p_column_display_sequence=>3
,p_column_heading=>'Created'
);
wwv_flow_api.create_report_columns(
 p_id=>895733337289134926+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>4
,p_column_heading=>'Created By'
);
wwv_flow_api.create_report_columns(
 p_id=>895733482991134926+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>5
,p_column_heading=>'Row Version No.'
);
wwv_flow_api.create_report_columns(
 p_id=>895733505023134926+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>6
,p_column_heading=>'Updated'
);
wwv_flow_api.create_report_columns(
 p_id=>895733635181134926+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>7
,p_column_heading=>'Updated By'
);
wwv_flow_api.create_report_region(
 p_id=>895717636208795152+wwv_flow_api.g_id_offset
,p_name=>'Weapon''s Owner'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select a.ID,',
'       a.NAME,',
'       a.HEALTH,',
'       a.CURRENT_SPAWN,',
'       a.HUNGER,',
'       a.EXPERIENCE,',
'       p.FIRST_NAME || '' '' || p.LAST_NAME as "Player Name",',
'       a.CREATED,',
'       a.CREATED_BY,',
'       a.ROW_VERSION_NUMBER,',
'       a.UPDATED,',
'       a.UPDATED_BY',
'  from MC_AVATAR a',
'  join MC_PLAYER p',
'  on a.mc_player_id=p.id',
'  where a.ID in (select mc_avatar_id from MC_WEAPON where ID=:P67_ID)'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>895717975746795155+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895718010890795156+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895718165805795156+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'HEALTH'
,p_column_display_sequence=>3
,p_column_heading=>'Health'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895718299438795156+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CURRENT_SPAWN'
,p_column_display_sequence=>4
,p_column_heading=>'Current Spawn'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895718321722795156+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'HUNGER'
,p_column_display_sequence=>5
,p_column_heading=>'Hunger'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895718494775795156+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'EXPERIENCE'
,p_column_display_sequence=>6
,p_column_heading=>'Experience'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895917514906345270+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'Player Name'
,p_column_display_sequence=>7
,p_column_heading=>'Player Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895718631567795156+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'CREATED'
,p_column_display_sequence=>8
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895718705603795156+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>9
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895718874334795156+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>10
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895718951705795156+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>11
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895719028039795156+wwv_flow_api.g_id_offset
,p_query_column_id=>12
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>12
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>895416585002660139+wwv_flow_api.g_id_offset
,p_name=>'P67_ID'
,p_item_sequence=>10
,p_item_plug_id=>892475404975621179+wwv_flow_api.g_id_offset
,p_display_as=>'NATIVE_HIDDEN'
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_attribute_01=>'Y'
);
end;
/
prompt --application/pages/page_00068
begin
wwv_flow_api.create_page(
 p_id=>68
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Armor Details'
,p_page_mode=>'NORMAL'
,p_step_title=>'Armor Details'
,p_step_sub_title=>'Armor Details'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123224357'
);
wwv_flow_api.create_report_region(
 p_id=>892477429399626635+wwv_flow_api.g_id_offset
,p_name=>'Armor''s Details'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select *',
'from #OWNER#.MC_ARMOR',
'where "ID"=:P68_ID'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>892477749647626637+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892477893939626638+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892477915539626638+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'TYPE'
,p_column_display_sequence=>3
,p_column_heading=>'Type'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892478002945626638+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'AMOUNT'
,p_column_display_sequence=>4
,p_column_heading=>'Amount'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892478172285626639+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'MC_AVATAR_ID'
,p_column_display_sequence=>5
,p_column_heading=>'Owner ID'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892478220574626639+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'DURABILITY'
,p_column_display_sequence=>6
,p_column_heading=>'Durability'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892478307084626639+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'ARMOR'
,p_column_display_sequence=>7
,p_column_heading=>'Armor'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892478456666626639+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'MC_MATERIAL_ID'
,p_column_display_sequence=>8
,p_column_heading=>'Material ID'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895452273520414543+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'CREATED'
,p_column_display_sequence=>9
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895452374399414544+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>10
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895452486237414544+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>11
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895452505985414544+wwv_flow_api.g_id_offset
,p_query_column_id=>12
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>12
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895452632784414544+wwv_flow_api.g_id_offset
,p_query_column_id=>13
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>13
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>895742043074176126+wwv_flow_api.g_id_offset
,p_name=>'Armor''s Material'
,p_parent_plug_id=>892477429399626635+wwv_flow_api.g_id_offset
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select ID,',
'       NAME,',
'       CREATED,',
'       CREATED_BY,',
'       ROW_VERSION_NUMBER,',
'       UPDATED,',
'       UPDATED_BY',
'  from MC_MATERIAL',
'  where ID in (select mc_material_id from MC_ARMOR where ID=:P68_ID)'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>1
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>895742203384176127+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
);
wwv_flow_api.create_report_columns(
 p_id=>895742363099176128+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
);
wwv_flow_api.create_report_columns(
 p_id=>895742476263176128+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'CREATED'
,p_column_display_sequence=>3
,p_column_heading=>'Created'
);
wwv_flow_api.create_report_columns(
 p_id=>895742584437176128+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>4
,p_column_heading=>'Created By'
);
wwv_flow_api.create_report_columns(
 p_id=>895742687355176128+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>5
,p_column_heading=>'Row Version No.'
);
wwv_flow_api.create_report_columns(
 p_id=>895742792777176128+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>6
,p_column_heading=>'Updated'
);
wwv_flow_api.create_report_columns(
 p_id=>895742847470176128+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>7
,p_column_heading=>'Updated By'
);
wwv_flow_api.create_report_region(
 p_id=>895708473995097961+wwv_flow_api.g_id_offset
,p_name=>'Armor''s Owner'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select a.ID,',
'       a.NAME,',
'       a.HEALTH,',
'       a.CURRENT_SPAWN,',
'       a.HUNGER,',
'       a.EXPERIENCE,',
'       p.FIRST_NAME || '' '' || p.LAST_NAME as "Player Name",',
'       a.CREATED,',
'       a.CREATED_BY,',
'       a.ROW_VERSION_NUMBER,',
'       a.UPDATED,',
'       a.UPDATED_BY',
'  from MC_AVATAR a',
'  join MC_PLAYER p',
'  on a.mc_player_id=p.id',
'  where a.ID in (select mc_avatar_id from MC_ARMOR where ID=:P68_ID)'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>895708683346097964+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895708725618097966+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895708836350097966+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'HEALTH'
,p_column_display_sequence=>3
,p_column_heading=>'Health'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895708918346097967+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CURRENT_SPAWN'
,p_column_display_sequence=>4
,p_column_heading=>'Current Spawn'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895709010758097967+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'HUNGER'
,p_column_display_sequence=>5
,p_column_heading=>'Hunger'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895709162783097967+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'EXPERIENCE'
,p_column_display_sequence=>6
,p_column_heading=>'Experience'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895918566648350024+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'Player Name'
,p_column_display_sequence=>7
,p_column_heading=>'Player Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895709377516097967+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'CREATED'
,p_column_display_sequence=>8
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895709481839097967+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>9
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895709516096097967+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>10
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895709627929097967+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>11
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895709705191097967+wwv_flow_api.g_id_offset
,p_query_column_id=>12
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>12
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>895417099056661238+wwv_flow_api.g_id_offset
,p_name=>'P68_ID'
,p_item_sequence=>10
,p_item_plug_id=>892477429399626635+wwv_flow_api.g_id_offset
,p_display_as=>'NATIVE_HIDDEN'
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_attribute_01=>'Y'
);
end;
/
prompt --application/pages/page_00069
begin
wwv_flow_api.create_page(
 p_id=>69
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Tool Details'
,p_page_mode=>'NORMAL'
,p_step_title=>'Tool Details'
,p_step_sub_title=>'Tool Details'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123224350'
);
wwv_flow_api.create_report_region(
 p_id=>892478967801632404+wwv_flow_api.g_id_offset
,p_name=>'Tool''s Details'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select *',
'from #OWNER#.MC_TOOL',
'where "ID"=:P69_ID'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>892479290405632406+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892479354939632406+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892479481742632406+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'TYPE'
,p_column_display_sequence=>3
,p_column_heading=>'Type'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892479509787632406+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'AMOUNT'
,p_column_display_sequence=>4
,p_column_heading=>'Amount'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892479695556632406+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'MC_AVATAR_ID'
,p_column_display_sequence=>5
,p_column_heading=>'Owner ID'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892479709453632407+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'DURABILITY'
,p_column_display_sequence=>6
,p_column_heading=>'Durability'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892479857001632407+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'MC_MATERIAL_ID'
,p_column_display_sequence=>7
,p_column_heading=>'Material ID'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895452899339416888+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'CREATED'
,p_column_display_sequence=>8
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895452937759416888+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>9
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895453062542416888+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>10
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895453180499416888+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>11
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895453220816416888+wwv_flow_api.g_id_offset
,p_query_column_id=>12
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>12
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>895743190018177161+wwv_flow_api.g_id_offset
,p_name=>'Tool''s Material'
,p_parent_plug_id=>892478967801632404+wwv_flow_api.g_id_offset
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select ID,',
'       NAME,',
'       CREATED,',
'       CREATED_BY,',
'       ROW_VERSION_NUMBER,',
'       UPDATED,',
'       UPDATED_BY',
'  from MC_MATERIAL',
'  where ID in (select mc_material_id from MC_TOOL where ID=:P69_ID)'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>1
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>895743339557177163+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
);
wwv_flow_api.create_report_columns(
 p_id=>895743465503177165+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
);
wwv_flow_api.create_report_columns(
 p_id=>895743538282177165+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'CREATED'
,p_column_display_sequence=>3
,p_column_heading=>'Created'
);
wwv_flow_api.create_report_columns(
 p_id=>895743682460177165+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>4
,p_column_heading=>'Created By'
);
wwv_flow_api.create_report_columns(
 p_id=>895743759414177165+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>5
,p_column_heading=>'Row Version No.'
);
wwv_flow_api.create_report_columns(
 p_id=>895743827748177165+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>6
,p_column_heading=>'Updated'
);
wwv_flow_api.create_report_columns(
 p_id=>895743901025177165+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>7
,p_column_heading=>'Updated By'
);
wwv_flow_api.create_report_region(
 p_id=>895719769558832239+wwv_flow_api.g_id_offset
,p_name=>'Tool''s Owner'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select a.ID,',
'       a.NAME,',
'       a.HEALTH,',
'       a.CURRENT_SPAWN,',
'       a.HUNGER,',
'       a.EXPERIENCE,',
'       p.FIRST_NAME || '' '' || p.LAST_NAME as "Player Name",',
'       a.CREATED,',
'       a.CREATED_BY,',
'       a.ROW_VERSION_NUMBER,',
'       a.UPDATED,',
'       a.UPDATED_BY',
'  from MC_AVATAR a',
'  join MC_PLAYER p',
'  on a.mc_player_id=p.id',
'  where a.ID in (select mc_avatar_id from MC_TOOL where ID=:P69_ID)'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>895719928298832240+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895720021649832241+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895720142261832241+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'HEALTH'
,p_column_display_sequence=>3
,p_column_heading=>'Health'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895720231335832241+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CURRENT_SPAWN'
,p_column_display_sequence=>4
,p_column_heading=>'Current Spawn'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895720391867832241+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'HUNGER'
,p_column_display_sequence=>5
,p_column_heading=>'Hunger'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895720499195832241+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'EXPERIENCE'
,p_column_display_sequence=>6
,p_column_heading=>'Experience'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895919127650351692+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'Player Name'
,p_column_display_sequence=>7
,p_column_heading=>'Player Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895720691242832241+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'CREATED'
,p_column_display_sequence=>8
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895720784950832241+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>9
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895720881268832241+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>10
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895720927443832241+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>11
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895721067562832241+wwv_flow_api.g_id_offset
,p_query_column_id=>12
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>12
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>895417234041662739+wwv_flow_api.g_id_offset
,p_name=>'P69_ID'
,p_item_sequence=>10
,p_item_plug_id=>892478967801632404+wwv_flow_api.g_id_offset
,p_display_as=>'NATIVE_HIDDEN'
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_attribute_01=>'Y'
);
end;
/
prompt --application/pages/page_00070
begin
wwv_flow_api.create_page(
 p_id=>70
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Food Details'
,p_page_mode=>'NORMAL'
,p_step_title=>'Food Details'
,p_step_sub_title=>'Food Details'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123224341'
);
wwv_flow_api.create_report_region(
 p_id=>892480410926637867+wwv_flow_api.g_id_offset
,p_name=>'Food''s Details'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select *',
'from #OWNER#.MC_FOOD',
'where "ID"=:P70_ID'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>892480749579637868+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892480870530637869+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892480952295637869+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'TYPE'
,p_column_display_sequence=>3
,p_column_heading=>'Type'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892481096712637869+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'AMOUNT'
,p_column_display_sequence=>4
,p_column_heading=>'Amount'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892481181053637869+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'MC_AVATAR_ID'
,p_column_display_sequence=>5
,p_column_heading=>'Owner ID'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892481237627637869+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'FOOD'
,p_column_display_sequence=>6
,p_column_heading=>'Food'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892481352966637869+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'SATURATION'
,p_column_display_sequence=>7
,p_column_heading=>'Saturation'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895453482339417708+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'CREATED'
,p_column_display_sequence=>8
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895453536622417708+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>9
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895453612941417708+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>10
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895453791743417708+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>11
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895453851613417708+wwv_flow_api.g_id_offset
,p_query_column_id=>12
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>12
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>895721335743844199+wwv_flow_api.g_id_offset
,p_name=>'Food''s Owner'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select a.ID,',
'       a.NAME,',
'       a.HEALTH,',
'       a.CURRENT_SPAWN,',
'       a.HUNGER,',
'       a.EXPERIENCE,',
'       p.FIRST_NAME || '' '' || p.LAST_NAME as "Player Name",',
'       a.CREATED,',
'       a.CREATED_BY,',
'       a.ROW_VERSION_NUMBER,',
'       a.UPDATED,',
'       a.UPDATED_BY',
'  from MC_AVATAR a',
'  join MC_PLAYER p',
'  on a.mc_player_id=p.id',
'  where a.ID in (select mc_avatar_id from MC_FOOD where ID=:P70_ID)'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>895721572122844201+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895721633865844202+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895721711737844202+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'HEALTH'
,p_column_display_sequence=>3
,p_column_heading=>'Health'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895721800959844202+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CURRENT_SPAWN'
,p_column_display_sequence=>4
,p_column_heading=>'Current Spawn'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895721942086844202+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'HUNGER'
,p_column_display_sequence=>5
,p_column_heading=>'Hunger'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895722005563844202+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'EXPERIENCE'
,p_column_display_sequence=>6
,p_column_heading=>'Experience'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895919894681353861+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'Player Name'
,p_column_display_sequence=>7
,p_column_heading=>'Player Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895722201366844202+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'CREATED'
,p_column_display_sequence=>8
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895722334439844202+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>9
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895722481336844202+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>10
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895722550409844202+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>11
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>895722634714844203+wwv_flow_api.g_id_offset
,p_query_column_id=>12
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>12
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>895417420123664116+wwv_flow_api.g_id_offset
,p_name=>'P70_ID'
,p_item_sequence=>10
,p_item_plug_id=>892480410926637867+wwv_flow_api.g_id_offset
,p_display_as=>'NATIVE_HIDDEN'
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_attribute_01=>'Y'
);
end;
/
prompt --application/pages/page_00071
begin
wwv_flow_api.create_page(
 p_id=>71
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Ownership Details'
,p_page_mode=>'NORMAL'
,p_step_title=>'Ownership Details'
,p_step_sub_title=>'Ownership Details'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'NO_FIRST_ITEM'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'N'
,p_cache_mode=>'NOCACHE'
,p_help_text=>'No help is available for this page.'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141123230854'
);
wwv_flow_api.create_report_region(
 p_id=>892481847499643726+wwv_flow_api.g_id_offset
,p_name=>'Ownership Details'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select ',
' "ID",',
' "MC_AVATAR_ID",',
' "MC_CHUNK_ID",',
' "CREATED",',
' "CREATED_BY",',
' "ROW_VERSION_NUMBER",',
' "UPDATED",',
' "UPDATED_BY"',
'from #OWNER#.MC_OWNERSHIP',
'where "ID"=:P71_ID'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'0'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>892482173606643728+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892482287907643728+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'MC_AVATAR_ID'
,p_column_display_sequence=>2
,p_column_heading=>'Avatar ID'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892482322818643729+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'MC_CHUNK_ID'
,p_column_display_sequence=>3
,p_column_heading=>'Chunk ID'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892482488194643729+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CREATED'
,p_column_display_sequence=>4
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892482576755643730+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>5
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892482619498643730+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>6
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892482758371643730+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>7
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>892482887907643730+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>8
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>896823748864204530+wwv_flow_api.g_id_offset
,p_name=>'Owner''s Details'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select a.ID,',
'       a.NAME,',
'       a.HEALTH,',
'       a.CURRENT_SPAWN,',
'       a.HUNGER,',
'       a.EXPERIENCE,',
'       p.FIRST_NAME || '' '' || p.LAST_NAME as "Player Name",',
'       a.CREATED,',
'       a.CREATED_BY,',
'       a.ROW_VERSION_NUMBER,',
'       a.UPDATED,',
'       a.UPDATED_BY',
'  from MC_AVATAR a',
'  join MC_PLAYER p',
'  on a.mc_player_id=p.id',
'  where a.ID in (select mc_avatar_id from MC_OWNERSHIP where ID=:P71_ID)'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>896824066512204533+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896824166081204533+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896824238196204533+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'HEALTH'
,p_column_display_sequence=>3
,p_column_heading=>'Health'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896824366893204533+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CURRENT_SPAWN'
,p_column_display_sequence=>4
,p_column_heading=>'Current Spawn'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896824447317204533+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'HUNGER'
,p_column_display_sequence=>5
,p_column_heading=>'Hunger'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896824560910204533+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'EXPERIENCE'
,p_column_display_sequence=>6
,p_column_heading=>'Experience'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896836437865492838+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'Player Name'
,p_column_display_sequence=>7
,p_column_heading=>'Player Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896824728647204534+wwv_flow_api.g_id_offset
,p_query_column_id=>8
,p_column_alias=>'CREATED'
,p_column_display_sequence=>8
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896824889293204534+wwv_flow_api.g_id_offset
,p_query_column_id=>9
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>9
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896824936524204534+wwv_flow_api.g_id_offset
,p_query_column_id=>10
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>10
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896825010410204534+wwv_flow_api.g_id_offset
,p_query_column_id=>11
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>11
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896825128207204534+wwv_flow_api.g_id_offset
,p_query_column_id=>12
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>12
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_region(
 p_id=>896852589774521950+wwv_flow_api.g_id_offset
,p_name=>'Chunk''s Details'
,p_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'N'
,p_region_template_options=>'#DEFAULT#'
,p_new_grid_row=>false
,p_display_point=>'BODY'
,p_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'select ID,',
'       NAME,',
'       CREATED,',
'       CREATED_BY,',
'       ROW_VERSION_NUMBER,',
'       UPDATED,',
'       UPDATED_BY',
'  from MC_CHUNK',
'  where ID in (select mc_chunk_id from MC_OWNERSHIP where ID=:P71_ID)'))
,p_source_type=>'NATIVE_SQL_REPORT'
,p_ajax_enabled=>'Y'
,p_query_row_template=>2
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>' - '
,p_query_break_cols=>'0'
,p_query_no_data_found=>'no data found'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>896852871676521953+wwv_flow_api.g_id_offset
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896852972527521953+wwv_flow_api.g_id_offset
,p_query_column_id=>2
,p_column_alias=>'NAME'
,p_column_display_sequence=>2
,p_column_heading=>'Name'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896853090075521953+wwv_flow_api.g_id_offset
,p_query_column_id=>3
,p_column_alias=>'CREATED'
,p_column_display_sequence=>3
,p_column_heading=>'Created'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896853148259521953+wwv_flow_api.g_id_offset
,p_query_column_id=>4
,p_column_alias=>'CREATED_BY'
,p_column_display_sequence=>4
,p_column_heading=>'Created By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896853264343521953+wwv_flow_api.g_id_offset
,p_query_column_id=>5
,p_column_alias=>'ROW_VERSION_NUMBER'
,p_column_display_sequence=>5
,p_column_heading=>'Row Version No.'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896853390732521953+wwv_flow_api.g_id_offset
,p_query_column_id=>6
,p_column_alias=>'UPDATED'
,p_column_display_sequence=>6
,p_column_heading=>'Updated'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>896853403153521953+wwv_flow_api.g_id_offset
,p_query_column_id=>7
,p_column_alias=>'UPDATED_BY'
,p_column_display_sequence=>7
,p_column_heading=>'Updated By'
,p_disable_sort_column=>'N'
);
wwv_flow_api.create_page_item(
 p_id=>895432033132384549+wwv_flow_api.g_id_offset
,p_name=>'P71_ID'
,p_item_sequence=>10
,p_item_plug_id=>892481847499643726+wwv_flow_api.g_id_offset
,p_display_as=>'NATIVE_HIDDEN'
,p_cMaxlength=>4000
,p_label_alignment=>'RIGHT'
,p_field_alignment=>'LEFT-CENTER'
,p_attribute_01=>'Y'
);
end;
/
prompt --application/pages/page_00101
begin
wwv_flow_api.create_page(
 p_id=>101
,p_user_interface_id=>788853004205209425+wwv_flow_api.g_id_offset
,p_name=>'Login'
,p_alias=>'LOGIN_DESKTOP'
,p_page_mode=>'NORMAL'
,p_step_title=>'Login'
,p_step_sub_title_type=>'TEXT_WITH_SUBSTITUTIONS'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>788827447128204316+wwv_flow_api.g_id_offset
,p_page_template_options=>'#DEFAULT#'
,p_dialog_chained=>'Y'
,p_overwrite_navigation_list=>'N'
,p_page_is_public_y_n=>'Y'
,p_cache_mode=>'NOCACHE'
,p_last_updated_by=>'DARIUSGXU@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20141121051729'
);
wwv_flow_api.create_page_plug(
 p_id=>788853539721209429+wwv_flow_api.g_id_offset
,p_plug_name=>'Login'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'N'
,p_plug_display_point=>'BODY'
,p_plug_source=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'username: test',
'password: test'))
,p_plug_query_row_template=>1
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>788853857073209431+wwv_flow_api.g_id_offset
,p_button_sequence=>30
,p_button_plug_id=>788853539721209429+wwv_flow_api.g_id_offset
,p_button_name=>'P101_LOGIN'
,p_button_static_id=>'P101_LOGIN'
,p_button_action=>'SUBMIT'
,p_button_template_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Login'
,p_button_position=>'REGION_TEMPLATE_NEXT'
,p_request_source=>'LOGIN'
,p_request_source_type=>'STATIC'
,p_grid_new_grid=>false
);
wwv_flow_api.create_page_item(
 p_id=>788853677564209430+wwv_flow_api.g_id_offset
,p_name=>'P101_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>788853539721209429+wwv_flow_api.g_id_offset
,p_prompt=>'Username'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_api.create_page_item(
 p_id=>788853739753209430+wwv_flow_api.g_id_offset
,p_name=>'P101_PASSWORD'
,p_item_sequence=>20
,p_item_plug_id=>788853539721209429+wwv_flow_api.g_id_offset
,p_prompt=>'Password'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_label_alignment=>'RIGHT'
,p_field_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
);
wwv_flow_api.create_page_process(
 p_id=>788854082848209432+wwv_flow_api.g_id_offset
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Set Username Cookie'
,p_process_sql_clob=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'apex_authentication.send_login_username_cookie (',
'    p_username => lower(:P101_USERNAME) );'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>788853999469209432+wwv_flow_api.g_id_offset
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Login'
,p_process_sql_clob=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'apex_authentication.login(',
'    p_username => :P101_USERNAME,',
'    p_password => :P101_PASSWORD );'))
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>788854269009209433+wwv_flow_api.g_id_offset
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Clear Page(s) Cache'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.create_page_process(
 p_id=>788854192490209432+wwv_flow_api.g_id_offset
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Username Cookie'
,p_process_sql_clob=>':P101_USERNAME := apex_authentication.get_login_username_cookie;'
);
end;
/
prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
wwv_flow_api.create_menu(
 p_id=>788854317688209433+wwv_flow_api.g_id_offset
,p_name=>' Breadcrumb'
);
end;
/
prompt --application/shared_components/user_interface/templates/page
begin
wwv_flow_api.create_template(
 p_id=>788825680144204012+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'Left Side Bar'
,p_is_popup=>false
,p_javascript_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/modernizr/2.6.2/modernizr.min.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#',
'#IMAGE_PREFIX#libraries/font-awesome/4.0.3/css/font-awesome#MIN#.css?v=#APEX_VERSION#'))
,p_header_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<!DOCTYPE html>',
'<!--[if lt IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8 lt-ie7" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 8]><html class="no-js lt-ie10 lt-ie9" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 9]><html class="no-js lt-ie10" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if gt IE 9]><!--> <html class="no-js" lang="&BROWSER_LANGUAGE."> <!--<![endif]-->',
'<head>',
'  <meta charset="utf-8">  ',
'  <title>#TITLE#</title>',
'  #APEX_CSS#',
'  #TEMPLATE_CSS#',
'  #THEME_CSS#',
'  #PAGE_CSS#',
'',
'#APEX_JAVASCRIPT#',
'#TEMPLATE_JAVASCRIPT#',
'#APPLICATION_JAVASCRIPT#',
'#PAGE_JAVASCRIPT#',
'    ',
'    ',
'  #HEAD#',
'  <meta name="viewport" content="width=device-width,initial-scale=1" />',
'</head>',
'<body #ONLOAD#>',
'#FORM_OPEN#',
'<header class="t-Header">',
'  #REGION_POSITION_07#',
'  <div class="t-Header-branding">',
'    <div class="t-Header-logo"><a href="#HOME_LINK#" class="t-Header-logo-link">#LOGO#</a></div>',
'    <div class="t-Header-userNav"><span class="t-Header-user"><span class="a-Icon icon-user"></span>&APP_USER.</span>#NAVIGATION_BAR##REGION_POSITION_08#</div>',
'  </div>',
'  <div class="t-Header-nav">',
'    #NAVIGATION_LIST#',
'    #REGION_POSITION_06#',
'  </div>',
'</header>'))
,p_box=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body">',
'  #REGION_POSITION_01#',
'  #SUCCESS_MESSAGE##NOTIFICATION_MESSAGE##GLOBAL_NOTIFICATION#',
'  <div class="t-Body-wrap">',
'    <div class="t-Body-col t-Body-col--left">',
'      <aside class="t-Body-side">',
'        #REGION_POSITION_02#',
'      </aside>',
'    </div>',
'    <div class="t-Body-col t-Body-col--main">',
'      #BODY#',
'      #REGION_POSITION_03#',
'    </div>',
'  </div>',
'</div>'))
,p_footer_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<footer class="t-Footer">',
'  #REGION_POSITION_05#',
'  #CUSTOMIZE#',
'  #SCREEN_READER_TOGGLE#',
'  #APP_VERSION#',
'</footer>',
'#FORM_CLOSE#',
'#DEVELOPER_TOOLBAR#',
'#GENERATED_CSS#',
'#GENERATED_JAVASCRIPT#',
'</body>',
'</html>'))
,p_success_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--success t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Success">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#SUCCESS_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #SUCCESS_MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Success'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_notification_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--warning t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Notification">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#ERROR_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Notification'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_navigation_bar=>'#BAR_BODY#'
,p_navbar_entry=>'<a href="#LINK#">#TEXT#</a>#EDIT#'
,p_region_table_cattributes=>' summary="" cellpadding="0" border="0" cellspacing="0" width="100%"'
,p_breadcrumb_def_reg_pos=>'REGION_POSITION_01'
,p_theme_class_id=>3
,p_error_page_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="apex_cols apex_span_12">',
'  <section class="uRegion uNoHeading uErrorRegion">',
'    <div class="uRegionContent">',
'      <p class="errorIcon"><img src="#IMAGE_PREFIX#f_spacer.gif" alt="" class="iconLarge error"/></p>',
'      <p><strong>#MESSAGE#</strong></p>',
'      <p>#ADDITIONAL_INFO#</p>',
'      <div class="uErrorTechInfo">#TECHNICAL_INFO#</div>',
'    </div>',
'    <div class="uRegionHeading">',
'      <span class="uButtonContainer">',
'        <button onclick="#BACK_LINK#" class="uButtonLarge uHotButton" type="button"><span>#OK#</span></button>',
'      </span>',
'    </div>',
'  </section>',
'</div>'))
,p_grid_type=>'FIXED'
,p_grid_max_columns=>12
,p_grid_always_use_max_columns=>true
,p_grid_has_column_span=>true
,p_grid_always_emit=>false
,p_grid_emit_empty_leading_cols=>true
,p_grid_emit_empty_trail_cols=>false
,p_grid_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="container">',
'#ROWS#',
'</div>'))
,p_grid_row_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="row">',
'#COLUMNS#',
'</div>'))
,p_grid_column_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="col col-#COLUMN_SPAN_NUMBER# #ATTRIBUTES#">',
'#CONTENT#',
'</div>'))
,p_grid_first_column_attributes=>'alpha'
,p_grid_last_column_attributes=>'omega'
,p_grid_javascript_debug_code=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'apex.jQuery(document)',
'    .on("apex-devbar-grid-debug-on", console.log(''show grid''))',
'    .on("apex-devbar-grid-debug-off", console.log(''hide grid''));'))
,p_dialog_js_init_code=>'apex.navigation.dialog(#PAGE_URL#,{title:#TITLE#,height:#DIALOG_HEIGHT#,width:#DIALOG_WIDTH#,maxWidth:#DIALOG_MAX_WIDTH#,modal:#IS_MODAL#,dialog:#DIALOG#,#DIALOG_ATTRIBUTES#},#DIALOG_CSS_CLASSES#,#TRIGGERING_ELEMENT#);'
,p_dialog_js_close_code=>'apex.navigation.dialog.close(#IS_MODAL#,#TARGET#);'
,p_dialog_js_cancel_code=>'apex.navigation.dialog.cancel(#IS_MODAL#);'
,p_translate_this_template=>'N'
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788825752797204013+wwv_flow_api.g_id_offset
,p_page_template_id=>788825680144204012+wwv_flow_api.g_id_offset
,p_name=>'Body Header'
,p_placeholder=>'REGION_POSITION_01'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788825838175204013+wwv_flow_api.g_id_offset
,p_page_template_id=>788825680144204012+wwv_flow_api.g_id_offset
,p_name=>'Content Body'
,p_placeholder=>'BODY'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788825941436204013+wwv_flow_api.g_id_offset
,p_page_template_id=>788825680144204012+wwv_flow_api.g_id_offset
,p_name=>'Content Body (2)'
,p_placeholder=>'REGION_POSITION_03'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788826075947204013+wwv_flow_api.g_id_offset
,p_page_template_id=>788825680144204012+wwv_flow_api.g_id_offset
,p_name=>'Footer'
,p_placeholder=>'REGION_POSITION_05'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788826173511204013+wwv_flow_api.g_id_offset
,p_page_template_id=>788825680144204012+wwv_flow_api.g_id_offset
,p_name=>'Global Navigation'
,p_placeholder=>'REGION_POSITION_08'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788826202010204013+wwv_flow_api.g_id_offset
,p_page_template_id=>788825680144204012+wwv_flow_api.g_id_offset
,p_name=>'Left Column'
,p_placeholder=>'REGION_POSITION_02'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788826367322204013+wwv_flow_api.g_id_offset
,p_page_template_id=>788825680144204012+wwv_flow_api.g_id_offset
,p_name=>'Page Header'
,p_placeholder=>'REGION_POSITION_07'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788826476801204013+wwv_flow_api.g_id_offset
,p_page_template_id=>788825680144204012+wwv_flow_api.g_id_offset
,p_name=>'Page Navigation'
,p_placeholder=>'REGION_POSITION_06'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_template(
 p_id=>788826571579204169+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'Left and Right Side Columns'
,p_is_popup=>false
,p_javascript_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/modernizr/2.6.2/modernizr.min.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#',
'#IMAGE_PREFIX#libraries/font-awesome/4.0.3/css/font-awesome#MIN#.css?v=#APEX_VERSION#'))
,p_header_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<!DOCTYPE html>',
'<!--[if lt IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8 lt-ie7" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 8]><html class="no-js lt-ie10 lt-ie9" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 9]><html class="no-js lt-ie10" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if gt IE 9]><!--> <html class="no-js" lang="&BROWSER_LANGUAGE."> <!--<![endif]-->',
'<head>',
'  <meta charset="utf-8">  ',
'  <title>#TITLE#</title>',
'  #APEX_CSS#',
'  #TEMPLATE_CSS#',
'  #THEME_CSS#',
'  #PAGE_CSS#',
'',
'    ',
'#APEX_JAVASCRIPT#',
'#TEMPLATE_JAVASCRIPT#',
'#APPLICATION_JAVASCRIPT#',
'#PAGE_JAVASCRIPT#',
'    ',
'    ',
'  #HEAD#',
'  <meta name="viewport" content="width=device-width,initial-scale=1" />',
'</head>',
'<body #ONLOAD#>',
'#FORM_OPEN#',
'<header class="t-Header">',
'  #REGION_POSITION_07#',
'  <div class="t-Header-branding">',
'    <div class="t-Header-logo"><a href="#HOME_LINK#" class="t-Header-logo-link">#LOGO#</a></div>',
'    <div class="t-Header-userNav"><span class="t-Header-user"><span class="a-Icon icon-user"></span>&APP_USER.</span>#NAVIGATION_BAR##REGION_POSITION_08#</div>',
'  </div>',
'  <div class="t-Header-nav">',
'    #NAVIGATION_LIST#',
'    #REGION_POSITION_06#',
'  </div>',
'</header>'))
,p_box=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body">',
'  #REGION_POSITION_01#',
'  #SUCCESS_MESSAGE##NOTIFICATION_MESSAGE##GLOBAL_NOTIFICATION#',
'  <div class="t-Body-wrap">',
'    <div class="t-Body-col t-Body-col--left">',
'      <aside class="t-Body-side">',
'        #REGION_POSITION_02#',
'      </aside>',
'    </div>',
'    <div class="t-Body-col t-Body-col--main">',
'      #BODY#',
'    </div>',
'    <div class="t-Body-col t-Body-col--right">',
'      <aside class="t-Body-side">',
'        #REGION_POSITION_03#',
'      </aside>',
'    </div>',
'  </div>',
'</div>'))
,p_footer_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<footer class="t-Footer">',
'  #REGION_POSITION_05#',
'  #CUSTOMIZE#',
'  #SCREEN_READER_TOGGLE#',
'  #APP_VERSION#',
'</footer>',
'#FORM_CLOSE#',
'#DEVELOPER_TOOLBAR#',
'#GENERATED_CSS#',
'#GENERATED_JAVASCRIPT#',
'</body>',
'</html>'))
,p_success_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--success t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Success">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#SUCCESS_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #SUCCESS_MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Success'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_notification_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--warning t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Notification">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#ERROR_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Notification'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_navigation_bar=>'#BAR_BODY#'
,p_navbar_entry=>'<a href="#LINK#">#TEXT#</a>#EDIT#'
,p_region_table_cattributes=>' summary="" cellpadding="0" border="0" cellspacing="0" width="100%"'
,p_breadcrumb_def_reg_pos=>'REGION_POSITION_01'
,p_theme_class_id=>3
,p_error_page_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="apex_cols apex_span_12">',
'  <section class="uRegion uNoHeading uErrorRegion">',
'    <div class="uRegionContent">',
'      <p class="errorIcon"><img src="#IMAGE_PREFIX#f_spacer.gif" alt="" class="iconLarge error"/></p>',
'      <p><strong>#MESSAGE#</strong></p>',
'      <p>#ADDITIONAL_INFO#</p>',
'      <div class="uErrorTechInfo">#TECHNICAL_INFO#</div>',
'    </div>',
'    <div class="uRegionHeading">',
'      <span class="uButtonContainer">',
'        <button onclick="#BACK_LINK#" class="uButtonLarge uHotButton" type="button"><span>#OK#</span></button>',
'      </span>',
'    </div>',
'  </section>',
'</div>'))
,p_grid_type=>'FIXED'
,p_grid_max_columns=>12
,p_grid_always_use_max_columns=>true
,p_grid_has_column_span=>true
,p_grid_always_emit=>false
,p_grid_emit_empty_leading_cols=>true
,p_grid_emit_empty_trail_cols=>false
,p_grid_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="container">',
'#ROWS#',
'</div>'))
,p_grid_row_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="row">',
'#COLUMNS#',
'</div>'))
,p_grid_column_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="col col-#COLUMN_SPAN_NUMBER# #ATTRIBUTES#">',
'#CONTENT#',
'</div>'))
,p_grid_first_column_attributes=>'alpha'
,p_grid_last_column_attributes=>'omega'
,p_grid_javascript_debug_code=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'apex.jQuery(document)',
'    .on("apex-devbar-grid-debug-on", console.log(''show grid''))',
'    .on("apex-devbar-grid-debug-off", console.log(''hide grid''));'))
,p_dialog_js_init_code=>'apex.navigation.dialog(#PAGE_URL#,{title:#TITLE#,height:#DIALOG_HEIGHT#,width:#DIALOG_WIDTH#,maxWidth:#DIALOG_MAX_WIDTH#,modal:#IS_MODAL#,dialog:#DIALOG#,#DIALOG_ATTRIBUTES#},#DIALOG_CSS_CLASSES#,#TRIGGERING_ELEMENT#);'
,p_dialog_js_close_code=>'apex.navigation.dialog.close(#IS_MODAL#,#TARGET#);'
,p_dialog_js_cancel_code=>'apex.navigation.dialog.cancel(#IS_MODAL#);'
,p_translate_this_template=>'N'
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788826664214204169+wwv_flow_api.g_id_offset
,p_page_template_id=>788826571579204169+wwv_flow_api.g_id_offset
,p_name=>'Body Header'
,p_placeholder=>'REGION_POSITION_01'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788826730803204169+wwv_flow_api.g_id_offset
,p_page_template_id=>788826571579204169+wwv_flow_api.g_id_offset
,p_name=>'Content Body'
,p_placeholder=>'BODY'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788826848399204169+wwv_flow_api.g_id_offset
,p_page_template_id=>788826571579204169+wwv_flow_api.g_id_offset
,p_name=>'Footer'
,p_placeholder=>'REGION_POSITION_05'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788826915459204169+wwv_flow_api.g_id_offset
,p_page_template_id=>788826571579204169+wwv_flow_api.g_id_offset
,p_name=>'Global Navigation'
,p_placeholder=>'REGION_POSITION_08'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788827073578204169+wwv_flow_api.g_id_offset
,p_page_template_id=>788826571579204169+wwv_flow_api.g_id_offset
,p_name=>'Left Column'
,p_placeholder=>'REGION_POSITION_02'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788827157167204169+wwv_flow_api.g_id_offset
,p_page_template_id=>788826571579204169+wwv_flow_api.g_id_offset
,p_name=>'Page Header'
,p_placeholder=>'REGION_POSITION_07'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788827202006204169+wwv_flow_api.g_id_offset
,p_page_template_id=>788826571579204169+wwv_flow_api.g_id_offset
,p_name=>'Page Navigation'
,p_placeholder=>'REGION_POSITION_06'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788827317069204169+wwv_flow_api.g_id_offset
,p_page_template_id=>788826571579204169+wwv_flow_api.g_id_offset
,p_name=>'Right Column'
,p_placeholder=>'REGION_POSITION_03'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_template(
 p_id=>788827447128204316+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'Login'
,p_is_popup=>false
,p_javascript_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/modernizr/2.6.2/modernizr.min.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#',
'#IMAGE_PREFIX#libraries/font-awesome/4.0.3/css/font-awesome#MIN#.css?v=#APEX_VERSION#'))
,p_header_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<!DOCTYPE html>',
'<!--[if lt IE 7]><html class="html-login no-js lt-ie10 lt-ie9 lt-ie8 lt-ie7" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 7]><html class="html-login no-js lt-ie10 lt-ie9 lt-ie8" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 8]><html class="html-login no-js lt-ie10 lt-ie9" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 9]><html class="html-login no-js lt-ie10" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if gt IE 9]><!--> <html class="html-login no-js" lang="&BROWSER_LANGUAGE."> <!--<![endif]-->',
'<head>',
'  <meta charset="utf-8">  ',
'  <title>#TITLE#</title>',
'  #APEX_CSS#',
'  #TEMPLATE_CSS#',
'  #THEME_CSS#',
'  #PAGE_CSS#',
'',
'    ',
'#APEX_JAVASCRIPT#',
'#TEMPLATE_JAVASCRIPT#',
'#APPLICATION_JAVASCRIPT#',
'#PAGE_JAVASCRIPT#',
'    ',
'    ',
'  #HEAD#',
'  <meta name="viewport" content="width=device-width,initial-scale=1" />',
'</head>',
'<body class="t-PageBody--login #PAGE_CSS_CLASSES#" #ONLOAD#>',
'#FORM_OPEN#'))
,p_box=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body">',
'  #REGION_POSITION_01#',
'  #SUCCESS_MESSAGE##NOTIFICATION_MESSAGE##GLOBAL_NOTIFICATION#',
'  <div class="t-Body-wrap">',
'    <div class="t-Body-col t-Body-col--main">',
'      #REGION_POSITION_02#',
'      #BODY#',
'      #REGION_POSITION_03#',
'    </div>',
'  </div>',
'</div>'))
,p_footer_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#FORM_CLOSE#',
'#DEVELOPER_TOOLBAR#',
'#GENERATED_CSS#',
'#GENERATED_JAVASCRIPT#',
'</body>',
'</html>'))
,p_success_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--success t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Success">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#SUCCESS_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #SUCCESS_MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Success'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_notification_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--warning t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Notification">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#ERROR_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Notification'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_navigation_bar=>'#BAR_BODY#'
,p_navbar_entry=>'<a href="#LINK#">#TEXT#</a>#EDIT#'
,p_region_table_cattributes=>' summary="" cellpadding="0" border="0" cellspacing="0" width="100%"'
,p_breadcrumb_def_reg_pos=>'REGION_POSITION_01'
,p_theme_class_id=>3
,p_error_page_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Alert t-Alert--danger t-Alert--wizard t-Alert--defaultIcons">',
'  <div class="t-Alert-wrap">',
'    <div class="t-Alert-icon">',
'      <span class="t-Icon"></span>',
'    </div>',
'    <div class="t-Alert-content">',
'      <div class="t-Alert-body">',
'        <h3>#MESSAGE#</h3>',
'        <p>#ADDITIONAL_INFO#</p>',
'        <div class="t-Alert-inset">#TECHNICAL_INFO#</div>',
'      </div>',
'    </div>',
'    <div class="t-Alert-buttons">',
'      <button onclick="#BACK_LINK#" class="t-Button t-Button--hot w50p t-Button--large" type="button">#OK#</button>',
'    </div>',
'  </div>',
'</div>'))
,p_grid_type=>'FIXED'
,p_grid_max_columns=>12
,p_grid_always_use_max_columns=>true
,p_grid_has_column_span=>true
,p_grid_always_emit=>false
,p_grid_emit_empty_leading_cols=>true
,p_grid_emit_empty_trail_cols=>false
,p_grid_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="container">',
'#ROWS#',
'</div>'))
,p_grid_row_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="row">',
'#COLUMNS#',
'</div>'))
,p_grid_column_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="col col-#COLUMN_SPAN_NUMBER# #ATTRIBUTES#">',
'#CONTENT#',
'</div>'))
,p_grid_first_column_attributes=>'alpha'
,p_grid_last_column_attributes=>'omega'
,p_grid_javascript_debug_code=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'apex.jQuery(document)',
'    .on("apex-devbar-grid-debug-on", console.log(''show grid''))',
'    .on("apex-devbar-grid-debug-off", console.log(''hide grid''));'))
,p_dialog_js_init_code=>'apex.navigation.dialog(#PAGE_URL#,{title:#TITLE#,height:#DIALOG_HEIGHT#,width:#DIALOG_WIDTH#,maxWidth:#DIALOG_MAX_WIDTH#,modal:#IS_MODAL#,dialog:#DIALOG#,#DIALOG_ATTRIBUTES#},#DIALOG_CSS_CLASSES#,#TRIGGERING_ELEMENT#);'
,p_dialog_js_close_code=>'apex.navigation.dialog.close(#IS_MODAL#,#TARGET#);'
,p_dialog_js_cancel_code=>'apex.navigation.dialog.cancel(#IS_MODAL#);'
,p_translate_this_template=>'N'
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788827558597204316+wwv_flow_api.g_id_offset
,p_page_template_id=>788827447128204316+wwv_flow_api.g_id_offset
,p_name=>'Body Header'
,p_placeholder=>'REGION_POSITION_01'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788827618068204316+wwv_flow_api.g_id_offset
,p_page_template_id=>788827447128204316+wwv_flow_api.g_id_offset
,p_name=>'Content Body'
,p_placeholder=>'BODY'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788827780686204316+wwv_flow_api.g_id_offset
,p_page_template_id=>788827447128204316+wwv_flow_api.g_id_offset
,p_name=>'Footer'
,p_placeholder=>'REGION_POSITION_05'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788827892832204316+wwv_flow_api.g_id_offset
,p_page_template_id=>788827447128204316+wwv_flow_api.g_id_offset
,p_name=>'Global Navigation'
,p_placeholder=>'REGION_POSITION_08'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788827982093204316+wwv_flow_api.g_id_offset
,p_page_template_id=>788827447128204316+wwv_flow_api.g_id_offset
,p_name=>'Left Column'
,p_placeholder=>'REGION_POSITION_02'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788828091083204316+wwv_flow_api.g_id_offset
,p_page_template_id=>788827447128204316+wwv_flow_api.g_id_offset
,p_name=>'Page Header'
,p_placeholder=>'REGION_POSITION_07'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788828129916204316+wwv_flow_api.g_id_offset
,p_page_template_id=>788827447128204316+wwv_flow_api.g_id_offset
,p_name=>'Page Navigation'
,p_placeholder=>'REGION_POSITION_06'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788828294961204316+wwv_flow_api.g_id_offset
,p_page_template_id=>788827447128204316+wwv_flow_api.g_id_offset
,p_name=>'Right Column'
,p_placeholder=>'REGION_POSITION_03'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_template(
 p_id=>788828374944204471+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'Master Detail'
,p_is_popup=>false
,p_javascript_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/modernizr/2.6.2/modernizr.min.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#',
'#IMAGE_PREFIX#libraries/font-awesome/4.0.3/css/font-awesome#MIN#.css?v=#APEX_VERSION#'))
,p_header_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<!DOCTYPE html>',
'<!--[if lt IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8 lt-ie7" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 8]><html class="no-js lt-ie10 lt-ie9" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 9]><html class="no-js lt-ie10" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if gt IE 9]><!--> <html class="no-js" lang="&BROWSER_LANGUAGE."> <!--<![endif]-->',
'<head>',
'  <meta charset="utf-8">  ',
'  <title>#TITLE#</title>',
'  #APEX_CSS#',
'  #TEMPLATE_CSS#',
'  #THEME_CSS#',
'  #PAGE_CSS#',
'',
'    ',
'#APEX_JAVASCRIPT#',
'#TEMPLATE_JAVASCRIPT#',
'#APPLICATION_JAVASCRIPT#',
'#PAGE_JAVASCRIPT#',
'    ',
'    ',
'  #HEAD#',
'  <meta name="viewport" content="width=device-width,initial-scale=1" />',
'</head>',
'<body #ONLOAD#>',
'#FORM_OPEN#',
'<header class="t-Header">',
'  #REGION_POSITION_07#',
'  <div class="t-Header-branding">',
'    <div class="t-Header-logo"><a href="#HOME_LINK#" class="t-Header-logo-link">#LOGO#</a></div>',
'    <div class="t-Header-userNav"><span class="t-Header-user"><span class="a-Icon icon-user"></span>&APP_USER.</span>#NAVIGATION_BAR##REGION_POSITION_08#</div>',
'  </div>',
'  <div class="t-Header-nav">',
'    #NAVIGATION_LIST#',
'    #REGION_POSITION_06#',
'  </div>',
'</header>'))
,p_box=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body t-ContentFrame">',
'  #REGION_POSITION_01#',
'  #SUCCESS_MESSAGE##NOTIFICATION_MESSAGE##GLOBAL_NOTIFICATION#',
'  <div class="t-Body-wrap t-ContentFrame-wrap">',
'    <div class="t-Body-col t-Body-col--main t-ContentFrame-main">',
'        #REGION_POSITION_02#',
'        #BODY#',
'    </div>',
'    <div class="t-Body-col t-Body-col--right t-ContentFrame-side">',
'      <aside class="t-Body-side">',
'        #REGION_POSITION_03#',
'      </aside>',
'    </div>',
'  </div>',
'</div>'))
,p_footer_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<footer class="t-Footer">',
'  #REGION_POSITION_05#',
'  #CUSTOMIZE#',
'  #SCREEN_READER_TOGGLE#',
'  #APP_VERSION#',
'</footer>',
'#FORM_CLOSE#',
'#DEVELOPER_TOOLBAR#',
'#GENERATED_CSS#',
'#GENERATED_JAVASCRIPT#',
'</body>',
'</html>'))
,p_success_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--success t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Success">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#SUCCESS_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #SUCCESS_MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Success'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_notification_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--warning t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Notification">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#ERROR_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Notification'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_navigation_bar=>'#BAR_BODY#'
,p_navbar_entry=>'<a href="#LINK#">#TEXT#</a>#EDIT#'
,p_region_table_cattributes=>' summary="" cellpadding="0" border="0" cellspacing="0" width="100%"'
,p_breadcrumb_def_reg_pos=>'REGION_POSITION_01'
,p_theme_class_id=>3
,p_error_page_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="apex_cols apex_span_12">',
'  <section class="uRegion uNoHeading uErrorRegion">',
'    <div class="uRegionContent">',
'      <p class="errorIcon"><img src="#IMAGE_PREFIX#f_spacer.gif" alt="" class="iconLarge error"/></p>',
'      <p><strong>#MESSAGE#</strong></p>',
'      <p>#ADDITIONAL_INFO#</p>',
'      <div class="uErrorTechInfo">#TECHNICAL_INFO#</div>',
'    </div>',
'    <div class="uRegionHeading">',
'      <span class="uButtonContainer">',
'        <button onclick="#BACK_LINK#" class="uButtonLarge uHotButton" type="button"><span>#OK#</span></button>',
'      </span>',
'    </div>',
'  </section>',
'</div>'))
,p_grid_type=>'FIXED'
,p_grid_max_columns=>12
,p_grid_always_use_max_columns=>true
,p_grid_has_column_span=>true
,p_grid_always_emit=>false
,p_grid_emit_empty_leading_cols=>true
,p_grid_emit_empty_trail_cols=>false
,p_grid_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="container">',
'#ROWS#',
'</div>'))
,p_grid_row_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="row">',
'#COLUMNS#',
'</div>'))
,p_grid_column_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="col col-#COLUMN_SPAN_NUMBER# #ATTRIBUTES#">',
'#CONTENT#',
'</div>'))
,p_grid_first_column_attributes=>'alpha'
,p_grid_last_column_attributes=>'omega'
,p_grid_javascript_debug_code=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'apex.jQuery(document)',
'    .on("apex-devbar-grid-debug-on", console.log(''show grid''))',
'    .on("apex-devbar-grid-debug-off", console.log(''hide grid''));'))
,p_dialog_js_init_code=>'apex.navigation.dialog(#PAGE_URL#,{title:#TITLE#,height:#DIALOG_HEIGHT#,width:#DIALOG_WIDTH#,maxWidth:#DIALOG_MAX_WIDTH#,modal:#IS_MODAL#,dialog:#DIALOG#,#DIALOG_ATTRIBUTES#},#DIALOG_CSS_CLASSES#,#TRIGGERING_ELEMENT#);'
,p_dialog_js_close_code=>'apex.navigation.dialog.close(#IS_MODAL#,#TARGET#);'
,p_dialog_js_cancel_code=>'apex.navigation.dialog.cancel(#IS_MODAL#);'
,p_translate_this_template=>'N'
);
end;
/
begin
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788828457849204471+wwv_flow_api.g_id_offset
,p_page_template_id=>788828374944204471+wwv_flow_api.g_id_offset
,p_name=>'Body Header'
,p_placeholder=>'REGION_POSITION_01'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788828568476204471+wwv_flow_api.g_id_offset
,p_page_template_id=>788828374944204471+wwv_flow_api.g_id_offset
,p_name=>'Content Body'
,p_placeholder=>'BODY'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788828672319204471+wwv_flow_api.g_id_offset
,p_page_template_id=>788828374944204471+wwv_flow_api.g_id_offset
,p_name=>'Content Body (1)'
,p_placeholder=>'REGION_POSITION_02'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788828794594204471+wwv_flow_api.g_id_offset
,p_page_template_id=>788828374944204471+wwv_flow_api.g_id_offset
,p_name=>'Footer'
,p_placeholder=>'REGION_POSITION_05'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788828827122204471+wwv_flow_api.g_id_offset
,p_page_template_id=>788828374944204471+wwv_flow_api.g_id_offset
,p_name=>'Global Navigation'
,p_placeholder=>'REGION_POSITION_08'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788828966423204471+wwv_flow_api.g_id_offset
,p_page_template_id=>788828374944204471+wwv_flow_api.g_id_offset
,p_name=>'Page Header'
,p_placeholder=>'REGION_POSITION_07'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788829068254204471+wwv_flow_api.g_id_offset
,p_page_template_id=>788828374944204471+wwv_flow_api.g_id_offset
,p_name=>'Page Navigation'
,p_placeholder=>'REGION_POSITION_06'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788829175006204471+wwv_flow_api.g_id_offset
,p_page_template_id=>788828374944204471+wwv_flow_api.g_id_offset
,p_name=>'Right Column'
,p_placeholder=>'REGION_POSITION_03'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_template(
 p_id=>788829236861204619+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'Modal Dialog'
,p_is_popup=>true
,p_javascript_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/modernizr/2.6.2/modernizr.min.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#',
'#IMAGE_PREFIX#libraries/font-awesome/4.0.3/css/font-awesome#MIN#.css?v=#APEX_VERSION#'))
,p_header_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<!DOCTYPE html>',
'<!--[if lt IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8 lt-ie7" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 8]><html class="no-js lt-ie10 lt-ie9" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 9]><html class="no-js lt-ie10" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if gt IE 9]><!--> <html class="no-js" lang="&BROWSER_LANGUAGE."> <!--<![endif]-->',
'<head>',
'  <meta charset="utf-8">  ',
'  <title>#TITLE#</title>',
'  #APEX_CSS#',
'  #TEMPLATE_CSS#',
'  #THEME_CSS#',
'  #PAGE_CSS#',
'',
'    ',
'#APEX_JAVASCRIPT#',
'#TEMPLATE_JAVASCRIPT#',
'#APPLICATION_JAVASCRIPT#',
'#PAGE_JAVASCRIPT#',
'    ',
'    ',
'  #HEAD#',
'  <meta name="viewport" content="width=device-width,initial-scale=1" />',
'</head>',
'<body class="t-Dialog-page #DIALOG_CSS_CLASSES# #PAGE_CSS_CLASSES#" #ONLOAD#>',
'#FORM_OPEN#'))
,p_box=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Dialog" role="dialog" aria-label="#TITLE#">',
'#REGION_POSITION_01#',
'#SUCCESS_MESSAGE##NOTIFICATION_MESSAGE##GLOBAL_NOTIFICATION#',
'#REGION_POSITION_02#',
'#BODY#',
'#REGION_POSITION_03#',
'</div>'))
,p_footer_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#FORM_CLOSE#',
'#DEVELOPER_TOOLBAR#',
'#GENERATED_CSS#',
'#GENERATED_JAVASCRIPT#',
'</body>',
'</html>'))
,p_success_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--success t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Success">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#SUCCESS_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #SUCCESS_MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Success'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_notification_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--warning t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Notification">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#ERROR_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Notification'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_navigation_bar=>'#BAR_BODY#'
,p_navbar_entry=>'<a href="#LINK#">#TEXT#</a>#EDIT#'
,p_region_table_cattributes=>' summary="" cellpadding="0" border="0" cellspacing="0" width="100%"'
,p_breadcrumb_def_reg_pos=>'REGION_POSITION_01'
,p_theme_class_id=>3
,p_error_page_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="apex_cols apex_span_12">',
'  <section class="uRegion uNoHeading uErrorRegion">',
'    <div class="uRegionContent">',
'      <p class="errorIcon"><img src="#IMAGE_PREFIX#f_spacer.gif" alt="" class="iconLarge error"/></p>',
'      <p><strong>#MESSAGE#</strong></p>',
'      <p>#ADDITIONAL_INFO#</p>',
'      <div class="uErrorTechInfo">#TECHNICAL_INFO#</div>',
'    </div>',
'    <div class="uRegionHeading">',
'      <span class="uButtonContainer">',
'        <button onclick="#BACK_LINK#" class="uButtonLarge uHotButton" type="button"><span>#OK#</span></button>',
'      </span>',
'    </div>',
'  </section>',
'</div>'))
,p_grid_type=>'FIXED'
,p_grid_max_columns=>12
,p_grid_always_use_max_columns=>true
,p_grid_has_column_span=>true
,p_grid_always_emit=>false
,p_grid_emit_empty_leading_cols=>true
,p_grid_emit_empty_trail_cols=>false
,p_grid_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="container">',
'#ROWS#',
'</div>'))
,p_grid_row_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="row">',
'#COLUMNS#',
'</div>'))
,p_grid_column_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="col col-#COLUMN_SPAN_NUMBER# #ATTRIBUTES#">',
'#CONTENT#',
'</div>'))
,p_grid_first_column_attributes=>'alpha'
,p_grid_last_column_attributes=>'omega'
,p_grid_javascript_debug_code=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'apex.jQuery(document)',
'    .on("apex-devbar-grid-debug-on", console.log(''show grid''))',
'    .on("apex-devbar-grid-debug-off", console.log(''hide grid''));'))
,p_dialog_js_init_code=>'apex.navigation.dialog(#PAGE_URL#,{title:#TITLE#,height:#DIALOG_HEIGHT#,width:#DIALOG_WIDTH#,maxWidth:#DIALOG_MAX_WIDTH#,modal:#IS_MODAL#,dialog:#DIALOG#,#DIALOG_ATTRIBUTES#},#DIALOG_CSS_CLASSES#,#TRIGGERING_ELEMENT#);'
,p_dialog_js_close_code=>'apex.navigation.dialog.close(#IS_MODAL#,#TARGET#);'
,p_dialog_js_cancel_code=>'apex.navigation.dialog.cancel(#IS_MODAL#);'
,p_dialog_height=>'400'
,p_dialog_width=>'600'
,p_dialog_max_width=>'960'
,p_dialog_css_classes=>'t-Dialog--standard'
,p_translate_this_template=>'N'
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788829389590204620+wwv_flow_api.g_id_offset
,p_page_template_id=>788829236861204619+wwv_flow_api.g_id_offset
,p_name=>'Body Header'
,p_placeholder=>'REGION_POSITION_01'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788829478683204620+wwv_flow_api.g_id_offset
,p_page_template_id=>788829236861204619+wwv_flow_api.g_id_offset
,p_name=>'Content Body'
,p_placeholder=>'BODY'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788829562374204620+wwv_flow_api.g_id_offset
,p_page_template_id=>788829236861204619+wwv_flow_api.g_id_offset
,p_name=>'Footer'
,p_placeholder=>'REGION_POSITION_05'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788829629423204620+wwv_flow_api.g_id_offset
,p_page_template_id=>788829236861204619+wwv_flow_api.g_id_offset
,p_name=>'Global Navigation'
,p_placeholder=>'REGION_POSITION_08'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788829708250204620+wwv_flow_api.g_id_offset
,p_page_template_id=>788829236861204619+wwv_flow_api.g_id_offset
,p_name=>'Left Column'
,p_placeholder=>'REGION_POSITION_02'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788829845080204620+wwv_flow_api.g_id_offset
,p_page_template_id=>788829236861204619+wwv_flow_api.g_id_offset
,p_name=>'Page Header'
,p_placeholder=>'REGION_POSITION_07'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788829989914204620+wwv_flow_api.g_id_offset
,p_page_template_id=>788829236861204619+wwv_flow_api.g_id_offset
,p_name=>'Page Navigation'
,p_placeholder=>'REGION_POSITION_06'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788830078010204620+wwv_flow_api.g_id_offset
,p_page_template_id=>788829236861204619+wwv_flow_api.g_id_offset
,p_name=>'Right Column'
,p_placeholder=>'REGION_POSITION_03'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_template(
 p_id=>788830151089204775+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'Page (No Side Bars)'
,p_is_popup=>false
,p_javascript_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/modernizr/2.6.2/modernizr.min.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#',
'#IMAGE_PREFIX#libraries/font-awesome/4.0.3/css/font-awesome#MIN#.css?v=#APEX_VERSION#'))
,p_header_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<!DOCTYPE html>',
'<!--[if lt IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8 lt-ie7" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 8]><html class="no-js lt-ie10 lt-ie9" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 9]><html class="no-js lt-ie10" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if gt IE 9]><!--> <html class="no-js" lang="&BROWSER_LANGUAGE."> <!--<![endif]-->',
'<head>',
'  <meta charset="utf-8">  ',
'  <title>#TITLE#</title>',
'  #APEX_CSS#',
'  #TEMPLATE_CSS#',
'  #THEME_CSS#',
'  #PAGE_CSS#',
'',
'    ',
'#APEX_JAVASCRIPT#',
'#TEMPLATE_JAVASCRIPT#',
'#APPLICATION_JAVASCRIPT#',
'#PAGE_JAVASCRIPT#',
'    ',
'    ',
'  #HEAD#',
'  <meta name="viewport" content="width=device-width,initial-scale=1" />',
'</head>',
'<body #ONLOAD#>',
'#FORM_OPEN#',
'<header class="t-Header">',
'  #REGION_POSITION_07#',
'  <div class="t-Header-branding">',
'    <div class="t-Header-logo"><a href="#HOME_LINK#" class="t-Header-logo-link">#LOGO#</a></div>',
'    <div class="t-Header-userNav"><span class="t-Header-user"><span class="a-Icon icon-user"></span>&APP_USER.</span>#NAVIGATION_BAR##REGION_POSITION_08#</div>',
'  </div>',
'  <div class="t-Header-nav">',
'    #NAVIGATION_LIST#',
'    #REGION_POSITION_06#',
'  </div>',
'</header>'))
,p_box=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body">',
'  #REGION_POSITION_01#',
'  #SUCCESS_MESSAGE##NOTIFICATION_MESSAGE##GLOBAL_NOTIFICATION#',
'  <div class="t-Body-wrap">',
'    <div class="t-Body-col t-Body-col--main">',
'      #REGION_POSITION_02#',
'      #BODY#',
'      #REGION_POSITION_03#',
'    </div>',
'  </div>',
'</div>'))
,p_footer_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<footer class="t-Footer">',
'  #REGION_POSITION_05#',
'  #CUSTOMIZE#',
'  #SCREEN_READER_TOGGLE#',
'  #APP_VERSION#',
'</footer>',
'#FORM_CLOSE#',
'#DEVELOPER_TOOLBAR#',
'#GENERATED_CSS#',
'#GENERATED_JAVASCRIPT#',
'</body>',
'</html>'))
,p_success_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--success t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Success">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#SUCCESS_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #SUCCESS_MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Success'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_notification_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--warning t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Notification">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#ERROR_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Notification'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_navigation_bar=>'#BAR_BODY#'
,p_navbar_entry=>'<a href="#LINK#">#TEXT#</a>#EDIT#'
,p_region_table_cattributes=>' summary="" cellpadding="0" border="0" cellspacing="0" width="100%"'
,p_breadcrumb_def_reg_pos=>'REGION_POSITION_01'
,p_theme_class_id=>3
,p_error_page_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="apex_cols apex_span_12">',
'  <section class="uRegion uNoHeading uErrorRegion">',
'    <div class="uRegionContent">',
'      <p class="errorIcon"><img src="#IMAGE_PREFIX#f_spacer.gif" alt="" class="iconLarge error"/></p>',
'      <p><strong>#MESSAGE#</strong></p>',
'      <p>#ADDITIONAL_INFO#</p>',
'      <div class="uErrorTechInfo">#TECHNICAL_INFO#</div>',
'    </div>',
'    <div class="uRegionHeading">',
'      <span class="uButtonContainer">',
'        <button onclick="#BACK_LINK#" class="uButtonLarge uHotButton" type="button"><span>#OK#</span></button>',
'      </span>',
'    </div>',
'  </section>',
'</div>'))
,p_grid_type=>'FIXED'
,p_grid_max_columns=>12
,p_grid_always_use_max_columns=>true
,p_grid_has_column_span=>true
,p_grid_always_emit=>false
,p_grid_emit_empty_leading_cols=>true
,p_grid_emit_empty_trail_cols=>false
,p_grid_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="container">',
'#ROWS#',
'</div>'))
,p_grid_row_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="row">',
'#COLUMNS#',
'</div>'))
,p_grid_column_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="col col-#COLUMN_SPAN_NUMBER# #ATTRIBUTES#">',
'#CONTENT#',
'</div>'))
,p_grid_first_column_attributes=>'alpha'
,p_grid_last_column_attributes=>'omega'
,p_grid_javascript_debug_code=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'apex.jQuery(document)',
'    .on("apex-devbar-grid-debug-on", console.log(''show grid''))',
'    .on("apex-devbar-grid-debug-off", console.log(''hide grid''));'))
,p_dialog_js_init_code=>'apex.navigation.dialog(#PAGE_URL#,{title:#TITLE#,height:#DIALOG_HEIGHT#,width:#DIALOG_WIDTH#,maxWidth:#DIALOG_MAX_WIDTH#,modal:#IS_MODAL#,dialog:#DIALOG#,#DIALOG_ATTRIBUTES#},#DIALOG_CSS_CLASSES#,#TRIGGERING_ELEMENT#);'
,p_dialog_js_close_code=>'apex.navigation.dialog.close(#IS_MODAL#,#TARGET#);'
,p_dialog_js_cancel_code=>'apex.navigation.dialog.cancel(#IS_MODAL#);'
,p_translate_this_template=>'N'
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788830248703204775+wwv_flow_api.g_id_offset
,p_page_template_id=>788830151089204775+wwv_flow_api.g_id_offset
,p_name=>'Body Header'
,p_placeholder=>'REGION_POSITION_01'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788830395947204775+wwv_flow_api.g_id_offset
,p_page_template_id=>788830151089204775+wwv_flow_api.g_id_offset
,p_name=>'Content Body'
,p_placeholder=>'BODY'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788830475772204775+wwv_flow_api.g_id_offset
,p_page_template_id=>788830151089204775+wwv_flow_api.g_id_offset
,p_name=>'Footer'
,p_placeholder=>'REGION_POSITION_05'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788830518524204775+wwv_flow_api.g_id_offset
,p_page_template_id=>788830151089204775+wwv_flow_api.g_id_offset
,p_name=>'Global Navigation'
,p_placeholder=>'REGION_POSITION_08'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788830633747204775+wwv_flow_api.g_id_offset
,p_page_template_id=>788830151089204775+wwv_flow_api.g_id_offset
,p_name=>'Left Column'
,p_placeholder=>'REGION_POSITION_02'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788830741734204775+wwv_flow_api.g_id_offset
,p_page_template_id=>788830151089204775+wwv_flow_api.g_id_offset
,p_name=>'Page Header'
,p_placeholder=>'REGION_POSITION_07'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788830876048204775+wwv_flow_api.g_id_offset
,p_page_template_id=>788830151089204775+wwv_flow_api.g_id_offset
,p_name=>'Page Navigation'
,p_placeholder=>'REGION_POSITION_06'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788830915005204775+wwv_flow_api.g_id_offset
,p_page_template_id=>788830151089204775+wwv_flow_api.g_id_offset
,p_name=>'Right Column'
,p_placeholder=>'REGION_POSITION_03'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_template(
 p_id=>788831099284204924+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'Popup'
,p_is_popup=>false
,p_javascript_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/modernizr/2.6.2/modernizr.min.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#',
'#IMAGE_PREFIX#libraries/font-awesome/4.0.3/css/font-awesome#MIN#.css?v=#APEX_VERSION#'))
,p_header_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<!DOCTYPE html>',
'<!--[if lt IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8 lt-ie7" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 8]><html class="no-js lt-ie10 lt-ie9" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 9]><html class="no-js lt-ie10" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if gt IE 9]><!--> <html class="no-js" lang="&BROWSER_LANGUAGE."> <!--<![endif]-->',
'<head>',
'  <meta charset="utf-8">  ',
'  <title>#TITLE#</title>',
'  #APEX_CSS#',
'  #TEMPLATE_CSS#',
'  #THEME_CSS#',
'  #PAGE_CSS#',
'',
'    ',
'#APEX_JAVASCRIPT#',
'#TEMPLATE_JAVASCRIPT#',
'#APPLICATION_JAVASCRIPT#',
'#PAGE_JAVASCRIPT#',
'    ',
'    ',
'  #HEAD#',
'  <meta name="viewport" content="width=device-width,initial-scale=1" />',
'</head>',
'<body #ONLOAD#>',
'#FORM_OPEN#'))
,p_box=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body">',
'  #SUCCESS_MESSAGE##NOTIFICATION_MESSAGE##GLOBAL_NOTIFICATION#',
'  <div class="t-Body-wrap">',
'    <div class="t-Body-col t-Body-col--main">',
'      #REGION_POSITION_02#',
'      #BODY#',
'      #REGION_POSITION_03#',
'    </div>',
'  </div>',
'</div>'))
,p_footer_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<footer class="t-Footer">',
'  #REGION_POSITION_05#',
'  #CUSTOMIZE#',
'  #SCREEN_READER_TOGGLE#',
'  #APP_VERSION#',
'</footer>',
'#FORM_CLOSE#',
'#DEVELOPER_TOOLBAR#',
'#GENERATED_CSS#',
'#GENERATED_JAVASCRIPT#',
'</body>',
'</html>'))
,p_success_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--success t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Success">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#SUCCESS_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #SUCCESS_MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Success'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_notification_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--warning t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Notification">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#ERROR_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Notification'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_navigation_bar=>'#BAR_BODY#'
,p_navbar_entry=>'<a href="#LINK#">#TEXT#</a>#EDIT#'
,p_region_table_cattributes=>' summary="" cellpadding="0" border="0" cellspacing="0" width="100%"'
,p_breadcrumb_def_reg_pos=>'REGION_POSITION_01'
,p_theme_class_id=>3
,p_error_page_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="apex_cols apex_span_12">',
'  <section class="uRegion uNoHeading uErrorRegion">',
'    <div class="uRegionContent">',
'      <p class="errorIcon"><img src="#IMAGE_PREFIX#f_spacer.gif" alt="" class="iconLarge error"/></p>',
'      <p><strong>#MESSAGE#</strong></p>',
'      <p>#ADDITIONAL_INFO#</p>',
'      <div class="uErrorTechInfo">#TECHNICAL_INFO#</div>',
'    </div>',
'    <div class="uRegionHeading">',
'      <span class="uButtonContainer">',
'        <button onclick="#BACK_LINK#" class="uButtonLarge uHotButton" type="button"><span>#OK#</span></button>',
'      </span>',
'    </div>',
'  </section>',
'</div>'))
,p_grid_type=>'FIXED'
,p_grid_max_columns=>12
,p_grid_always_use_max_columns=>true
,p_grid_has_column_span=>true
,p_grid_always_emit=>false
,p_grid_emit_empty_leading_cols=>true
,p_grid_emit_empty_trail_cols=>false
,p_grid_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="container">',
'#ROWS#',
'</div>'))
,p_grid_row_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="row">',
'#COLUMNS#',
'</div>'))
,p_grid_column_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="col col-#COLUMN_SPAN_NUMBER# #ATTRIBUTES#">',
'#CONTENT#',
'</div>'))
,p_grid_first_column_attributes=>'alpha'
,p_grid_last_column_attributes=>'omega'
,p_grid_javascript_debug_code=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'apex.jQuery(document)',
'    .on("apex-devbar-grid-debug-on", console.log(''show grid''))',
'    .on("apex-devbar-grid-debug-off", console.log(''hide grid''));'))
,p_dialog_js_init_code=>'apex.navigation.dialog(#PAGE_URL#,{title:#TITLE#,height:#DIALOG_HEIGHT#,width:#DIALOG_WIDTH#,maxWidth:#DIALOG_MAX_WIDTH#,modal:#IS_MODAL#,dialog:#DIALOG#,#DIALOG_ATTRIBUTES#},#DIALOG_CSS_CLASSES#,#TRIGGERING_ELEMENT#);'
,p_dialog_js_close_code=>'apex.navigation.dialog.close(#IS_MODAL#,#TARGET#);'
,p_dialog_js_cancel_code=>'apex.navigation.dialog.cancel(#IS_MODAL#);'
,p_translate_this_template=>'N'
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788831114287204924+wwv_flow_api.g_id_offset
,p_page_template_id=>788831099284204924+wwv_flow_api.g_id_offset
,p_name=>'Body Header'
,p_placeholder=>'REGION_POSITION_01'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788831269070204924+wwv_flow_api.g_id_offset
,p_page_template_id=>788831099284204924+wwv_flow_api.g_id_offset
,p_name=>'Content Body'
,p_placeholder=>'BODY'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788831382144204924+wwv_flow_api.g_id_offset
,p_page_template_id=>788831099284204924+wwv_flow_api.g_id_offset
,p_name=>'Footer'
,p_placeholder=>'REGION_POSITION_05'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788831486646204924+wwv_flow_api.g_id_offset
,p_page_template_id=>788831099284204924+wwv_flow_api.g_id_offset
,p_name=>'Global Navigation'
,p_placeholder=>'REGION_POSITION_08'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788831524736204924+wwv_flow_api.g_id_offset
,p_page_template_id=>788831099284204924+wwv_flow_api.g_id_offset
,p_name=>'Left Column'
,p_placeholder=>'REGION_POSITION_02'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788831691178204924+wwv_flow_api.g_id_offset
,p_page_template_id=>788831099284204924+wwv_flow_api.g_id_offset
,p_name=>'Page Header'
,p_placeholder=>'REGION_POSITION_07'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788831738827204924+wwv_flow_api.g_id_offset
,p_page_template_id=>788831099284204924+wwv_flow_api.g_id_offset
,p_name=>'Page Navigation'
,p_placeholder=>'REGION_POSITION_06'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788831878256204924+wwv_flow_api.g_id_offset
,p_page_template_id=>788831099284204924+wwv_flow_api.g_id_offset
,p_name=>'Right Column'
,p_placeholder=>'REGION_POSITION_03'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_template(
 p_id=>788831908869205071+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'Right Side Bar'
,p_is_popup=>false
,p_javascript_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/modernizr/2.6.2/modernizr.min.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#',
'#IMAGE_PREFIX#libraries/font-awesome/4.0.3/css/font-awesome#MIN#.css?v=#APEX_VERSION#'))
,p_header_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<!DOCTYPE html>',
'<!--[if lt IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8 lt-ie7" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 8]><html class="no-js lt-ie10 lt-ie9" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 9]><html class="no-js lt-ie10" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if gt IE 9]><!--> <html class="no-js" lang="&BROWSER_LANGUAGE."> <!--<![endif]-->',
'<head>',
'  <meta charset="utf-8">  ',
'  <title>#TITLE#</title>',
'  #APEX_CSS#',
'  #TEMPLATE_CSS#',
'  #THEME_CSS#',
'  #PAGE_CSS#',
'',
'    ',
'#APEX_JAVASCRIPT#',
'#TEMPLATE_JAVASCRIPT#',
'#APPLICATION_JAVASCRIPT#',
'#PAGE_JAVASCRIPT#',
'    ',
'    ',
'  #HEAD#',
'  <meta name="viewport" content="width=device-width,initial-scale=1" />',
'</head>',
'<body #ONLOAD#>',
'#FORM_OPEN#',
'<header class="t-Header">',
'  #REGION_POSITION_07#',
'  <div class="t-Header-branding">',
'    <div class="t-Header-logo"><a href="#HOME_LINK#" class="t-Header-logo-link">#LOGO#</a></div>',
'    <div class="t-Header-userNav"><span class="t-Header-user"><span class="a-Icon icon-user"></span>&APP_USER.</span>#NAVIGATION_BAR##REGION_POSITION_08#</div>',
'  </div>',
'  <div class="t-Header-nav">',
'    #NAVIGATION_LIST#',
'    #REGION_POSITION_06#',
'  </div>',
'</header>'))
,p_box=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body">',
'  #REGION_POSITION_01#',
'  #SUCCESS_MESSAGE##NOTIFICATION_MESSAGE##GLOBAL_NOTIFICATION#',
'  <div class="t-Body-wrap">',
'    <div class="t-Body-col t-Body-col--main">',
'      #REGION_POSITION_02#',
'      #BODY#',
'    </div>',
'    <div class="t-Body-col t-Body-col--right">',
'      <aside class="t-Body-side">',
'        #REGION_POSITION_03#',
'      </aside>',
'    </div>',
'  </div>',
'</div>'))
,p_footer_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<footer class="t-Footer">',
'  #REGION_POSITION_05#',
'  #CUSTOMIZE#',
'  #SCREEN_READER_TOGGLE#',
'  #APP_VERSION#',
'</footer>',
'#FORM_CLOSE#',
'#DEVELOPER_TOOLBAR#',
'#GENERATED_CSS#',
'#GENERATED_JAVASCRIPT#',
'</body>',
'</html>'))
,p_success_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--success t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Success">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#SUCCESS_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #SUCCESS_MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Success'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_notification_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--warning t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Notification">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#ERROR_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Notification'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_navigation_bar=>'#BAR_BODY#'
,p_navbar_entry=>'<a href="#LINK#">#TEXT#</a>#EDIT#'
,p_region_table_cattributes=>' summary="" cellpadding="0" border="0" cellspacing="0" width="100%"'
,p_breadcrumb_def_reg_pos=>'REGION_POSITION_01'
,p_theme_class_id=>3
,p_error_page_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="apex_cols apex_span_12">',
'  <section class="uRegion uNoHeading uErrorRegion">',
'    <div class="uRegionContent">',
'      <p class="errorIcon"><img src="#IMAGE_PREFIX#f_spacer.gif" alt="" class="iconLarge error"/></p>',
'      <p><strong>#MESSAGE#</strong></p>',
'      <p>#ADDITIONAL_INFO#</p>',
'      <div class="uErrorTechInfo">#TECHNICAL_INFO#</div>',
'    </div>',
'    <div class="uRegionHeading">',
'      <span class="uButtonContainer">',
'        <button onclick="#BACK_LINK#" class="uButtonLarge uHotButton" type="button"><span>#OK#</span></button>',
'      </span>',
'    </div>',
'  </section>',
'</div>'))
,p_grid_type=>'FIXED'
,p_grid_max_columns=>12
,p_grid_always_use_max_columns=>true
,p_grid_has_column_span=>true
,p_grid_always_emit=>false
,p_grid_emit_empty_leading_cols=>true
,p_grid_emit_empty_trail_cols=>false
,p_grid_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="container">',
'#ROWS#',
'</div>'))
,p_grid_row_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="row">',
'#COLUMNS#',
'</div>'))
,p_grid_column_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="col col-#COLUMN_SPAN_NUMBER# #ATTRIBUTES#">',
'#CONTENT#',
'</div>'))
,p_grid_first_column_attributes=>'alpha'
,p_grid_last_column_attributes=>'omega'
,p_grid_javascript_debug_code=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'apex.jQuery(document)',
'    .on("apex-devbar-grid-debug-on", console.log(''show grid''))',
'    .on("apex-devbar-grid-debug-off", console.log(''hide grid''));'))
,p_dialog_js_init_code=>'apex.navigation.dialog(#PAGE_URL#,{title:#TITLE#,height:#DIALOG_HEIGHT#,width:#DIALOG_WIDTH#,maxWidth:#DIALOG_MAX_WIDTH#,modal:#IS_MODAL#,dialog:#DIALOG#,#DIALOG_ATTRIBUTES#},#DIALOG_CSS_CLASSES#,#TRIGGERING_ELEMENT#);'
,p_dialog_js_close_code=>'apex.navigation.dialog.close(#IS_MODAL#,#TARGET#);'
,p_dialog_js_cancel_code=>'apex.navigation.dialog.cancel(#IS_MODAL#);'
,p_translate_this_template=>'N'
);
end;
/
begin
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788832077724205071+wwv_flow_api.g_id_offset
,p_page_template_id=>788831908869205071+wwv_flow_api.g_id_offset
,p_name=>'Body Header'
,p_placeholder=>'REGION_POSITION_01'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788832195349205071+wwv_flow_api.g_id_offset
,p_page_template_id=>788831908869205071+wwv_flow_api.g_id_offset
,p_name=>'Content Body'
,p_placeholder=>'BODY'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788832235479205071+wwv_flow_api.g_id_offset
,p_page_template_id=>788831908869205071+wwv_flow_api.g_id_offset
,p_name=>'Content Body (1)'
,p_placeholder=>'REGION_POSITION_02'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788832320108205071+wwv_flow_api.g_id_offset
,p_page_template_id=>788831908869205071+wwv_flow_api.g_id_offset
,p_name=>'Footer'
,p_placeholder=>'REGION_POSITION_05'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788832466647205071+wwv_flow_api.g_id_offset
,p_page_template_id=>788831908869205071+wwv_flow_api.g_id_offset
,p_name=>'Global Navigation'
,p_placeholder=>'REGION_POSITION_08'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788832593538205071+wwv_flow_api.g_id_offset
,p_page_template_id=>788831908869205071+wwv_flow_api.g_id_offset
,p_name=>'Page Header'
,p_placeholder=>'REGION_POSITION_07'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788832631877205071+wwv_flow_api.g_id_offset
,p_page_template_id=>788831908869205071+wwv_flow_api.g_id_offset
,p_name=>'Page Navigation'
,p_placeholder=>'REGION_POSITION_06'
,p_has_grid_support=>false
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788832736733205071+wwv_flow_api.g_id_offset
,p_page_template_id=>788831908869205071+wwv_flow_api.g_id_offset
,p_name=>'Right Column'
,p_placeholder=>'REGION_POSITION_03'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_template(
 p_id=>788832857464205220+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'Wizard Modal Dialog'
,p_is_popup=>true
,p_javascript_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/modernizr/2.6.2/modernizr.min.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_javascript_code_onload=>'apex.theme42.initWizardModal();'
,p_css_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#',
'#IMAGE_PREFIX#libraries/font-awesome/4.0.3/css/font-awesome#MIN#.css?v=#APEX_VERSION#'))
,p_header_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<!DOCTYPE html>',
'<!--[if lt IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8 lt-ie7" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 7]><html class="no-js lt-ie10 lt-ie9 lt-ie8" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 8]><html class="no-js lt-ie10 lt-ie9" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if IE 9]><html class="no-js lt-ie10" lang="&BROWSER_LANGUAGE."> <![endif]-->',
'<!--[if gt IE 9]><!--> <html class="no-js" lang="&BROWSER_LANGUAGE."> <!--<![endif]-->',
'<head>',
'  <meta charset="utf-8">  ',
'  <title>#TITLE#</title>',
'  #APEX_CSS#',
'  #TEMPLATE_CSS#',
'  #THEME_CSS#',
'  #PAGE_CSS#',
'',
'    ',
'#APEX_JAVASCRIPT#',
'#TEMPLATE_JAVASCRIPT#',
'#APPLICATION_JAVASCRIPT#',
'#PAGE_JAVASCRIPT#',
'    ',
'    ',
'  #HEAD#',
'  <meta name="viewport" content="width=device-width,initial-scale=1" />',
'</head>',
'<body class="t-Dialog-page #DIALOG_CSS_CLASSES# #PAGE_CSS_CLASSES#" #ONLOAD#>',
'#FORM_OPEN#'))
,p_box=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Dialog" role="dialog" aria-label="#TITLE#">',
'  <div class="t-Wizard t-Wizard--modal">',
'    <div class=" t-Wizard-steps">',
'      #REGION_POSITION_01#',
'    </div>',
'    <div class="t-Wizard-body">',
'      #SUCCESS_MESSAGE##NOTIFICATION_MESSAGE##GLOBAL_NOTIFICATION#',
'      #BODY#',
'    </div>',
'    <div class="t-Wizard-footer">',
'      #REGION_POSITION_03#',
'    </div>',
'  </div>',
'</div>'))
,p_footer_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#FORM_CLOSE#',
'#DEVELOPER_TOOLBAR#',
'#GENERATED_CSS#',
'#GENERATED_JAVASCRIPT#',
'</body>',
'</html>'))
,p_success_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--success t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Success">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#SUCCESS_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #SUCCESS_MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Success'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_notification_message=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Body-alert">',
'    <div class="t-Alert t-Alert--defaultIcons t-Alert--warning t-Alert--horizontal t-Alert--colorBG" id="t_Alert_Notification">',
'      <div class="t-Alert-wrap">',
'        <div class="t-Alert-icon">',
'          <span class="t-Icon"></span>',
'        </div>',
'        <div class="t-Alert-content">',
'          <div class="t-Alert-header">',
'            <h2 class="t-Alert-title">#ERROR_MESSAGE_HEADING#</h2>',
'          </div>',
'          <div class="t-Alert-body">',
'            #MESSAGE#',
'          </div>',
'        </div>',
'        <div class="t-Alert-buttons">',
'          <button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly" onclick="apex.jQuery(''#t_Alert_Notification'').remove();" type="button" title="#CLOSE_NOTIFICATION#"><span class="t-Icon fa-times"></span></button>',
'        </div>',
'      </div>',
'    </div>',
'</div>'))
,p_navigation_bar=>'#BAR_BODY#'
,p_navbar_entry=>'<a href="#LINK#">#TEXT#</a>#EDIT#'
,p_region_table_cattributes=>' summary="" cellpadding="0" border="0" cellspacing="0" width="100%"'
,p_theme_class_id=>3
,p_error_page_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="apex_cols apex_span_12">',
'  <section class="uRegion uNoHeading uErrorRegion">',
'    <div class="uRegionContent">',
'      <p class="errorIcon"><img src="#IMAGE_PREFIX#f_spacer.gif" alt="" class="iconLarge error"/></p>',
'      <p><strong>#MESSAGE#</strong></p>',
'      <p>#ADDITIONAL_INFO#</p>',
'      <div class="uErrorTechInfo">#TECHNICAL_INFO#</div>',
'    </div>',
'    <div class="uRegionHeading">',
'      <span class="uButtonContainer">',
'        <button onclick="#BACK_LINK#" class="uButtonLarge uHotButton" type="button"><span>#OK#</span></button>',
'      </span>',
'    </div>',
'  </section>',
'</div>'))
,p_grid_type=>'FIXED'
,p_grid_max_columns=>12
,p_grid_always_use_max_columns=>true
,p_grid_has_column_span=>true
,p_grid_always_emit=>false
,p_grid_emit_empty_leading_cols=>true
,p_grid_emit_empty_trail_cols=>false
,p_grid_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="container">',
'#ROWS#',
'</div>'))
,p_grid_row_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="row">',
'#COLUMNS#',
'</div>'))
,p_grid_column_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="col col-#COLUMN_SPAN_NUMBER# #ATTRIBUTES#">',
'#CONTENT#',
'</div>'))
,p_grid_first_column_attributes=>'alpha'
,p_grid_last_column_attributes=>'omega'
,p_grid_javascript_debug_code=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'apex.jQuery(document)',
'    .on("apex-devbar-grid-debug-on", console.log(''show grid''))',
'    .on("apex-devbar-grid-debug-off", console.log(''hide grid''));'))
,p_dialog_js_init_code=>'apex.navigation.dialog(#PAGE_URL#,{title:#TITLE#,height:#DIALOG_HEIGHT#,width:#DIALOG_WIDTH#,maxWidth:#DIALOG_MAX_WIDTH#,modal:#IS_MODAL#,dialog:#DIALOG#,#DIALOG_ATTRIBUTES#},#DIALOG_CSS_CLASSES#,#TRIGGERING_ELEMENT#);'
,p_dialog_js_close_code=>'apex.navigation.dialog.close(#IS_MODAL#,#TARGET#);'
,p_dialog_js_cancel_code=>'apex.navigation.dialog.cancel(#IS_MODAL#);'
,p_dialog_height=>'480'
,p_dialog_width=>'680'
,p_dialog_max_width=>'960'
,p_dialog_css_classes=>'t-Dialog--wizard'
,p_translate_this_template=>'N'
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788832974195205220+wwv_flow_api.g_id_offset
,p_page_template_id=>788832857464205220+wwv_flow_api.g_id_offset
,p_name=>'Wizard Body'
,p_placeholder=>'BODY'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788833036791205220+wwv_flow_api.g_id_offset
,p_page_template_id=>788832857464205220+wwv_flow_api.g_id_offset
,p_name=>'Wizard Buttons'
,p_placeholder=>'REGION_POSITION_03'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
wwv_flow_api.create_page_tmpl_display_point(
 p_id=>788833150138205220+wwv_flow_api.g_id_offset
,p_page_template_id=>788832857464205220+wwv_flow_api.g_id_offset
,p_name=>'Wizard Progress Bar'
,p_placeholder=>'REGION_POSITION_01'
,p_has_grid_support=>true
,p_glv_new_row=>true
);
end;
/
prompt --application/shared_components/user_interface/templates/button
begin
wwv_flow_api.create_button_templates(
 p_id=>788847674299208649+wwv_flow_api.g_id_offset
,p_template_name=>'HTML button (legacy - APEX 5 migration)'
,p_template=>'<input type="button" value="#LABEL#" onclick="#JAVASCRIPT#" id="#BUTTON_ID#" class="#BUTTON_CSS_CLASSES#" #BUTTON_ATTRIBUTES#/>'
,p_hot_template=>'<input type="button" value="#LABEL#" onclick="#JAVASCRIPT#" id="#BUTTON_ID#" class="#BUTTON_CSS_CLASSES#" #BUTTON_ATTRIBUTES#/>'
,p_translate_this_template=>'N'
,p_theme_class_id=>13
,p_theme_id=>42
);
wwv_flow_api.create_button_templates(
 p_id=>788847708499208795+wwv_flow_api.g_id_offset
,p_template_name=>'Icon Button'
,p_template=>'<button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly #BUTTON_CSS_CLASSES#" #BUTTON_ATTRIBUTES# onclick="#JAVASCRIPT#" value="#LABEL#" type="button" id="#BUTTON_ID#" title="#LABEL#"><span class="t-Icon #ICON_CSS_CLASSES#"></span'
||'></button>'
,p_hot_template=>'<button class="t-Button t-Button--noLabel t-Button--icon t-Button--iconOnly #BUTTON_CSS_CLASSES# t-Button--hot" #BUTTON_ATTRIBUTES# onclick="#JAVASCRIPT#" value="#LABEL#" type="button" id="#BUTTON_ID#" title="#LABEL#"><span class="t-Icon #ICON_CSS_CL'
||'ASSES#"></span></button>'
,p_translate_this_template=>'N'
,p_theme_class_id=>6
,p_theme_id=>42
);
wwv_flow_api.create_button_templates(
 p_id=>788847802513208981+wwv_flow_api.g_id_offset
,p_template_name=>'Text + Icon Button'
,p_template=>'<button class="t-Button t-Button--icon #BUTTON_CSS_CLASSES#" #BUTTON_ATTRIBUTES# onclick="#JAVASCRIPT#" value="#LABEL#" type="button" id="#BUTTON_ID#"><span class="t-Icon t-Icon--left #ICON_CSS_CLASSES#"></span>#LABEL#<span class="t-Icon t-Icon--righ'
||'t #ICON_CSS_CLASSES#"></span></button>'
,p_hot_template=>'<button class="t-Button t-Button--icon #BUTTON_CSS_CLASSES# t-Button--hot" #BUTTON_ATTRIBUTES# onclick="#JAVASCRIPT#" value="#LABEL#" type="button" id="#BUTTON_ID#"><span class="t-Icon t-Icon--left #ICON_CSS_CLASSES#"></span>#LABEL#<span class="t-Ico'
||'n t-Icon--right #ICON_CSS_CLASSES#"></span></button>'
,p_translate_this_template=>'N'
,p_theme_class_id=>6
,p_preset_template_options=>'t-Button--iconRight'
,p_theme_id=>42
);
wwv_flow_api.create_button_templates(
 p_id=>788848220255209127+wwv_flow_api.g_id_offset
,p_template_name=>'Text Button'
,p_template=>'<button value="#LABEL#" onclick="#JAVASCRIPT#" class="t-Button #BUTTON_CSS_CLASSES#" type="button" #BUTTON_ATTRIBUTES# id="#BUTTON_ID#">#LABEL#</button>'
,p_hot_template=>'<button value="#LABEL#" onclick="#JAVASCRIPT#" class="t-Button t-Button--hot #BUTTON_CSS_CLASSES#" type="button" #BUTTON_ATTRIBUTES# id="#BUTTON_ID#">#LABEL#</button>'
,p_reference_id=>1285360819622194101
,p_translate_this_template=>'N'
,p_theme_class_id=>6
,p_theme_id=>42
);
end;
/
prompt --application/shared_components/user_interface/templates/region
begin
wwv_flow_api.create_plug_template(
 p_id=>788833210017205368+wwv_flow_api.g_id_offset
,p_layout=>'TABLE'
,p_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Alert #REGION_CSS_CLASSES#" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>',
'  <div class="t-Alert-wrap">',
'    <div class="t-Alert-icon">',
'      <span class="t-Icon #ICON_CSS_CLASSES#"></span>',
'    </div>',
'    <div class="t-Alert-content">',
'      <div class="t-Alert-header">',
'        <h2 class="t-Alert-title">#TITLE#</h2>',
'      </div>',
'      <div class="t-Alert-body">',
'        #BODY#',
'      </div>',
'    </div>',
'    <div class="t-Alert-buttons">',
'      #PREVIOUS##CLOSE##CREATE##NEXT#',
'    </div>',
'  </div>',
'</div>'))
,p_page_plug_template_name=>'Alert Region'
,p_plug_table_bgcolor=>'#ffffff'
,p_theme_id=>42
,p_theme_class_id=>9
,p_default_template_options=>'t-Alert--colorBG:t-Alert--defaultIcons'
,p_preset_template_options=>'t-Alert--warning:t-Alert--horizontal'
,p_plug_heading_bgcolor=>'#ffffff'
,p_plug_font_size=>'-1'
,p_default_label_alignment=>'RIGHT'
,p_default_field_alignment=>'LEFT'
,p_translate_this_template=>'N'
,p_template_comment=>'Red Theme'
);
wwv_flow_api.create_plug_tmpl_display_point(
 p_id=>788833308602205369+wwv_flow_api.g_id_offset
,p_plug_template_id=>788833210017205368+wwv_flow_api.g_id_offset
,p_name=>'Region Body'
,p_placeholder=>'BODY'
,p_has_grid_support=>true
,p_glv_new_row=>true
,p_max_fixed_grid_columns=>12
);
wwv_flow_api.create_plug_template(
 p_id=>788834570073205524+wwv_flow_api.g_id_offset
,p_layout=>'TABLE'
,p_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES# class="#REGION_CSS_CLASSES#"> ',
'#PREVIOUS##BODY##SUB_REGIONS##NEXT#',
'</div>'))
,p_page_plug_template_name=>'Blank Region with Attributes'
,p_theme_id=>42
,p_theme_class_id=>22
,p_default_label_alignment=>'RIGHT'
,p_default_field_alignment=>'LEFT'
,p_translate_this_template=>'N'
);
wwv_flow_api.create_plug_template(
 p_id=>788834655647205677+wwv_flow_api.g_id_offset
,p_layout=>'TABLE'
,p_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-ButtonRegion #REGION_CSS_CLASSES#" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>',
'  <div class="t-ButtonRegion-wrap">',
'    <div class="t-ButtonRegion-col t-ButtonRegion-col--left"><div class="t-ButtonRegion-buttons">#PREVIOUS#</div></div>',
'    <div class="t-ButtonRegion-col t-ButtonRegion-col--content">',
'      <h2 class="t-ButtonRegion-title">#TITLE#</h2>',
'      #BODY#',
'      <div class="t-ButtonRegion-buttons">#CLOSE#</div>',
'    </div>',
'    <div class="t-ButtonRegion-col t-ButtonRegion-col--right"><div class="t-ButtonRegion-buttons">#NEXT#</div></div>',
'  </div>',
'</div>'))
,p_page_plug_template_name=>'Button Region'
,p_plug_table_bgcolor=>'#ffffff'
,p_theme_id=>42
,p_theme_class_id=>9
,p_plug_heading_bgcolor=>'#ffffff'
,p_plug_font_size=>'-1'
,p_default_label_alignment=>'RIGHT'
,p_default_field_alignment=>'LEFT'
,p_translate_this_template=>'N'
,p_template_comment=>'Red Theme'
);
wwv_flow_api.create_plug_tmpl_display_point(
 p_id=>788834763670205677+wwv_flow_api.g_id_offset
,p_plug_template_id=>788834655647205677+wwv_flow_api.g_id_offset
,p_name=>'Region Body'
,p_placeholder=>'BODY'
,p_has_grid_support=>true
,p_glv_new_row=>true
,p_max_fixed_grid_columns=>12
);
wwv_flow_api.create_plug_tmpl_display_point(
 p_id=>788834877332205677+wwv_flow_api.g_id_offset
,p_plug_template_id=>788834655647205677+wwv_flow_api.g_id_offset
,p_name=>'Sub Regions'
,p_placeholder=>'SUB_REGIONS'
,p_has_grid_support=>true
,p_glv_new_row=>true
,p_max_fixed_grid_columns=>12
);
wwv_flow_api.create_plug_template(
 p_id=>788835768975205834+wwv_flow_api.g_id_offset
,p_layout=>'TABLE'
,p_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES# class="t-IRR-region #REGION_CSS_CLASSES#">',
'  <h2 class="u-VisuallyHidden">#TITLE#</h2>',
'#PREVIOUS##BODY##SUB_REGIONS##NEXT#',
'</div>'))
,p_page_plug_template_name=>'Interactive Report Region'
,p_theme_id=>42
,p_theme_class_id=>22
,p_default_label_alignment=>'RIGHT'
,p_default_field_alignment=>'LEFT'
,p_translate_this_template=>'N'
);
wwv_flow_api.create_plug_template(
 p_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_layout=>'TABLE'
,p_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Region #REGION_CSS_CLASSES#" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>',
' <div class="t-Region-header">',
'  <div class="t-Region-headerItems t-Region-headerItems--title">',
'    <h2 class="t-Region-title">#TITLE#</h2>',
'  </div>',
'  <div class="t-Region-headerItems t-Region-headerItems--buttons">#EDIT#</div>',
' </div>',
' <div class="t-Region-bodyWrap">',
'   <div class="t-Region-buttons t-Region-buttons--top">',
'    <div class="t-Region-buttons-left">#CLOSE#</div>',
'    <div class="t-Region-buttons-right">#CREATE#</div>',
'   </div>',
'   <div class="t-Region-body">',
'     #COPY#',
'     #BODY#',
'     #SUB_REGIONS#',
'     #CHANGE#',
'   </div>',
'   <div class="t-Region-buttons t-Region-buttons--bottom">',
'    <div class="t-Region-buttons-left">#PREVIOUS#</div>',
'    <div class="t-Region-buttons-right">#NEXT#</div>',
'   </div>',
' </div>',
'</div>'))
,p_page_plug_template_name=>'Standard Region'
,p_plug_table_bgcolor=>'#ffffff'
,p_theme_id=>42
,p_theme_class_id=>9
,p_preset_template_options=>'t-Region--defaultHeight:t-Region-scrollAuto'
,p_plug_heading_bgcolor=>'#ffffff'
,p_plug_font_size=>'-1'
,p_default_label_alignment=>'RIGHT'
,p_default_field_alignment=>'LEFT'
,p_translate_this_template=>'N'
,p_template_comment=>'Red Theme'
);
wwv_flow_api.create_plug_tmpl_display_point(
 p_id=>788836016156205990+wwv_flow_api.g_id_offset
,p_plug_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_name=>'Region Body'
,p_placeholder=>'BODY'
,p_has_grid_support=>true
,p_glv_new_row=>true
,p_max_fixed_grid_columns=>12
);
wwv_flow_api.create_plug_tmpl_display_point(
 p_id=>788836138038205990+wwv_flow_api.g_id_offset
,p_plug_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_name=>'Sub Regions'
,p_placeholder=>'SUB_REGIONS'
,p_has_grid_support=>true
,p_glv_new_row=>true
,p_max_fixed_grid_columns=>12
);
wwv_flow_api.create_plug_template(
 p_id=>788838476638206140+wwv_flow_api.g_id_offset
,p_layout=>'TABLE'
,p_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Wizard #REGION_CSS_CLASSES#" id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES#>',
'  <div class="t-Wizard-header">',
'    <h1 class="t-Wizard-title">#TITLE#</h1>',
'    <div class="u-Table t-Wizard-controls">',
'      <div class="u-Table-fit t-Wizard-buttons">#PREVIOUS#</div>',
'      <div class="u-Table-fill t-Wizard-steps">',
'        #BODY#',
'      </div>',
'      <div class="u-Table-fit t-Wizard-buttons">#NEXT#</div>',
'    </div>',
'  </div>',
'  <div class="t-Wizard-body">',
'    #SUB_REGIONS#',
'  </div>',
'</div>'))
,p_page_plug_template_name=>'Wizard Region'
,p_theme_id=>42
,p_theme_class_id=>12
,p_default_template_options=>'t-Wizard--headerBG'
,p_preset_template_options=>'t-Wizard--hideStepsSmall'
,p_default_label_alignment=>'RIGHT'
,p_default_field_alignment=>'LEFT'
,p_translate_this_template=>'N'
);
end;
/
prompt --application/shared_components/user_interface/templates/list
begin
wwv_flow_api.create_list_template(
 p_id=>788842491139207185+wwv_flow_api.g_id_offset
,p_list_template_current=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<li class="t-BadgeList-item #A02#">',
'  <span class="t-BadgeList-label">#TEXT#</span>',
'  <span class="t-BadgeList-value"><a href="#LINK#" title="#TEXT_ESC_SC#" #A03#>#A01#</a></span>',
'</li>',
''))
,p_list_template_noncurrent=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<li class="t-BadgeList-item #A02#">',
'  <span class="t-BadgeList-label">#TEXT#</span>',
'  <span class="t-BadgeList-value"><a href="#LINK#" title="#TEXT_ESC_SC#" #A03#>#A01#</a></span>',
'</li>',
''))
,p_list_template_name=>'Badge List'
,p_theme_id=>42
,p_theme_class_id=>3
,p_default_template_options=>'t-BadgeList--responsive'
,p_preset_template_options=>'t-BadgeList--large:t-BadgeList--fixed'
,p_list_template_before_rows=>'<ul class="t-BadgeList #COMPONENT_CSS_CLASSES#">'
,p_list_template_after_rows=>'</ul>'
,p_list_template_comment=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'A01: Large Number',
'A02: List Item Classes',
'A03: Link Attributes'))
);
wwv_flow_api.create_list_template(
 p_id=>788844187914207332+wwv_flow_api.g_id_offset
,p_list_template_current=>'<li class="t-LinksList-item is-current #A03#"><a href="#LINK#" class="t-LinksList-link" #A02#><span class="t-LinksList-icon"><span class="t-Icon #IMAGE#"></span></span><span class="t-LinksList-label">#TEXT#</span><span class="t-LinksList-badge">#A01#'
||'</span></a></li>'
,p_list_template_noncurrent=>'<li class="t-LinksList-item #A03#"><a href="#LINK#" class="t-LinksList-link" #A02#><span class="t-LinksList-icon"><span class="t-Icon #IMAGE#"></span></span><span class="t-LinksList-label">#TEXT#</span><span class="t-LinksList-badge">#A01#</span></a>'
||'</li>'
,p_list_template_name=>'Links List'
,p_theme_id=>42
,p_theme_class_id=>3
,p_list_template_before_rows=>'<ul class="t-LinksList #COMPONENT_CSS_CLASSES#" id="#LIST_ID#">'
,p_list_template_after_rows=>'</ul>'
,p_before_sub_list=>'<ul class="t-LinksList-list">'
,p_after_sub_list=>'</ul>'
,p_sub_list_item_current=>'<li class="t-LinksList-item is-current #A03#"><a href="#LINK#" class="t-LinksList-link" #A02#><span class="t-LinksList-icon"><span class="t-Icon #IMAGE#"></span></span><span class="t-LinksList-label">#TEXT#</span><span class="t-LinksList-badge">#A01#'
||'</span></a></li>'
,p_sub_list_item_noncurrent=>'<li class="t-LinksList-item#A03#"><a href="#LINK#" class="t-LinksList-link" #A02#><span class="t-LinksList-icon"><span class="t-Icon #IMAGE#"></span></span><span class="t-LinksList-label">#TEXT#</span><span class="t-LinksList-badge">#A01#</span></a><'
||'/li>'
,p_item_templ_curr_w_child=>'<li class="t-LinksList-item is-current is-expanded #A03#"><a href="#LINK#" class="t-LinksList-link" #A02#><span class="t-LinksList-icon"><span class="t-Icon #IMAGE#"></span></span><span class="t-LinksList-label">#TEXT#</span><span class="t-LinksList-'
||'badge">#A01#</span></a>#SUB_LISTS#</li>'
,p_item_templ_noncurr_w_child=>'<li class="t-LinksList-item #A03#"><a href="#LINK#" class="t-LinksList-link" #A02#><span class="t-LinksList-icon"><span class="t-Icon #IMAGE#"></span></span><span class="t-LinksList-label">#TEXT#</span><span class="t-LinksList-badge">#A01#</span></a>'
||'</li>'
);
wwv_flow_api.create_list_template(
 p_id=>788845088168207477+wwv_flow_api.g_id_offset
,p_list_template_current=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<li class="t-MediaList-item is-active">',
'    <a href="#LINK#" class="t-MediaList-link" #A03#>',
'        <div class="t-MediaList-iconWrap">',
'            <span class="t-MediaList-icon"><span class="t-Icon #IMAGE#" #IMAGE_ATTR#></span></span>',
'        </div>',
'        <div class="t-MediaList-body">',
'            <h3 class="t-MediaList-title">#TEXT#</h3>',
'            <p class="t-MediaList-desc">#A01#</p>',
'        </div>',
'        <div class="t-MediaList-badgeWrap">',
'            <span class="t-MediaList-badge">#A02#</span>',
'        </div>',
'    </a>',
'</li>'))
,p_list_template_noncurrent=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<li class="t-MediaList-item">',
'    <a href="#LINK#" class="t-MediaList-link" #A03#>',
'        <div class="t-MediaList-iconWrap">',
'            <span class="t-MediaList-icon"><span class="t-Icon #IMAGE#" #IMAGE_ATTR#></span></span>',
'        </div>',
'        <div class="t-MediaList-body">',
'            <h3 class="t-MediaList-title">#TEXT#</h3>',
'            <p class="t-MediaList-desc">#A01#</p>',
'        </div>',
'        <div class="t-MediaList-badgeWrap">',
'            <span class="t-MediaList-badge">#A02#</span>',
'        </div>',
'    </a>',
'</li>'))
,p_list_template_name=>'Media List'
,p_theme_id=>42
,p_theme_class_id=>9
,p_default_template_options=>'t-MediaList--noBadge'
,p_list_template_before_rows=>'<ul class="t-MediaList #COMPONENT_CSS_CLASSES#">'
,p_list_template_after_rows=>'</ul>'
);
wwv_flow_api.create_list_template(
 p_id=>788846557001207623+wwv_flow_api.g_id_offset
,p_list_template_current=>'<li data-current="true"><a href="#LINK#" class="active">#TEXT_ESC_SC#</a></li>'
,p_list_template_noncurrent=>'<li><a href="#LINK#">#TEXT_ESC_SC#</a></li>'
,p_list_template_name=>'Menu Bar'
,p_javascript_code_onload=>'apex.jQuery( ".t-MenuBar" ).menu({ menubar: true, behaveLikeTabs: true });'
,p_theme_id=>42
,p_theme_class_id=>7
,p_list_template_before_rows=>'<div class="t-MenuBar #COMPONENT_CSS_CLASSES#"><ul>'
,p_list_template_after_rows=>'</ul></div>'
,p_after_sub_list=>'</ul></li>'
,p_sub_list_item_current=>'<li data-current="true"><a href="#LINK#">#TEXT_ESC_SC#</a></li>'
,p_sub_list_item_noncurrent=>'<li><a href="#LINK#">#TEXT_ESC_SC#</a></li>'
,p_item_templ_curr_w_child=>'<li data-current="true" class="active"><a href="#LINK#">#TEXT_ESC_SC#</a><ul>'
,p_item_templ_noncurr_w_child=>'<li><a href="#LINK#">#TEXT_ESC_SC#</a><ul>'
,p_sub_templ_curr_w_child=>'<li data-current="true"><a href="#LINK#">#TEXT_ESC_SC#</a><ul>'
,p_sub_templ_noncurr_w_child=>'<li><a href="#LINK#">#TEXT_ESC_SC#</a><ul>'
);
wwv_flow_api.create_list_template(
 p_id=>788846699424207768+wwv_flow_api.g_id_offset
,p_list_template_current=>'<li data-current="true"><a href="#LINK#" class="active">#TEXT_ESC_SC#</a></li>'
,p_list_template_noncurrent=>'<li><a href="#LINK#">#TEXT_ESC_SC#</a></li>'
,p_list_template_name=>'Navigation List'
,p_javascript_code_onload=>'apex.jQuery( ".t-Header-nav-list" ).menu({ menubar: true, behaveLikeTabs: true });'
,p_theme_id=>42
,p_theme_class_id=>7
,p_list_template_before_rows=>'<div class="t-Header-nav-list #COMPONENT_CSS_CLASSES#"><ul style="display:none">'
,p_list_template_after_rows=>'</ul></div>'
,p_after_sub_list=>'</ul></li>'
,p_sub_list_item_current=>'<li data-current="true"><a href="#LINK#">#TEXT_ESC_SC#</a></li>'
,p_sub_list_item_noncurrent=>'<li><a href="#LINK#">#TEXT_ESC_SC#</a></li>'
,p_item_templ_curr_w_child=>'<li data-current="true" class="active"><a href="#LINK#">#TEXT_ESC_SC#</a><ul>'
,p_item_templ_noncurr_w_child=>'<li><a href="#LINK#">#TEXT_ESC_SC#</a><ul>'
,p_sub_templ_curr_w_child=>'<li data-current="true"><a href="#LINK#">#TEXT_ESC_SC#</a><ul>'
,p_sub_templ_noncurr_w_child=>'<li><a href="#LINK#">#TEXT_ESC_SC#</a><ul>'
);
wwv_flow_api.create_list_template(
 p_id=>788846781624207914+wwv_flow_api.g_id_offset
,p_list_template_current=>'<li class="active"><a href="#LINK#">#TEXT#</a></li>'
,p_list_template_noncurrent=>'<li><a href="#LINK#">#TEXT#</a></li>'
,p_list_template_name=>'Vertical Unordered List with Bullets'
,p_theme_id=>42
,p_theme_class_id=>1
,p_list_template_before_rows=>'<ul class="uVerticalList">'
,p_list_template_after_rows=>'</ul>'
);
wwv_flow_api.create_list_template(
 p_id=>788846860150208059+wwv_flow_api.g_id_offset
,p_list_template_current=>'<li class="t-WizardSteps-step is-active"><div class="t-WizardSteps-wrap"><span class="t-WizardSteps-marker"></span><span class="t-WizardSteps-label">#TEXT#</span></div></li>'
,p_list_template_noncurrent=>'<li class="t-WizardSteps-step"><div class="t-WizardSteps-wrap"><span class="t-WizardSteps-marker"><span class="t-Icon fa-check"></span></span><span class="t-WizardSteps-label">#TEXT#</span></div></li>'
,p_list_template_name=>'Wizard Progress'
,p_theme_id=>42
,p_theme_class_id=>3
,p_preset_template_options=>'t-WizardSteps--displayCurrentLabelOnly'
,p_list_template_before_rows=>'<ul class="t-WizardSteps #COMPONENT_CSS_CLASSES#">'
,p_list_template_after_rows=>'</ul>'
);
end;
/
prompt --application/shared_components/user_interface/templates/report
begin
wwv_flow_api.create_row_template(
 p_id=>788839046150206288+wwv_flow_api.g_id_offset
,p_row_template_name=>'Badge List - Column'
,p_row_template1=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<li class="t-BadgeList-item">',
'  <span class="t-BadgeList-label">#COLUMN_HEADER#</span>',
'  <span class="t-BadgeList-value">#COLUMN_VALUE#</span>',
'</li>'))
,p_row_template_before_rows=>'<ul class="t-BadgeList #COMPONENT_CSS_CLASSES#">'
,p_row_template_after_rows=>'</ul>'
,p_row_template_type=>'GENERIC_COLUMNS'
,p_row_template_display_cond1=>'0'
,p_row_template_display_cond2=>'0'
,p_row_template_display_cond3=>'0'
,p_row_template_display_cond4=>'0'
,p_theme_id=>42
,p_theme_class_id=>6
,p_default_template_options=>'t-BadgeList--responsive'
,p_preset_template_options=>'t-BadgeList--large:t-BadgeList--fixed'
,p_translate_this_template=>'N'
);
wwv_flow_api.create_row_template(
 p_id=>788840779280206437+wwv_flow_api.g_id_offset
,p_row_template_name=>'Badge List - Row'
,p_row_template1=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<li class="t-BadgeList-item">',
'  <span class="t-BadgeList-label">#1#</span>',
'  <span class="t-BadgeList-value">#2#</span>',
'</li>'))
,p_row_template_before_rows=>'<ul class="t-BadgeList #COMPONENT_CSS_CLASSES#">'
,p_row_template_after_rows=>'</ul>'
,p_row_template_type=>'NAMED_COLUMNS'
,p_row_template_display_cond1=>'0'
,p_row_template_display_cond2=>'0'
,p_row_template_display_cond3=>'0'
,p_row_template_display_cond4=>'0'
,p_theme_id=>42
,p_theme_class_id=>6
,p_translate_this_template=>'N'
);
wwv_flow_api.create_row_template(
 p_id=>788840897303206586+wwv_flow_api.g_id_offset
,p_row_template_name=>'Search Results Report'
,p_row_template1=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'  <li class="t-SearchResults-item">',
'    <h3 class="t-SearchResults-title"><a href="#SEARCH_LINK#">#SEARCH_TITLE#</a></h3>',
'    <div class="t-SearchResults-info">',
'      <p class="t-SearchResults-desc"><span class="t-SearchResults-date">#SEARCH_DATE#</span>#SEARCH_DESC#</p>',
'      <span class="t-SearchResults-misc">#SEARCH_MISC#</span>',
'    </div>',
'  </li>'))
,p_row_template_condition1=>'''#SEARCH_DATE#'' is not null'
,p_row_template2=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'  <li class="t-SearchResults-item">',
'    <h3 class="t-SearchResults-title"><a href="#SEARCH_LINK#">#SEARCH_TITLE#</a></h3>',
'    <div class="t-SearchResults-info">',
'      <p class="t-SearchResults-desc">#SEARCH_DESC#</p>',
'      <span class="t-SearchResults-misc">#SEARCH_MISC#</span>',
'    </div>',
'  </li>'))
,p_row_template_before_rows=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-SearchResults #COMPONENT_CSS_CLASSES#">',
'<ul class="t-SearchResults-list">'))
,p_row_template_after_rows=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'</ul>',
'<table class="t-SearchResults-pagination">',
'#PAGINATION#',
'</table>',
'</div>'))
,p_row_template_type=>'NAMED_COLUMNS'
,p_row_template_display_cond1=>'NOT_CONDITIONAL'
,p_row_template_display_cond2=>'0'
,p_row_template_display_cond3=>'0'
,p_row_template_display_cond4=>'NOT_CONDITIONAL'
,p_next_page_template=>'<a href="#LINK#" class="sPaginationNext">#PAGINATION_NEXT#</a>'
,p_previous_page_template=>'<a href="#LINK#" class="sPaginationPrev">#PAGINATION_PREVIOUS#</a>'
,p_next_set_template=>'<a href="#LINK#" class="sPaginationNext">#PAGINATION_NEXT_SET#</a>'
,p_previous_set_template=>'<a href="#LINK#" class="sPaginationPrev">#PAGINATION_PREVIOUS_SET#</a>'
,p_theme_id=>42
,p_theme_class_id=>1
,p_translate_this_template=>'N'
,p_row_template_comment=>' (SELECT link_text, link_target, detail1, detail2, last_modified)'
);
wwv_flow_api.create_row_template(
 p_id=>788840920131206733+wwv_flow_api.g_id_offset
,p_row_template_name=>'Table Report'
,p_row_template1=>'<td class="t-Report-cell" #ALIGNMENT# headers="#COLUMN_HEADER_NAME#">#COLUMN_VALUE#</td>'
,p_row_template_before_rows=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Report #COMPONENT_CSS_CLASSES#" id="report_#REGION_STATIC_ID#" #REPORT_ATTRIBUTES#>',
'  <div class="t-Report-wrap">',
'    <table class="t-Report-pagination">#TOP_PAGINATION#</table>',
'    <div class="t-Report-tableWrap">',
'    <table class="t-Report-report" summary="#REGION_TITLE#">'))
,p_row_template_after_rows=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'      </tbody>',
'    </table>',
'    </div>',
'    <div class="t-Report-links">#EXTERNAL_LINK##CSV_LINK#</div>',
'    <table class="t-Report-pagination t-Report-pagination t-Report-pagination--bottom">#PAGINATION#</table>',
'  </div>',
'</div>'))
,p_row_template_type=>'GENERIC_COLUMNS'
,p_before_column_heading=>'<thead>'
,p_column_heading_template=>'<th class="t-Report-colHead" #ALIGNMENT# id="#COLUMN_HEADER_NAME#" #COLUMN_WIDTH#>#COLUMN_HEADER#</th>'
,p_after_column_heading=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'</thead>',
'<tbody>'))
,p_row_template_display_cond1=>'0'
,p_row_template_display_cond2=>'0'
,p_row_template_display_cond3=>'0'
,p_row_template_display_cond4=>'0'
,p_pagination_template=>'<span class="t-Report-paginationText">#TEXT#</span>'
,p_next_page_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Report-paginationLink">',
'  #PAGINATION_NEXT#<span class="a-Icon icon-right-arrow"></span>',
'</a>'))
,p_previous_page_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Report-paginationLink">',
'  <span class="a-Icon icon-left-arrow"></span>#PAGINATION_PREVIOUS#',
'</a>'))
,p_next_set_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Report-paginationLink">',
'  #PAGINATION_NEXT_SET#<span class="a-Icon icon-right-arrow"></span>',
'</a>'))
,p_previous_set_template=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<a href="#LINK#" class="t-Report-paginationLink">',
'  <span class="a-Icon icon-left-arrow"></span>#PAGINATION_PREVIOUS_SET#',
'</a>'))
,p_theme_id=>42
,p_theme_class_id=>4
,p_preset_template_options=>'t-Report--altRowsDefault:t-Report--rowHighlight'
,p_translate_this_template=>'N'
);
begin
wwv_flow_api.create_row_template_patch(
 p_id=>788840920131206733+wwv_flow_api.g_id_offset
,p_row_template_before_first=>'<tr>'
,p_row_template_after_last=>'</tr>'
);
exception when others then null;
end;
wwv_flow_api.create_row_template(
 p_id=>788842274415206884+wwv_flow_api.g_id_offset
,p_row_template_name=>'Two Column Portlet'
,p_row_template1=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<li class="t-AVPList-item #A01#" #A02#>',
'  <span class="t-AVPList-label">',
'    #1#',
'  </span>',
'  <span class="t-AVPList-value">',
'    #2#',
'  </span>',
'</li>'))
,p_row_template_before_rows=>'<ul class="t-AVPList #COMPONENT_CSS_CLASSES#" #REPORT_ATTRIBUTES# id="report_#REGION_STATIC_ID#">'
,p_row_template_after_rows=>'</ul>'
,p_row_template_type=>'NAMED_COLUMNS'
,p_row_template_display_cond1=>'0'
,p_row_template_display_cond2=>'0'
,p_row_template_display_cond3=>'0'
,p_row_template_display_cond4=>'0'
,p_theme_id=>42
,p_theme_class_id=>7
,p_translate_this_template=>'N'
);
wwv_flow_api.create_row_template(
 p_id=>788842369563207031+wwv_flow_api.g_id_offset
,p_row_template_name=>'Value Attribute Pairs'
,p_row_template1=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<li class="t-AVPList-item>',
'  <span class="t-AVPList-label">',
'    #COLUMN_HEADER#',
'  </span>',
'  <span class="t-AVPList-value">',
'    #COLUMN_VALUE#',
'  </span>',
'</li>'))
,p_row_template_before_rows=>'<ul class="t-AVPList #COMPONENT_CSS_CLASSES#" #REPORT_ATTRIBUTES#>'
,p_row_template_after_rows=>'</ul>'
,p_row_template_type=>'GENERIC_COLUMNS'
,p_row_template_display_cond1=>'0'
,p_row_template_display_cond2=>'0'
,p_row_template_display_cond3=>'0'
,p_row_template_display_cond4=>'0'
,p_theme_id=>42
,p_theme_class_id=>6
,p_translate_this_template=>'N'
);
end;
/
prompt --application/shared_components/user_interface/templates/label
begin
wwv_flow_api.create_field_template(
 p_id=>788847371789208206+wwv_flow_api.g_id_offset
,p_template_name=>'Hidden Label'
,p_template_body1=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Form-labelContainer t-Form-labelContainer--hiddenLabel">',
'<label for="#CURRENT_ITEM_NAME#" class="t-Form-label u-VisuallyHidden">'))
,p_template_body2=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'</label>',
'</div>'))
,p_before_item=>'<div class="t-Form-fieldContainer t-Form-fieldContainer--hiddenLabel #ITEM_CSS_CLASSES#" id="#CURRENT_ITEM_CONTAINER_ID#">'
,p_after_item=>'</div>'
,p_before_element=>'<div class="t-Form-inputContainer">'
,p_after_element=>'#HELP_TEMPLATE##ERROR_TEMPLATE#</div>'
,p_help_link=>'<button class="t-Button t-Button--noUI t-Button--helpButton" title="CURRENT_ITEM_HELP_LABEL" tabindex="-1" onclick="popupFieldHelp(''#CURRENT_ITEM_ID#'',''&SESSION.'');" type="button"><span class="a-Icon icon-help"></span><span class="u-VisuallyHidden">#'
||'CURRENT_ITEM_HELP_LABEL#</span></button>'
,p_error_template=>'<span class="t-Form-error">#ERROR_MESSAGE#</span>'
,p_theme_id=>42
,p_theme_class_id=>3
,p_translate_this_template=>'N'
);
wwv_flow_api.create_field_template(
 p_id=>788847462236208358+wwv_flow_api.g_id_offset
,p_template_name=>'Optional Label'
,p_template_body1=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Form-labelContainer">',
'<label for="#CURRENT_ITEM_NAME#" class="t-Form-label">'))
,p_template_body2=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'</label>',
'</div>'))
,p_before_item=>'<div class="t-Form-fieldContainer" id="#CURRENT_ITEM_CONTAINER_ID#">'
,p_after_item=>'</div>'
,p_before_element=>'<div class="t-Form-inputContainer">'
,p_after_element=>'#HELP_TEMPLATE##ERROR_TEMPLATE#</div>'
,p_help_link=>'<button class="t-Button t-Button--noUI t-Button--helpButton" title="CURRENT_ITEM_HELP_LABEL" tabindex="-1" onclick="popupFieldHelp(''#CURRENT_ITEM_ID#'',''&SESSION.'');" type="button"><span class="a-Icon icon-help"></span><span class="u-VisuallyHidden">#'
||'CURRENT_ITEM_HELP_LABEL#</span></button>'
,p_error_template=>'<span class="t-Form-error">#ERROR_MESSAGE#</span>'
,p_theme_id=>42
,p_theme_class_id=>3
,p_translate_this_template=>'N'
);
wwv_flow_api.create_field_template(
 p_id=>788847507227208503+wwv_flow_api.g_id_offset
,p_template_name=>'Required Label'
,p_template_body1=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="t-Form-labelContainer">',
'  <span class="t-Form-required"><span class="a-Icon icon-asterisk"></span></span><label for="#CURRENT_ITEM_NAME#" class="t-Form-label">'))
,p_template_body2=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
' <span class="u-VisuallyHidden">(#VALUE_REQUIRED#)</span></label>',
'</div>'))
,p_before_item=>'<div class="t-Form-fieldContainer" id="#CURRENT_ITEM_CONTAINER_ID#">'
,p_after_item=>'</div>'
,p_before_element=>'<div class="t-Form-inputContainer">'
,p_after_element=>'#HELP_TEMPLATE##ERROR_TEMPLATE#</div>'
,p_help_link=>'<button class="t-Button t-Button--noUI t-Button--helpButton" title="CURRENT_ITEM_HELP_LABEL" tabindex="-1" onclick="popupFieldHelp(''#CURRENT_ITEM_ID#'',''&SESSION.'');" type="button"><span class="a-Icon icon-help"></span><span class="u-VisuallyHidden">#'
||'CURRENT_ITEM_HELP_LABEL#</span></button>'
,p_error_template=>'<span class="t-Form-error">#ERROR_MESSAGE#</span>'
,p_theme_id=>42
,p_theme_class_id=>3
,p_translate_this_template=>'N'
);
end;
/
prompt --application/shared_components/user_interface/templates/breadcrumb
begin
wwv_flow_api.create_menu_template(
 p_id=>788848363532209272+wwv_flow_api.g_id_offset
,p_name=>'Breadcrumb'
,p_before_first=>'<ul class="t-Breadcrumb #COMPONENT_CSS_CLASSES#">'
,p_current_page_option=>'<li class="t-Breadcrumb-item is-active"><span class="t-Breadcrumb-label">#NAME#</span></li>'
,p_non_current_page_option=>'<li class="t-Breadcrumb-item"><a href="#LINK#" class="t-Breadcrumb-label">#NAME#</a></li>'
,p_after_last=>'</ul>'
,p_max_levels=>6
,p_start_with_node=>'PARENT_TO_LEAF'
,p_theme_id=>42
,p_theme_class_id=>1
,p_preset_template_options=>'t-Breadcrumb--dividerArrow'
,p_translate_this_template=>'N'
);
end;
/
prompt --application/shared_components/user_interface/templates/popuplov
begin
wwv_flow_api.create_popup_lov_template(
 p_id=>788848865155209419+wwv_flow_api.g_id_offset
,p_page_name=>'winlov'
,p_page_title=>'Search Dialog'
,p_page_html_head=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=0" />',
'<link rel="shortcut icon" href="#IMAGE_PREFIX#favicon.ico" type="image/x-icon">',
'<link rel="stylesheet" href="#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#" type="text/css"/>',
'<link rel="stylesheet" href="#IMAGE_PREFIX#libraries/font-awesome/4.0.3/css/font-awesome#MIN#.css?v=#APEX_VERSION#" type="text/css"/>',
'#THEME_CSS#'))
,p_page_body_attr=>'class="t-Page t-Page--popupLOV"'
,p_before_field_text=>'<div class="t-PopupLOV-actions t-Form--large">'
,p_filter_width=>'15'
,p_filter_max_width=>'100'
,p_filter_text_attr=>'class="t-Form-field t-Form-searchField"'
,p_find_button_text=>'Search'
,p_find_button_attr=>'class="t-Button t-Button--hot t-Button--padLeft"'
,p_close_button_text=>'Close'
,p_close_button_attr=>'class="t-Button u-pullRight"'
,p_next_button_text=>'Next &gt;'
,p_next_button_attr=>'class="t-Button t-PopupLOV-button"'
,p_prev_button_text=>'&lt; Previous'
,p_prev_button_attr=>'class="t-Button t-PopupLOV-button"'
,p_after_field_text=>'</div>'
,p_scrollbars=>'1'
,p_resizable=>'1'
,p_width=>'320'
,p_height=>'480'
,p_result_row_x_of_y=>'<div class="t-PopupLOV-pagination">Row(s) #FIRST_ROW# - #LAST_ROW#</div>'
,p_result_rows_per_pg=>2
,p_before_result_set=>'<div class="t-PopupLOV-links">'
,p_theme_id=>42
,p_theme_class_id=>1
,p_translate_this_template=>'N'
,p_after_result_set=>'</div>'
);
end;
/
prompt --application/shared_components/user_interface/templates/calendar
begin
wwv_flow_api.create_calendar_template(
 p_id=>788848753039209419+wwv_flow_api.g_id_offset
,p_cal_template_name=>'Calendar'
,p_day_of_week_format=>'<th id="#DY#" scope="col" class="uCalDayCol">#IDAY#</th>'
,p_month_title_format=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="uCal">',
'<h1 class="uMonth">#IMONTH# <span>#YYYY#</span></h1>'))
,p_month_open_format=>'<table class="uCal" cellpadding="0" cellspacing="0" border="0" summary="#IMONTH# #YYYY#">'
,p_month_close_format=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'</table>',
'<div class="uCalFooter"></div>',
'</div>',
''))
,p_day_title_format=>'<span class="uDayTitle">#DD#</span>'
,p_day_open_format=>'<td class="uDay" headers="#DY#">#TITLE_FORMAT#<div class="uDayData">#DATA#</div>'
,p_day_close_format=>'</td>'
,p_today_open_format=>'<td class="uDay today" headers="#DY#">#TITLE_FORMAT#<div class="uDayData">#DATA#</div>'
,p_weekend_title_format=>'<span class="uDayTitle weekendday">#DD#</span>'
,p_weekend_open_format=>'<td class="uDay" headers="#DY#">#TITLE_FORMAT#<div class="uDayData">#DATA#</div>'
,p_weekend_close_format=>'</td>'
,p_nonday_title_format=>'<span class="uDayTitle">#DD#</span>'
,p_nonday_open_format=>'<td class="uDay nonday" headers="#DY#">'
,p_nonday_close_format=>'</td>'
,p_week_open_format=>'<tr>'
,p_week_close_format=>'</tr> '
,p_daily_title_format=>'<table cellspacing="0" cellpadding="0" border="0" summary="" class="t1DayCalendarHolder"> <tr> <td class="t1MonthTitle">#IMONTH# #DD#, #YYYY#</td> </tr> <tr> <td>'
,p_daily_open_format=>'<tr>'
,p_daily_close_format=>'</tr>'
,p_weekly_title_format=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="uCal uCalWeekly">',
'<h1 class="uMonth">#WTITLE#</h1>'))
,p_weekly_day_of_week_format=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<th scope="col" class="aCalDayCol" id="#DY#">',
'  <span class="visible-desktop">#DD# #IDAY#</span>',
'  <span class="hidden-desktop">#DD# <em>#IDY#</em></span>',
'</th>'))
,p_weekly_month_open_format=>'<table border="0" cellpadding="0" cellspacing="0" summary="#CALENDAR_TITLE# #START_DL# - #END_DL#" class="uCal">'
,p_weekly_month_close_format=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'</table>',
'<div class="uCalFooter"></div>',
'</div>'))
,p_weekly_day_open_format=>'<td class="uDay" headers="#DY#"><div class="uDayData">'
,p_weekly_day_close_format=>'</div></td>'
,p_weekly_today_open_format=>'<td class="uDay today" headers="#DY#"><div class="uDayData">'
,p_weekly_weekend_open_format=>'<td class="uDay weekend" headers="#DY#"><div class="uDayData">'
,p_weekly_weekend_close_format=>'</div></td>'
,p_weekly_time_open_format=>'<th scope="row" class="uCalHour">'
,p_weekly_time_close_format=>'</th>'
,p_weekly_time_title_format=>'#TIME#'
,p_weekly_hour_open_format=>'<tr>'
,p_weekly_hour_close_format=>'</tr>'
,p_daily_day_of_week_format=>'<th scope="col" id="#DY#" class="aCalDayCol">#IDAY#</th>'
,p_daily_month_title_format=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<div class="uCal uCalWeekly uCalDaily">',
'<h1 class="uMonth">#IMONTH# #DD#, #YYYY#</h1>'))
,p_daily_month_open_format=>'<table border="0" cellpadding="0" cellspacing="0" summary="#CALENDAR_TITLE# #START_DL#" class="uCal">'
,p_daily_month_close_format=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'</table>',
'<div class="uCalFooter"></div>',
'</div>'))
,p_daily_day_open_format=>'<td class="uDay" headers="#DY#"><div class="uDayData">'
,p_daily_day_close_format=>'</div></td>'
,p_daily_today_open_format=>'<td class="uDay today" headers="#DY#"><div class="uDayData">'
,p_daily_time_open_format=>'<th scope="row" class="uCalHour" id="#TIME#">'
,p_daily_time_close_format=>'</th>'
,p_daily_time_title_format=>'#TIME#'
,p_daily_hour_open_format=>'<tr>'
,p_daily_hour_close_format=>'</tr>'
,p_agenda_format=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<ul class="listCalendar">',
'  <li class="monthHeader">',
'    <h1>#IMONTH# #YYYY#</h1>',
'  </li>',
'  #DAYS#',
'  <li class="listEndCap"></li>',
'</ul>'))
,p_agenda_past_day_format=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'  <li class="dayHeader past">',
'    <h2>#IDAY# <span>#IMONTH# #DD#</span></h2>',
'  </li>'))
,p_agenda_today_day_format=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'  <li class="dayHeader today">',
'    <h2>#IDAY# <span>#IMONTH# #DD#</span></h2>',
'  </li>'))
,p_agenda_future_day_format=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'  <li class="dayHeader future">',
'    <h2>#IDAY# <span>#IMONTH# #DD#</span></h2>',
'  </li>'))
,p_agenda_past_entry_format=>'  <li class="dayData past">#DATA#</li>'
,p_agenda_today_entry_format=>'  <li class="dayData today">#DATA#</li>'
,p_agenda_future_entry_format=>'  <li class="dayData future">#DATA#</li>'
,p_month_data_format=>'#DAYS#'
,p_month_data_entry_format=>'#DATA#'
,p_theme_id=>42
,p_theme_class_id=>1
);
end;
/
prompt --application/shared_components/user_interface/themes
begin
wwv_flow_api.create_theme(
 p_id=>788849194681209421+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_ui_type_name=>'DESKTOP'
,p_navigation_type=>'L'
,p_is_locked=>false
,p_default_page_template=>788830151089204775+wwv_flow_api.g_id_offset
,p_default_page_template_opt=>'#DEFAULT#'
,p_default_dialog_template=>788829236861204619+wwv_flow_api.g_id_offset
,p_error_template=>788827447128204316+wwv_flow_api.g_id_offset
,p_printer_friendly_template=>788830151089204775+wwv_flow_api.g_id_offset
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>788827447128204316+wwv_flow_api.g_id_offset
,p_default_button_template=>788848220255209127+wwv_flow_api.g_id_offset
,p_default_region_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_default_chart_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_default_form_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_default_reportr_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_default_tabform_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_default_wizard_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_default_menur_template=>788834570073205524+wwv_flow_api.g_id_offset
,p_default_listr_template=>788835918340205990+wwv_flow_api.g_id_offset
,p_default_irr_template=>788835768975205834+wwv_flow_api.g_id_offset
,p_default_report_template=>788840920131206733+wwv_flow_api.g_id_offset
,p_default_label_template=>788847462236208358+wwv_flow_api.g_id_offset
,p_default_menu_template=>788848363532209272+wwv_flow_api.g_id_offset
,p_default_calendar_template=>788848753039209419+wwv_flow_api.g_id_offset
,p_default_list_template=>788846781624207914+wwv_flow_api.g_id_offset
,p_default_nav_list_template=>788846699424207768+wwv_flow_api.g_id_offset
,p_default_nav_list_templ_opt=>'#DEFAULT#'
,p_default_option_label=>788847462236208358+wwv_flow_api.g_id_offset
,p_default_required_label=>788847507227208503+wwv_flow_api.g_id_offset
,p_default_page_transition=>'NONE'
,p_default_popup_transition=>'NONE'
,p_file_prefix=>'#IMAGE_PREFIX#themes/theme_42/'
);
end;
/
prompt --application/shared_components/user_interface/theme_style
begin
wwv_flow_api.create_theme_style(
 p_id=>788848974923209420+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'Modern Blue - Default'
,p_css_file_urls=>'#THEME_IMAGES#css/Theme-Standard#MIN#.css?v=#APEX_VERSION#'
,p_is_current=>true
);
wwv_flow_api.create_theme_style(
 p_id=>788849002688209421+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'Modern Red'
,p_css_file_urls=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'#THEME_IMAGES#css/Theme-Standard#MIN#.css?v=#APEX_VERSION#',
'#THEME_IMAGES#css/Theme-Oracle#MIN#.css?v=#APEX_VERSION#'))
,p_is_current=>false
);
end;
/
prompt --application/shared_components/user_interface/theme_files
begin
null;
end;
/
prompt --application/shared_components/user_interface/theme_display_points
begin
null;
end;
/
prompt --application/shared_components/user_interface/template_opt_groups
begin
wwv_flow_api.create_template_opt_group(
 p_id=>788833556429205523+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'ALERT_TYPE'
,p_display_name=>'Alert Type'
,p_display_sequence=>1
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788833878311205524+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'DISPLAY_TYPE'
,p_display_name=>'Display Type'
,p_display_sequence=>1
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788834977452205834+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'REGION_STYLE'
,p_display_name=>'Region Style'
,p_display_sequence=>1
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788835147721205834+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'REGION_PADDING'
,p_display_name=>'Region Padding'
,p_display_sequence=>1
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788836207895206139+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'BODY_HEIGHT'
,p_display_name=>'Body Height'
,p_display_sequence=>1
,p_template_types=>'REGION'
,p_null_text=>'Extend to Fit Contents'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788836611442206139+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'REGION_TYPE'
,p_display_name=>'Region Type'
,p_display_sequence=>1
,p_template_types=>'REGION'
,p_null_text=>'Normal - Default'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788836920185206139+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'BODY_OVERFLOW'
,p_display_name=>'Body Overflow'
,p_display_sequence=>1
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788837151313206139+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'REGION_HEADER'
,p_display_name=>'Region Header'
,p_display_sequence=>1
,p_template_types=>'REGION'
,p_null_text=>'Visible - Default'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788838672676206287+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'HIDE_STEPS_FOR'
,p_display_name=>'Hide Steps For'
,p_display_sequence=>1
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788839115032206436+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'LAYOUT'
,p_display_name=>'Layout'
,p_display_sequence=>1
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788839920817206437+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'BADGE_SIZE'
,p_display_name=>'Badge Size'
,p_display_sequence=>1
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788841024091206883+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'ALTERNATING_ROWS'
,p_display_name=>'Alternating Rows'
,p_display_sequence=>1
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788841200419206883+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'REPORT_BORDER'
,p_display_name=>'Report Border'
,p_display_sequence=>1
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788841673271206884+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'ROW_HIGHLIGHTING'
,p_display_name=>'Row Highlighting'
,p_display_sequence=>1
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788842577260207331+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'BADGE_SIZE'
,p_display_name=>'Badge Size'
,p_display_sequence=>1
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788842791016207331+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'LAYOUT'
,p_display_name=>'Layout'
,p_display_sequence=>1
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788844768919207477+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'DISPLAY_ICONS'
,p_display_name=>'Display Icons'
,p_display_sequence=>1
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788845208105207622+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'ICON_STYLE'
,p_display_name=>'Icon Style'
,p_display_sequence=>1
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788846981219208205+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'LABEL_DISPLAY'
,p_display_name=>'Label Display'
,p_display_sequence=>1
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788847952265209126+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'ICON_POSITION'
,p_display_name=>'Icon Position'
,p_display_sequence=>1
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788848469743209418+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'BREADCRUMB_DIVIDER'
,p_display_name=>'Breadcrumb Divider'
,p_display_sequence=>1
,p_template_types=>'BREADCRUMB'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788849283607209423+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'BUTTON_TYPE'
,p_display_name=>'Button Type'
,p_display_sequence=>1
,p_template_types=>'BUTTON'
,p_null_text=>'Normal'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788849434510209423+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SPACING_LEFT'
,p_display_name=>'Spacing Left'
,p_display_sequence=>1
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788849645751209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SPACING_RIGHT'
,p_display_name=>'Spacing Right'
,p_display_sequence=>1
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788849907023209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'BUTTON_SIZE'
,p_display_name=>'Button Size'
,p_display_sequence=>1
,p_template_types=>'BUTTON'
,p_null_text=>'Default Size'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788850142408209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'BUTTON_STYLE'
,p_display_name=>'Button Style'
,p_display_sequence=>1
,p_template_types=>'BUTTON'
,p_null_text=>'Default Style'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788850581722209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'BUTTON_SET'
,p_display_name=>'Button Set'
,p_display_sequence=>1
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788851270059209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'BUTTON_WIDTH'
,p_display_name=>'Button Width'
,p_display_sequence=>1
,p_template_types=>'BUTTON'
,p_null_text=>'Default Width'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788851662507209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FORM_LABEL_WIDTH'
,p_display_name=>'Form Label Width'
,p_display_sequence=>1
,p_template_types=>'REGION'
,p_help_text=>'Help text for Form Label Width'
,p_null_text=>'Default Width'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788852190327209425+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FORM_SIZE'
,p_display_name=>'Form Size'
,p_display_sequence=>1
,p_template_types=>'REGION'
,p_null_text=>'Default Size'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_opt_group(
 p_id=>788852475737209425+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FORM_ITEM_PADDING'
,p_display_name=>'Form Item Padding'
,p_display_sequence=>1
,p_template_types=>'REGION'
,p_null_text=>'Default Padding'
,p_is_advanced=>'Y'
);
end;
/
prompt --application/shared_components/user_interface/template_options
begin
wwv_flow_api.create_template_option(
 p_id=>788833432605205522+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'COLOREDBACKGROUND'
,p_display_name=>'Colored Background'
,p_display_sequence=>1
,p_region_template_id=>788833210017205368+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Alert--colorBG'
,p_template_types=>'REGION'
,p_help_text=>'Set alert background color to that of the alert type (warning, success, etc.)'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788833671836205523+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'DANGER'
,p_display_name=>'Danger'
,p_display_sequence=>2
,p_region_template_id=>788833210017205368+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Alert--danger'
,p_group_id=>788833556429205523+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_help_text=>'Show an error or danger alert.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788833709381205524+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'USEDEFAULTICONS'
,p_display_name=>'Use Default Icons'
,p_display_sequence=>7
,p_region_template_id=>788833210017205368+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Alert--defaultIcons'
,p_template_types=>'REGION'
,p_help_text=>'Uses default icons for alert types.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788833961636205524+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'HORIZONTAL'
,p_display_name=>'Horizontal'
,p_display_sequence=>3
,p_region_template_id=>788833210017205368+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Alert--horizontal'
,p_group_id=>788833878311205524+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_help_text=>'Show horizontal alert with buttons to the right.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788834085004205524+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'INFORMATION'
,p_display_name=>'Information'
,p_display_sequence=>4
,p_region_template_id=>788833210017205368+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Alert--info'
,p_group_id=>788833556429205523+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_help_text=>'Show informational alert.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788834146552205524+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'NOICON'
,p_display_name=>'No Icon'
,p_display_sequence=>5
,p_region_template_id=>788833210017205368+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Alert--noIcon'
,p_template_types=>'REGION'
,p_help_text=>'Display alert without icon.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788834289807205524+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SUCCESS'
,p_display_name=>'Success'
,p_display_sequence=>6
,p_region_template_id=>788833210017205368+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Alert--success'
,p_group_id=>788833556429205523+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_help_text=>'Show success alert.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788834382040205524+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'WARNING'
,p_display_name=>'Warning'
,p_display_sequence=>8
,p_region_template_id=>788833210017205368+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Alert--warning'
,p_group_id=>788833556429205523+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_help_text=>'Show a warning alert.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788834465672205524+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'WIZARD'
,p_display_name=>'Wizard'
,p_display_sequence=>9
,p_region_template_id=>788833210017205368+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Alert--wizard'
,p_group_id=>788833878311205524+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_help_text=>'Show the alert in a wizard style region.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788835090959205834+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'BORDERLESS'
,p_display_name=>'Borderless'
,p_display_sequence=>1
,p_region_template_id=>788834655647205677+wwv_flow_api.g_id_offset
,p_css_classes=>'t-ButtonRegion--noBorder'
,p_group_id=>788834977452205834+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788835216034205834+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'NOPADDING'
,p_display_name=>'No Padding'
,p_display_sequence=>3
,p_region_template_id=>788834655647205677+wwv_flow_api.g_id_offset
,p_css_classes=>'t-ButtonRegion--noPadding'
,p_group_id=>788835147721205834+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788835373169205834+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'REMOVEUIDECORATION'
,p_display_name=>'Remove UI Decoration'
,p_display_sequence=>4
,p_region_template_id=>788834655647205677+wwv_flow_api.g_id_offset
,p_css_classes=>'t-ButtonRegion--noUI'
,p_group_id=>788834977452205834+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788835430446205834+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SLIMPADDING'
,p_display_name=>'Slim Padding'
,p_display_sequence=>5
,p_region_template_id=>788834655647205677+wwv_flow_api.g_id_offset
,p_css_classes=>'t-ButtonRegion--slimPadding'
,p_group_id=>788835147721205834+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788835573480205834+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'CONTAINSITEMS'
,p_display_name=>'Region contains Items'
,p_display_sequence=>2
,p_region_template_id=>788834655647205677+wwv_flow_api.g_id_offset
,p_css_classes=>'t-ButtonRegion--withItems'
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788835640260205834+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'USEDFORWIZARDDIALOGS'
,p_display_name=>'Used for Wizard Dialogs'
,p_display_sequence=>6
,p_region_template_id=>788834655647205677+wwv_flow_api.g_id_offset
,p_css_classes=>'t-ButtonRegion--wizard'
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788835839199205990+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'REMOVEBORDERS'
,p_display_name=>'Remove Borders'
,p_display_sequence=>1
,p_region_template_id=>788835768975205834+wwv_flow_api.g_id_offset
,p_css_classes=>'t-IRR-region--noBorders'
,p_template_types=>'REGION'
,p_help_text=>'Removes borders around the Interactive Report'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788836305504206139+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'240PX'
,p_display_name=>'240px'
,p_display_sequence=>1
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'i-h240'
,p_group_id=>788836207895206139+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_help_text=>'Sets region body height to 240px.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788836440085206139+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'320PX'
,p_display_name=>'320px'
,p_display_sequence=>2
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'i-h320'
,p_group_id=>788836207895206139+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_help_text=>'Sets region body height to 320px.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788836575970206139+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'COLOREDBG'
,p_display_name=>'Use Region Type BG Color'
,p_display_sequence=>3
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--colorBG'
,p_template_types=>'REGION'
,p_help_text=>'Set the region''s background color to be similar to the Region Type option. For example, a Region Type of Warning will show a yellow background when this option is enabled.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788836731290206139+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'TYPEDANGER'
,p_display_name=>'Danger'
,p_display_sequence=>14
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--danger'
,p_group_id=>788836611442206139+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788836822599206139+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'TYPEEMPHASIS'
,p_display_name=>'Emphasis'
,p_display_sequence=>15
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--emphasis'
,p_group_id=>788836611442206139+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_help_text=>'Use this region type to bring attention to one given region. The region header is styled to be slightly darker.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788837067976206139+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'HIDEOVERFLOW'
,p_display_name=>'Hide Overflow'
,p_display_sequence=>5
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--hiddenOverflow'
,p_group_id=>788836920185206139+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788837208363206139+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'HIDEREGIONHEADER'
,p_display_name=>'Hidden (Accessible)'
,p_display_sequence=>6
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--hideHeader'
,p_group_id=>788837151313206139+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_help_text=>'This option will hide the region header.  Note that the region title will still be audible for Screen Readers. Buttons placed in the region header will be hidden and inaccessible.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788837397129206139+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'TYPEINFO'
,p_display_name=>'Info'
,p_display_sequence=>16
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--info'
,p_group_id=>788836611442206139+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788837498447206139+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'NOBORDER'
,p_display_name=>'Remove Region Border'
,p_display_sequence=>8
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--noBorder'
,p_template_types=>'REGION'
,p_help_text=>'Removes borders from the region.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788837565242206140+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'NOBODYPADDING'
,p_display_name=>'Remove Body Padding'
,p_display_sequence=>7
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--noPadding'
,p_template_types=>'REGION'
,p_help_text=>'Removes padding from region body.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788837653591206140+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'REGIONNOUI'
,p_display_name=>'Remove UI Decoration'
,p_display_sequence=>9
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--noUI'
,p_template_types=>'REGION'
,p_help_text=>'Removes all user interface decoration such as borders, backgrounds, shadows, etc.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788837765536206140+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'HIDDENHEADERNOAT'
,p_display_name=>'Hidden (not Accessible)'
,p_display_sequence=>4
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--removeHeader'
,p_group_id=>788837151313206139+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788837806194206140+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SCROLLBODY'
,p_display_name=>'Scroll Body'
,p_display_sequence=>10
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--scrollBody'
,p_group_id=>788836920185206139+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788837911014206140+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SCROLLWITHSHADOWS'
,p_display_name=>'Scroll Body (with shadows)'
,p_display_sequence=>11
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--shadowScroll'
,p_group_id=>788836920185206139+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_help_text=>'Enables the region body to scroll when a height is applied to the region, and shows shadows at top or bottom of region to indicate that content exists outside of viewable area.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788838091627206140+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SMALLERTEXT'
,p_display_name=>'Smaller Text'
,p_display_sequence=>12
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--small'
,p_template_types=>'REGION'
,p_help_text=>'Reduces font sizes for region header and region body.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788838124443206140+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'STACKED'
,p_display_name=>'Stacked'
,p_display_sequence=>13
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--stacked'
,p_template_types=>'REGION'
,p_help_text=>'Removes side borders and shadows, and can be useful for accordions and regions that need to be grouped together vertically.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788838283534206140+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'TYPESUCCESS'
,p_display_name=>'Success'
,p_display_sequence=>17
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--success'
,p_group_id=>788836611442206139+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788838301621206140+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'TYPEWARNING'
,p_display_name=>'Warning'
,p_display_sequence=>18
,p_region_template_id=>788835918340205990+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Region--warning'
,p_group_id=>788836611442206139+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788838563982206287+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'HEADERSHADING'
,p_display_name=>'Header Shading'
,p_display_sequence=>1
,p_region_template_id=>788838476638206140+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Wizard--headerBG'
,p_template_types=>'REGION'
,p_help_text=>'Adds background shading for the wizard header.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788838781072206288+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'HIDESMALLSCREENS'
,p_display_name=>'Small Screens (Tablet)'
,p_display_sequence=>2
,p_region_template_id=>788838476638206140+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Wizard--hideStepsSmall'
,p_group_id=>788838672676206287+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_help_text=>'Hides the wizard progress steps for screens that are smaller than 768px wide.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788838892318206288+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'HIDEXSMALLSCREENS'
,p_display_name=>'X Small Screens (Mobile)'
,p_display_sequence=>4
,p_region_template_id=>788838476638206140+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Wizard--hideStepsXSmall'
,p_group_id=>788838672676206287+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_help_text=>'Hides the wizard progress steps for screens that are smaller than 768px wide.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788838922801206288+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'HIDETITLE'
,p_display_name=>'Hide Title'
,p_display_sequence=>3
,p_region_template_id=>788838476638206140+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Wizard--noTitle'
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788839227022206436+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'2COLUMNGRID'
,p_display_name=>'2 Column Grid'
,p_display_sequence=>2
,p_report_template_id=>788839046150206288+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--cols'
,p_group_id=>788839115032206436+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_help_text=>'Arrange badges in a two column grid'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788839395401206436+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'3COLUMNGRID'
,p_display_name=>'3 Column Grid'
,p_display_sequence=>4
,p_report_template_id=>788839046150206288+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--cols t-BadgeList--3cols'
,p_group_id=>788839115032206436+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_help_text=>'Arrange badges in a 3 column grid'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788839453912206436+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'4COLUMNGRID'
,p_display_name=>'4 Column Grid'
,p_display_sequence=>6
,p_report_template_id=>788839046150206288+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--cols t-BadgeList--4cols'
,p_group_id=>788839115032206436+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788839574507206437+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'5COLUMNGRID'
,p_display_name=>'5 Column Grid'
,p_display_sequence=>7
,p_report_template_id=>788839046150206288+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--cols t-BadgeList--5cols'
,p_group_id=>788839115032206436+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788839660603206437+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FIXED'
,p_display_name=>'Span Horizontally'
,p_display_sequence=>10
,p_report_template_id=>788839046150206288+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--fixed'
,p_group_id=>788839115032206436+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788839754832206437+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FLEXIBLEBOX'
,p_display_name=>'Flexible Box'
,p_display_sequence=>11
,p_report_template_id=>788839046150206288+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--flex'
,p_group_id=>788839115032206436+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788839859264206437+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FLOATITEMS'
,p_display_name=>'Float Items'
,p_display_sequence=>12
,p_report_template_id=>788839046150206288+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--float'
,p_group_id=>788839115032206436+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788840048053206437+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'64PX'
,p_display_name=>'64px'
,p_display_sequence=>8
,p_report_template_id=>788839046150206288+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--large'
,p_group_id=>788839920817206437+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788840148396206437+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'48PX'
,p_display_name=>'48px'
,p_display_sequence=>5
,p_report_template_id=>788839046150206288+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--medium'
,p_group_id=>788839920817206437+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788840236612206437+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'RESPONSIVE'
,p_display_name=>'Responsive'
,p_display_sequence=>13
,p_report_template_id=>788839046150206288+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--responsive'
,p_template_types=>'REPORT'
,p_help_text=>'Automatically resize badges to smaller sizes as screen becomes smaller.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788840327368206437+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'32PX'
,p_display_name=>'32px'
,p_display_sequence=>3
,p_report_template_id=>788839046150206288+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--small'
,p_group_id=>788839920817206437+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788840421726206437+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'STACKED'
,p_display_name=>'Stacked'
,p_display_sequence=>14
,p_report_template_id=>788839046150206288+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--stacked'
,p_group_id=>788839115032206436+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788840522261206437+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'96PX'
,p_display_name=>'96px'
,p_display_sequence=>9
,p_report_template_id=>788839046150206288+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--xlarge'
,p_group_id=>788839920817206437+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788840675198206437+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'128PX'
,p_display_name=>'128px'
,p_display_sequence=>1
,p_report_template_id=>788839046150206288+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--xxlarge'
,p_group_id=>788839920817206437+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788841198353206883+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'ALTROWCOLORSENABLE'
,p_display_name=>'Enable'
,p_display_sequence=>2
,p_report_template_id=>788840920131206733+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Report--altRowsDefault'
,p_group_id=>788841024091206883+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788841389204206883+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'HORIZONTALBORDERS'
,p_display_name=>'Horizontal Borders'
,p_display_sequence=>4
,p_report_template_id=>788840920131206733+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Report--horizontalBorders'
,p_group_id=>788841200419206883+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788841425690206883+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'REMOVEOUTERBORDERS'
,p_display_name=>'Remove Outer Borders'
,p_display_sequence=>6
,p_report_template_id=>788840920131206733+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Report--inline'
,p_group_id=>788841200419206883+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788841519561206884+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'REMOVEALLBORDERS'
,p_display_name=>'Remove All Borders'
,p_display_sequence=>5
,p_report_template_id=>788840920131206733+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Report--noBorders'
,p_group_id=>788841200419206883+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788841727003206884+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'ENABLE'
,p_display_name=>'Enable'
,p_display_sequence=>3
,p_report_template_id=>788840920131206733+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Report--rowHighlight'
,p_group_id=>788841673271206884+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_help_text=>'Enable row highlighting on mouse over'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788841805783206884+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'ROWHIGHLIGHTDISABLE'
,p_display_name=>'Disable'
,p_display_sequence=>7
,p_report_template_id=>788840920131206733+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Report--rowHighlightOff'
,p_group_id=>788841673271206884+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_help_text=>'Disable row highlighting on mouse over'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788841935510206884+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'ALTROWCOLORSDISABLE'
,p_display_name=>'Disable'
,p_display_sequence=>1
,p_report_template_id=>788840920131206733+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Report--staticRowColors'
,p_group_id=>788841024091206883+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788842084997206884+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'STRETCHREPORT'
,p_display_name=>'Stretch Report'
,p_display_sequence=>8
,p_report_template_id=>788840920131206733+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Report--stretch'
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788842137906206884+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'VERTICALBORDERS'
,p_display_name=>'Vertical Borders'
,p_display_sequence=>9
,p_report_template_id=>788840920131206733+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Report--verticalBorders'
,p_group_id=>788841200419206883+wwv_flow_api.g_id_offset
,p_template_types=>'REPORT'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788842600000207331+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'XLARGE'
,p_display_name=>'96px'
,p_display_sequence=>13
,p_list_template_id=>788842491139207185+wwv_flow_api.g_id_offset
,p_css_classes=>'.t-BadgeList--xlarge'
,p_group_id=>788842577260207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788842869877207331+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'2COLUMNGRID'
,p_display_name=>'2 Column Grid'
,p_display_sequence=>1
,p_list_template_id=>788842491139207185+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--cols'
,p_group_id=>788842791016207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_help_text=>'Arrange badges in a two column grid'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788842975181207331+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'3COLUMNGRID'
,p_display_name=>'3 Column Grid'
,p_display_sequence=>2
,p_list_template_id=>788842491139207185+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--cols t-BadgeList--3cols'
,p_group_id=>788842791016207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_help_text=>'Arrange badges in a 3 column grid'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788843037854207331+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'4COLUMNGRID'
,p_display_name=>'4 Column Grid'
,p_display_sequence=>3
,p_list_template_id=>788842491139207185+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--cols t-BadgeList--4cols'
,p_group_id=>788842791016207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_help_text=>'Arrange badges in 4 column grid'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788843130563207331+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'5COLUMNGRID'
,p_display_name=>'5 Column Grid'
,p_display_sequence=>4
,p_list_template_id=>788842491139207185+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--cols t-BadgeList--5cols'
,p_group_id=>788842791016207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_help_text=>'Arrange badges in a 5 column grid'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788843224678207331+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FIXED'
,p_display_name=>'Span Horizontally'
,p_display_sequence=>5
,p_list_template_id=>788842491139207185+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--fixed'
,p_group_id=>788842791016207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_help_text=>'Span badges horizontally'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788843338669207332+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FLEXIBLEBOX'
,p_display_name=>'Flexible Box'
,p_display_sequence=>6
,p_list_template_id=>788842491139207185+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--flex'
,p_group_id=>788842791016207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_help_text=>'Use flexbox to arrange items'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788843470694207332+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FLOATITEMS'
,p_display_name=>'Float Items'
,p_display_sequence=>7
,p_list_template_id=>788842491139207185+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--float'
,p_group_id=>788842791016207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_help_text=>'Float badges to left'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788843509158207332+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'LARGE'
,p_display_name=>'64px'
,p_display_sequence=>8
,p_list_template_id=>788842491139207185+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--large'
,p_group_id=>788842577260207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788843665274207332+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'MEDIUM'
,p_display_name=>'48px'
,p_display_sequence=>9
,p_list_template_id=>788842491139207185+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--medium'
,p_group_id=>788842577260207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788843700878207332+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'RESPONSIVE'
,p_display_name=>'Responsive'
,p_display_sequence=>10
,p_list_template_id=>788842491139207185+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--responsive'
,p_template_types=>'LIST'
,p_help_text=>'Automatically resize badges to smaller sizes as screen becomes smaller.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788843877535207332+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SMALL'
,p_display_name=>'32px'
,p_display_sequence=>11
,p_list_template_id=>788842491139207185+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--small'
,p_group_id=>788842577260207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788843999587207332+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'STACKED'
,p_display_name=>'Stacked'
,p_display_sequence=>12
,p_list_template_id=>788842491139207185+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--stacked'
,p_group_id=>788842791016207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_help_text=>'Stack badges on top of each other'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788844094377207332+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'XXLARGE'
,p_display_name=>'128px'
,p_display_sequence=>14
,p_list_template_id=>788842491139207185+wwv_flow_api.g_id_offset
,p_css_classes=>'t-BadgeList--xxlarge'
,p_group_id=>788842577260207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788844239481207477+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'USEBRIGHTHOVERS'
,p_display_name=>'Use Bright Hovers'
,p_display_sequence=>7
,p_list_template_id=>788844187914207332+wwv_flow_api.g_id_offset
,p_css_classes=>'t-LinksList--brightHover'
,p_template_types=>'LIST'
,p_help_text=>'Uses a more colorful hover-state for links'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788844325479207477+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'ICONSONLY'
,p_display_name=>'Icons Only (for Header Nav)'
,p_display_sequence=>2
,p_list_template_id=>788844187914207332+wwv_flow_api.g_id_offset
,p_css_classes=>'t-LinksList--iconOnly'
,p_template_types=>'LIST'
,p_help_text=>'Displays icons that are useful for header bar navigation.'
,p_is_advanced=>'N'
);
end;
/
begin
wwv_flow_api.create_template_option(
 p_id=>788844429231207477+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'DISABLETEXTWRAPPING'
,p_display_name=>'Disable Text Wrapping'
,p_display_sequence=>1
,p_list_template_id=>788844187914207332+wwv_flow_api.g_id_offset
,p_css_classes=>'t-LinksList--nowrap'
,p_template_types=>'LIST'
,p_help_text=>'Do not allow link text to wrap to new lines. Truncate with ellipsis.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788844571415207477+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SHOWGOTOARROW'
,p_display_name=>'Show Right Arrow'
,p_display_sequence=>4
,p_list_template_id=>788844187914207332+wwv_flow_api.g_id_offset
,p_css_classes=>'t-LinksList--showArrow'
,p_template_types=>'LIST'
,p_help_text=>'Show arrow to the right of link'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788844673683207477+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SHOWBADGES'
,p_display_name=>'Show Badges'
,p_display_sequence=>3
,p_list_template_id=>788844187914207332+wwv_flow_api.g_id_offset
,p_css_classes=>'t-LinksList--showBadge'
,p_template_types=>'LIST'
,p_help_text=>'Show badge to right of link (requires Attribute 1 to be populated)'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788844882218207477+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SHOWICONS'
,p_display_name=>'For all items'
,p_display_sequence=>5
,p_list_template_id=>788844187914207332+wwv_flow_api.g_id_offset
,p_css_classes=>'t-LinksList--showIcons'
,p_group_id=>788844768919207477+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788844944904207477+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SHOWTOPICONS'
,p_display_name=>'For Top Level Items Only'
,p_display_sequence=>6
,p_list_template_id=>788844187914207332+wwv_flow_api.g_id_offset
,p_css_classes=>'t-LinksList--showTopIcons'
,p_group_id=>788844768919207477+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_help_text=>'This will show icons for top level items of the list only. It will not show icons for sub lists.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788845131051207622+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'DISPLAYASBUTTONS'
,p_display_name=>'Display as Buttons'
,p_display_sequence=>6
,p_list_template_id=>788845088168207477+wwv_flow_api.g_id_offset
,p_css_classes=>'t-MediaList--buttons'
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788845389333207622+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'CIRCULARICONS'
,p_display_name=>'Circular Icons'
,p_display_sequence=>5
,p_list_template_id=>788845088168207477+wwv_flow_api.g_id_offset
,p_css_classes=>'t-MediaList--circularIcons'
,p_group_id=>788845208105207622+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788845476699207622+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'2COLUMNGRID'
,p_display_name=>'2 Column Grid'
,p_display_sequence=>1
,p_list_template_id=>788845088168207477+wwv_flow_api.g_id_offset
,p_css_classes=>'t-MediaList--cols t-MediaList--2cols'
,p_group_id=>788842791016207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788845530252207622+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'3COLUMNGRID'
,p_display_name=>'3 Column Grid'
,p_display_sequence=>2
,p_list_template_id=>788845088168207477+wwv_flow_api.g_id_offset
,p_css_classes=>'t-MediaList--cols t-MediaList--3cols'
,p_group_id=>788842791016207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788845636212207622+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'4COLUMNGRID'
,p_display_name=>'4 Column Grid'
,p_display_sequence=>3
,p_list_template_id=>788845088168207477+wwv_flow_api.g_id_offset
,p_css_classes=>'t-MediaList--cols t-MediaList--4cols'
,p_group_id=>788842791016207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788845710409207622+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'5COLUMNGRID'
,p_display_name=>'5 Column Grid'
,p_display_sequence=>4
,p_list_template_id=>788845088168207477+wwv_flow_api.g_id_offset
,p_css_classes=>'t-MediaList--cols t-MediaList--5cols'
,p_group_id=>788842791016207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788845830753207623+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'STANDARDICONS'
,p_display_name=>'Standard Icons'
,p_display_sequence=>13
,p_list_template_id=>788845088168207477+wwv_flow_api.g_id_offset
,p_css_classes=>'t-MediaList--defaultIcons'
,p_group_id=>788845208105207622+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788845931018207623+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SPANHORIZONTAL'
,p_display_name=>'Span Horizontal'
,p_display_sequence=>12
,p_list_template_id=>788845088168207477+wwv_flow_api.g_id_offset
,p_css_classes=>'t-MediaList--horizontal'
,p_group_id=>788842791016207331+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_help_text=>'Show all list items in one horizontal row.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788846008667207623+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'HIDEBADGE'
,p_display_name=>'Hide Badge'
,p_display_sequence=>7
,p_list_template_id=>788845088168207477+wwv_flow_api.g_id_offset
,p_css_classes=>'t-MediaList--noBadge'
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788846163114207623+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'HIDEDESCRIPTION'
,p_display_name=>'Hide Description'
,p_display_sequence=>8
,p_list_template_id=>788845088168207477+wwv_flow_api.g_id_offset
,p_css_classes=>'t-MediaList--noDesc'
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788846204020207623+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'NOICONS'
,p_display_name=>'No Icons'
,p_display_sequence=>10
,p_list_template_id=>788845088168207477+wwv_flow_api.g_id_offset
,p_css_classes=>'t-MediaList--noIcons'
,p_group_id=>788845208105207622+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788846372975207623+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'HIDETITLE'
,p_display_name=>'Hide Title'
,p_display_sequence=>9
,p_list_template_id=>788845088168207477+wwv_flow_api.g_id_offset
,p_css_classes=>'t-MediaList--noTitle'
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788846446595207623+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SLIMMERPADDING'
,p_display_name=>'Slimmer Padding'
,p_display_sequence=>11
,p_list_template_id=>788845088168207477+wwv_flow_api.g_id_offset
,p_css_classes=>'t-MediaList--slim'
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788847014388208205+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'CURRENTSTEPONLY'
,p_display_name=>'Current Step Only'
,p_display_sequence=>2
,p_list_template_id=>788846860150208059+wwv_flow_api.g_id_offset
,p_css_classes=>'t-WizardSteps--displayCurrentLabelOnly'
,p_group_id=>788846981219208205+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788847121956208205+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'ALLSTEPS'
,p_display_name=>'All Steps'
,p_display_sequence=>1
,p_list_template_id=>788846860150208059+wwv_flow_api.g_id_offset
,p_css_classes=>'t-WizardSteps--displayLabels'
,p_group_id=>788846981219208205+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788847265977208205+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'HIDELABELS'
,p_display_name=>'Hide Labels'
,p_display_sequence=>3
,p_list_template_id=>788846860150208059+wwv_flow_api.g_id_offset
,p_css_classes=>'t-WizardSteps--hideLabels'
,p_group_id=>788846981219208205+wwv_flow_api.g_id_offset
,p_template_types=>'LIST'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788848064680209126+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'LEFTICON'
,p_display_name=>'Left'
,p_display_sequence=>1
,p_button_template_id=>788847802513208981+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Button--iconLeft'
,p_group_id=>788847952265209126+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788848125076209127+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'RIGHTICON'
,p_display_name=>'Right'
,p_display_sequence=>2
,p_button_template_id=>788847802513208981+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Button--iconRight'
,p_group_id=>788847952265209126+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788848569339209418+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'RIGHTARROW'
,p_display_name=>'Right Arrow'
,p_display_sequence=>2
,p_breadcrumb_template_id=>788848363532209272+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Breadcrumb--dividerArrow'
,p_group_id=>788848469743209418+wwv_flow_api.g_id_offset
,p_template_types=>'BREADCRUMB'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788848666949209418+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'DIVIDERSLASH'
,p_display_name=>'Slash'
,p_display_sequence=>1
,p_breadcrumb_template_id=>788848363532209272+wwv_flow_api.g_id_offset
,p_css_classes=>'t-Breadcrumb--dividerSlash'
,p_group_id=>788848469743209418+wwv_flow_api.g_id_offset
,p_template_types=>'BREADCRUMB'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788849340862209423+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'DANGER'
,p_display_name=>'Danger'
,p_display_sequence=>1
,p_css_classes=>'t-Button--danger'
,p_group_id=>788849283607209423+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788849592733209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'LARGELEFTMARGIN'
,p_display_name=>'Large Left Margin'
,p_display_sequence=>1
,p_css_classes=>'t-Button--gapLeft'
,p_group_id=>788849434510209423+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788849778831209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'LARGERIGHTMARGIN'
,p_display_name=>'Large Right Margin'
,p_display_sequence=>1
,p_css_classes=>'t-Button--gapRight'
,p_group_id=>788849645751209424+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788849886548209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'HOT'
,p_display_name=>'Hot'
,p_display_sequence=>1
,p_css_classes=>'t-Button--hot'
,p_group_id=>788849283607209423+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788850032452209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'LARGE'
,p_display_name=>'Large'
,p_display_sequence=>1
,p_css_classes=>'t-Button--large'
,p_group_id=>788849907023209424+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788850290655209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'NOUI'
,p_display_name=>'Remove UI Decoration'
,p_display_sequence=>1
,p_css_classes=>'t-Button--noUI'
,p_group_id=>788850142408209424+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788850366994209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SMALLLEFTMARGIN'
,p_display_name=>'Small Left Margin'
,p_display_sequence=>1
,p_css_classes=>'t-Button--padLeft'
,p_group_id=>788849434510209423+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788850490086209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SMALLRIGHTMARGIN'
,p_display_name=>'Small Right Margin'
,p_display_sequence=>1
,p_css_classes=>'t-Button--padRight'
,p_group_id=>788849645751209424+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788850615503209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'PILL'
,p_display_name=>'Inner Button'
,p_display_sequence=>1
,p_css_classes=>'t-Button--pill'
,p_group_id=>788850581722209424+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788850756425209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'PILLEND'
,p_display_name=>'Last Button'
,p_display_sequence=>1
,p_css_classes=>'t-Button--pillEnd'
,p_group_id=>788850581722209424+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788850882240209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'PILLSTART'
,p_display_name=>'First Button'
,p_display_sequence=>1
,p_css_classes=>'t-Button--pillStart'
,p_group_id=>788850581722209424+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_help_text=>'Use this for the start of a pill button.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788850962216209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'PRIMARY'
,p_display_name=>'Primary'
,p_display_sequence=>1
,p_css_classes=>'t-Button--primary'
,p_group_id=>788849283607209423+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788851075953209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SIMPLE'
,p_display_name=>'Simple'
,p_display_sequence=>1
,p_css_classes=>'t-Button--simple'
,p_group_id=>788850142408209424+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788851117750209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SMALL'
,p_display_name=>'Small'
,p_display_sequence=>1
,p_css_classes=>'t-Button--small'
,p_group_id=>788849907023209424+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788851309607209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'STRETCH'
,p_display_name=>'Stretch'
,p_display_sequence=>1
,p_css_classes=>'t-Button--stretch'
,p_group_id=>788851270059209424+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_help_text=>'Stretches button to fill container'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788851496527209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SUCCESS'
,p_display_name=>'Success'
,p_display_sequence=>1
,p_css_classes=>'t-Button--success'
,p_group_id=>788849283607209423+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788851526385209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'WARNING'
,p_display_name=>'Warning'
,p_display_sequence=>1
,p_css_classes=>'t-Button--warning'
,p_group_id=>788849283607209423+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788851785940209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FORMLABELWIDTHFIXED'
,p_display_name=>'Fixed'
,p_display_sequence=>1
,p_css_classes=>'t-Form--fixedLabels'
,p_group_id=>788851662507209424+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788851897785209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FLOATITEMSTOLEFT'
,p_display_name=>'Float Items to Left'
,p_display_sequence=>1
,p_css_classes=>'t-Form--floatLeft'
,p_template_types=>'REGION'
,p_help_text=>'Float form items and labels to left. This is useful for button bars.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788851904276209424+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FORMLABELWIDTH25P'
,p_display_name=>'25%'
,p_display_sequence=>1
,p_css_classes=>'t-Form--labels25p'
,p_group_id=>788851662507209424+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788852078098209425+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'SHOWFORMLABELSABOVE'
,p_display_name=>'Show Form Labels Above'
,p_display_sequence=>1
,p_css_classes=>'t-Form--labelsAbove'
,p_template_types=>'REGION'
,p_help_text=>'Show form labels above input fields.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788852243683209425+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FORMSIZELARGE'
,p_display_name=>'Large'
,p_display_sequence=>1
,p_css_classes=>'t-Form--large'
,p_group_id=>788852190327209425+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788852391819209425+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FORMLEFTLABELS'
,p_display_name=>'Align Labels Left'
,p_display_sequence=>1
,p_css_classes=>'t-Form--leftLabels'
,p_template_types=>'REGION'
,p_help_text=>'Align form labels to left.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788852529640209425+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FORMREMOVEPADDING'
,p_display_name=>'Remove Padding'
,p_display_sequence=>1
,p_css_classes=>'t-Form--noPadding'
,p_group_id=>788852475737209425+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_help_text=>'Removes padding between items.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788852669478209425+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FORMSLIMPADDING'
,p_display_name=>'Slim Padding'
,p_display_sequence=>1
,p_css_classes=>'t-Form--slimPadding'
,p_group_id=>788852475737209425+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_help_text=>'Reduces form item padding to 4px.'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788852757631209425+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'STRETCH_FORM_FIELDS'
,p_display_name=>'Stretch Form Fields'
,p_display_sequence=>1
,p_css_classes=>'t-Form--stretchInputs'
,p_template_types=>'REGION'
);
wwv_flow_api.create_template_option(
 p_id=>788852803870209425+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'FORMSIZEXLARGE'
,p_display_name=>'X Large'
,p_display_sequence=>1
,p_css_classes=>'t-Form--xlarge'
,p_group_id=>788852190327209425+wwv_flow_api.g_id_offset
,p_template_types=>'REGION'
,p_is_advanced=>'N'
);
wwv_flow_api.create_template_option(
 p_id=>788852997599209425+wwv_flow_api.g_id_offset
,p_theme_id=>42
,p_name=>'WIDTH50P'
,p_display_name=>'50% Width'
,p_display_sequence=>1
,p_css_classes=>'w50p'
,p_group_id=>788851270059209424+wwv_flow_api.g_id_offset
,p_template_types=>'BUTTON'
,p_is_advanced=>'N'
);
end;
/
prompt --application/shared_components/logic/build_options
begin
null;
end;
/
prompt --application/shared_components/globalization/language
begin
null;
end;
/
prompt --application/shared_components/globalization/messages
begin
null;
end;
/
prompt --application/shared_components/globalization/dyntranslations
begin
null;
end;
/
prompt --application/shared_components/user_interface/shortcuts
begin
wwv_flow_api.create_shortcut(
 p_id=>793144759765027232+wwv_flow_api.g_id_offset
,p_shortcut_name=>'DELETE_CONFIRM_MSG'
,p_shortcut_type=>'TEXT_ESCAPE_JS'
,p_shortcut=>'Would you like to perform this delete action?'
);
end;
/
prompt --application/shared_components/security/authentications
begin
wwv_flow_api.create_authentication(
 p_id=>788853266544209427+wwv_flow_api.g_id_offset
,p_name=>'Application Express Authentication'
,p_scheme_type=>'NATIVE_APEX_ACCOUNTS'
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
end;
/
prompt --application/ui_types
begin
null;
end;
/
prompt --application/deployment/definition
begin
wwv_flow_api.create_install(
 p_id=>788886853487286705+wwv_flow_api.g_id_offset
);
end;
/
prompt --application/deployment/install
begin
null;
end;
/
prompt --application/deployment/checks
begin
null;
end;
/
prompt --application/deployment/buildoptions
begin
null;
end;
/
prompt --application/end_environment
begin
wwv_flow_api.import_end;
commit;
end;
/
set verify on feedback on define on
prompt  ...done
